const nextSteps = ['follow_up','retry_cadence','close_not_interested','close_dnc','close_wrong_number','convert'];
const noContact = new Set(['no_answer','voicemail','consumer_ended']);
const closeSteps = ['close_not_interested','close_dnc','close_wrong_number'];
const text = value => typeof value === 'string' ? value.trim() : '';

export function validateProspectNextStep(body, now = Date.now()) {
  const step = text(body.nextStep);
  const outcome = body.outcome;
  const labels = {
    follow_up:'Schedule follow-up', retry_cadence:'Retry by cadence', close_not_interested:'Close as not interested',
    close_dnc:'Close as do not contact', close_wrong_number:'Close as wrong number', convert:'Continue to conversion',
  };
  let allowed = nextSteps.filter(candidate => candidate !== 'retry_cadence' || noContact.has(outcome));
  if (['interested','callback_requested'].includes(outcome)) allowed = ['follow_up','convert'];
  if (outcome === 'not_interested') allowed = closeSteps;
  if (outcome === 'declined') allowed = [...closeSteps,'follow_up'];
  if (outcome === 'invalid_number') allowed = ['close_wrong_number'];
  if (!allowed.includes(step)) {
    return { error: 'Choose exactly one allowed next step: ' + allowed.map(candidate => labels[candidate]).join(', ') + '.' };
  }
  if (outcome === 'declined' && step === 'follow_up' && text(body.warningReason).length < 5) {
    return { error: 'To schedule a follow-up after a decline, enter a reason of at least five characters.' };
  }
  const reason = text(body.notInterestedReason);
  const note = text(body.notInterestedNote);
  const month = text(body.recontactMonth);
  if ((step === 'close_not_interested' || outcome === 'declined' || reason) && !/^[a-z][a-z0-9_]{0,63}$/.test(reason)) {
    return { error: 'Select a valid not-interested reason' };
  }
  if (reason === 'other' && note.length < 5) return { error: 'Explain the Other reason in at least five characters' };
  if (month && (reason !== 'timing' || !/^[2-9][0-9]{3}-(0[1-9]|1[0-2])$/.test(month))) {
    return { error: 'Select a valid recontact month for the timing reason' };
  }
  if (step === 'close_dnc' && text(body.doNotContactReason).length < 5) {
    return { error: 'A meaningful do-not-contact reason is required' };
  }
  let followUp = null;
  if (step === 'follow_up') {
    const due = Date.parse(body.followUpDueAt);
    const channel = text(body.followUpChannel);
    const subject = text(body.followUpSubject);
    if (!Number.isFinite(due) || due <= now || due > now + 90 * 86400000 ||
        !['call','whatsapp','email'].includes(channel) || !subject) {
      return { error: 'Follow-up needs a channel, subject and future due time within 90 days' };
    }
    followUp = { dueAt: new Date(due).toISOString(), channel, subject };
  }
  return { step, reason: reason || null, note: note || null, recontactDate: month ? month + '-01' : null, followUp };
}

export function answeredCallStatus(currentStatus, step) {
  if (step === 'close_dnc' || step === 'close_wrong_number') return 'do_not_contact';
  if (currentStatus === 'do_not_contact' || currentStatus === 'converted') return currentStatus;
  if (step === 'close_not_interested') return 'not_interested';
  if (step === 'follow_up' && currentStatus !== 'interested') return 'call_back';
  if (step === 'convert' && ['not_contacted', 'no_answer'].includes(currentStatus)) return 'call_back';
  return currentStatus;
}

export function addDubaiWorkingDays(at, days, workingDays) {
  if (!Number.isInteger(days) || days < 0 || !workingDays.length) throw new Error('Invalid working-day interval');
  const dubaiOffset = 4 * 3600000;
  const date = new Date(new Date(at).getTime() + dubaiOffset);
  if (!Number.isFinite(date.getTime())) throw new Error('Invalid activity timestamp');
  for (let remaining = days; remaining > 0;) {
    date.setUTCDate(date.getUTCDate() + 1);
    if (workingDays.includes(date.getUTCDay() || 7)) remaining--;
  }
  return new Date(date.getTime() - dubaiOffset);
}

export function advanceProspectRetry({ previousAttempts, outcome, step, at, policy }) {
  if (['answered','callback_requested','interested','not_interested','declined'].includes(outcome)) {
    return { attempts: 0, nextAt: null, parkedAt: null };
  }
  if (step !== 'retry_cadence') return { attempts: 0, nextAt: null, parkedAt: null };
  // The first unsuccessful call schedules retry 1. Retry 3 failing parks the prospect.
  const attempts = (previousAttempts ?? 0) + 1;
  const gap = policy.retryGaps[attempts - 1];
  return {
    attempts,
    nextAt: gap ? addDubaiWorkingDays(at, gap, policy.workingDays) : null,
    parkedAt: !gap && policy.parkOnExhaustion ? new Date(at) : null,
  };
}

export async function applyProspectRetryLimits(planned, workingDays, getWarnings) {
  const nextAt = new Date(planned);
  let weeklyLimitMovedRetry = false;
  const thresholds = ['unanswered_daily_threshold','unanswered_weekly_threshold','repeat_after_decline'];
  for (let day = 0; day < 15; day++) {
    const workingDay = new Date(nextAt.getTime()+4*3600000).getUTCDay() || 7;
    if (workingDays.includes(workingDay)) {
      const warnings = await getWarnings(nextAt);
      if (!warnings.some(warning => thresholds.includes(warning))) {
        return {
          nextAt,
          moved: weeklyLimitMovedRetry ? {
            plannedAt: planned.toISOString(),
            movedAt: nextAt.toISOString(),
            reason: 'unanswered_weekly_threshold',
          } : null,
        };
      }
      weeklyLimitMovedRetry ||= warnings.includes('unanswered_weekly_threshold');
    }
    nextAt.setUTCDate(nextAt.getUTCDate()+1);
  }
  return {nextAt:null,moved:null};
}

const boundedInteger = (value, min, max) => Number.isInteger(value) && value >= min && value <= max;

export function validateProspectCadence(body = {}) {
  const { dailyTarget, workingDays, firstCallDays, retryGaps, parkOnExhaustion } = body;
  if (!boundedInteger(dailyTarget, 0, 300) || !boundedInteger(firstCallDays, 1, 14) ||
      !Array.isArray(workingDays) || workingDays.length === 0 ||
      workingDays.some(day => !boundedInteger(day, 1, 7)) || new Set(workingDays).size !== workingDays.length ||
      !Array.isArray(retryGaps) || !boundedInteger(retryGaps.length, 1, 10) ||
      retryGaps.some(gap => !boundedInteger(gap, 1, 14)) || typeof parkOnExhaustion !== 'boolean') {
    return { error: 'Enter a valid call target, working days, first-call deadline and retry cadence' };
  }
  return { dailyTarget, workingDays: [...workingDays].sort((a,b) => a-b), firstCallDays, retryGaps, parkOnExhaustion };
}

export function validateProspectAgentTarget(body = {}) {
  const { dailyTarget, effectiveFrom } = body;
  const reason = text(body.reason);
  const validDate = typeof effectiveFrom === 'string' && /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(effectiveFrom) &&
    Number.isFinite(Date.parse(effectiveFrom)) && new Date(effectiveFrom).toISOString().slice(0,10) === effectiveFrom;
  if (!boundedInteger(dailyTarget, 0, 300) || !validDate || reason.length < 5 || reason.length > 1000) {
    return { error: 'Enter a target from 0 to 300, an effective date and a meaningful reason' };
  }
  return { dailyTarget, effectiveFrom, reason };
}
