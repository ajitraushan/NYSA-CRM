import { startProspectDigestWorker } from './prospect-digest-worker.js';
import {startAdviceWorker} from './payout-advice.js';
import {startWebIntakeWorker} from './web-intake-worker.js';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './lib/http-kit.js';
import authRoutes from './routes/auth.js';
import listingRoutes from './routes/listings.js';
import commentRoutes from './routes/comments.js';
import adminRoutes from './routes/admin.js';
import crmRoutes from './routes/crm.js';
import governanceRoutes from './routes/governance.js';
import leadOperationRoutes from './routes/lead-operations.js';
import websiteIntakeRoutes from './routes/website-intake.js';
import listingIntakeRoutes from './routes/listing-intake.js';
import listingMappingRoutes from './routes/listing-mappings.js';
import qualificationFinanceRoutes from './routes/qualification-finance.js';
import filesProposalRoutes from './routes/files-proposals.js';
import dashboardRoutes from './routes/dashboards.js';
import aiRoutes from './routes/ai.js';
import opportunityRoutes from './routes/opportunities.js';
import integrationRoutes from './routes/integrations.js';
import propertyFinderSandboxRoutes from './routes/property-finder-sandbox.js';
import propertyFinderMediaDeliveryRoutes from './routes/property-finder-media-delivery.js';
import diaryRoutes from './routes/diary.js';
import transactionRepresentationRoutes from './routes/transaction-representation.js';
import campaignRoutes from './routes/campaigns.js';
import governedMatchingRoutes from './routes/governed-matching.js';
import inventoryImportRoutes from './routes/inventory-import.js';
import partnerOrganizationRoutes from './routes/partner-organizations.js';
import release3cGovernedShareRoutes from './routes/release3c-governed-shares.js';
import officialDocumentEvidenceRoutes from './routes/official-document-evidence.js';
import dldMarketIntelligenceRoutes from './routes/dld-market-intelligence.js';
import commissionPayoutRoutes from './routes/commission-payout.js';
import agentLeaveRoutes from './routes/agent-leave.js';
import documentComplianceRoutes from './routes/document-compliance.js';
import marketingMaterialComplianceRoutes from './routes/marketing-material-compliance.js';
import emailCalendlyRoutes from './routes/email-calendly.js';
import classificationCatalogueRoutes from './routes/classification-catalogue.js';
import purchasedDataImportRoutes from './routes/purchased-data-import.js';
import approvedDocumentRoutes from './routes/approved-documents.js';
import { migrate, closeDatabase, transaction } from './db.js';
import { createMetaIntakeRoutes } from './routes/meta-intake.js';
import { createLeadIntegrationSetupRoutes } from './routes/lead-integration-setup.js';
import { createLeadResponseRoutes } from './routes/lead-response.js';
import { createWebIntakePhase1Routes } from './routes/web-intake-phase1.js';
import { createLeadChannelInboxRoutes } from './routes/lead-channel-inbox.js';
import { createNativeLeadWhatsAppRoutes } from './lead-whatsapp.js';
import { createWhatsAppSandboxAdminRoutes, createWhatsAppSandboxInboxRoutes } from './routes/whatsapp-sandbox.js';
import whatsappWorkspaceRoutes from './routes/whatsapp-workspace.js';
import prospectRoutes from './routes/prospects.js';
import {createWhatsAppSimulatedProviderRoutes,createWhatsAppSimulationControlRoutes} from './routes/whatsapp-simulated-provider.js';
import {assertSimulatedProviderEnvironment} from './whatsapp-simulated-provider.js';
import {configureWhatsAppReplyLock} from './whatsapp-reply-lock.js';
import {configureProspectCallingPolicy} from './prospect-calling-policy.js';
import { leadConnectionEnvironment } from './lead-integration-connections.js';
import { requireAuth } from './auth.js';
import { productionCampaignsDisabled } from './production-campaign-policy.js';
import { configureHttpServer, createShutdownHandler, writeRuntimeEvent } from './lib/runtime-lifecycle.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = createApp();
const loadLeadEnvironment=async()=>{
 if(process.env.META_INTAKE_ENABLED!=='true' && process.env.LEAD_WHATSAPP_INBOX_ENABLED!=='true')return process.env;
 const draft=await transaction(async c=>(await c.query('SELECT draft FROM lead_integration_setup WHERE singleton=TRUE')).rows[0]?.draft);
 const credentials=process.env.LEAD_CONNECTION_KEY?await transaction(c=>leadConnectionEnvironment(c,process.env.LEAD_CONNECTION_KEY)):{};
 return {...process.env,...credentials,...(draft?.pageIds?.length?{META_ALLOWED_PAGE_IDS:draft.pageIds.join(',')}:{} )};
};

app.mount('/api', authRoutes);
app.mount('/api', listingRoutes);
app.mount('/api', commentRoutes);
app.mount('/api', adminRoutes);
app.mount('/api', websiteIntakeRoutes);
app.mount('/api', createMetaIntakeRoutes({transaction,loadEnvironment:loadLeadEnvironment}));
app.mount('/api', createLeadIntegrationSetupRoutes({requireAuth,transaction}));
app.mount('/api', createLeadResponseRoutes({requireAuth,transaction}));
app.mount('/api', createWebIntakePhase1Routes({requireAuth,transaction}));
app.mount('/api', createLeadChannelInboxRoutes({transaction}));
if (!productionCampaignsDisabled()) {
  app.mount('/api', createNativeLeadWhatsAppRoutes({transaction,loadEnvironment:loadLeadEnvironment}));
  app.mount('/api', createWhatsAppSandboxAdminRoutes({requireAuth,transaction}));
  app.mount('/api', createWhatsAppSandboxInboxRoutes({transaction}));
  app.mount('/api', whatsappWorkspaceRoutes);
  app.mount('/api', createWhatsAppSimulatedProviderRoutes());
  app.mount('/api', createWhatsAppSimulationControlRoutes());
}
app.mount('/api', listingIntakeRoutes);
app.mount('/api', listingMappingRoutes);
app.mount('/api', crmRoutes);
app.mount('/api', prospectRoutes);
app.mount('/api', governanceRoutes);
app.mount('/api', leadOperationRoutes);
app.mount('/api', qualificationFinanceRoutes);
app.mount('/api', filesProposalRoutes);
app.mount('/api', dashboardRoutes);
app.mount('/api', aiRoutes);
app.mount('/api', opportunityRoutes);
app.mount('/api', integrationRoutes);
app.mount('/api', propertyFinderMediaDeliveryRoutes);
app.mount('/api', propertyFinderSandboxRoutes);
app.mount('/api', diaryRoutes);
app.mount('/api', transactionRepresentationRoutes);
app.mount('/api', campaignRoutes);
app.mount('/api', governedMatchingRoutes);
app.mount('/api', inventoryImportRoutes);
app.mount('/api', partnerOrganizationRoutes);
app.mount('/api', release3cGovernedShareRoutes);
app.mount('/api', officialDocumentEvidenceRoutes);
app.mount('/api', dldMarketIntelligenceRoutes);
app.mount('/api', commissionPayoutRoutes);
app.mount('/api', agentLeaveRoutes);
app.mount('/api', documentComplianceRoutes);
app.mount('/api', marketingMaterialComplianceRoutes);
app.mount('/api', emailCalendlyRoutes);
app.mount('/api', classificationCatalogueRoutes);
app.mount('/api', purchasedDataImportRoutes);
app.mount('/api', approvedDocumentRoutes);
app.static(path.join(__dirname, '..', 'public'));

const PORT = process.env.PORT || 3000;
let server;

const shutdown = createShutdownHandler({
  getServer: () => server,
  closeDatabase
});

async function start() {
  writeRuntimeEvent('starting');
  assertSimulatedProviderEnvironment();
  configureWhatsAppReplyLock(process.env);
  configureProspectCallingPolicy(process.env);
  await migrate();
  startAdviceWorker();
  startWebIntakeWorker({transaction});
  startProspectDigestWorker();
  await new Promise((resolve, reject) => {
    server = app.listen(PORT, () => {
      server.off('error', reject);
      writeRuntimeEvent('listening');
      resolve();
    });
    configureHttpServer(server);
    server.once('error', reject);
  });
}

process.on('SIGTERM', () => void shutdown('SIGTERM'));
process.on('SIGINT', () => void shutdown('SIGINT'));

start().catch(async (error) => {
  console.error('Application startup failed:', error);
  await shutdown('startup-failure', 1);
});
