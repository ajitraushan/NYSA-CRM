import {businessLineAtSql,businessLineFilterSql,businessLineSetup,registerBusinessLineRoutes} from '../business-lines.js';
import { Router } from '../lib/http-kit.js';
import { one,many,execute,transaction,uuid,audit } from '../db.js';
import { requireAuth } from '../auth.js';
import { hasNysaStaffIdentity,isManager,isCompanyReader,isProposalApprover,agentWorkLeadScopeSql,opportunityScopeSql,proposalApprovalScopeSql } from '../crm-policy.js';
import { dashboardTypeFor,buildRoleDashboardPresentation,buildAgentLifecycle,AGENT_LIFECYCLE_STAGES } from '../dashboard-domain.js';
import {targetSetup,TARGET_METRICS,createTarget,changeTarget,listTargetVersions,comparisonPeriods} from '../dashboard-target-service.js';
import {targetDate,dubaiToday} from '../dashboard-target-domain.js';
import {pipelineJoin,pipelineStageSql} from '../dashboard-pipeline.js';

import {dashboardLeadScopeSql,dashboardTeamScopeSql} from '../dashboard-scope.js';

const r=Router();r.use(requireAuth,(req,res,next)=>hasNysaStaffIdentity(req.broker)?next():res.status(403).json({error:'CRM dashboards are restricted to NYSA staff'}));
registerBusinessLineRoutes(r,TARGET_METRICS);
const clean=v=>typeof v==='string'&&v.trim()?v.trim():null;
function filters(req,alias='l',dateColumn=`${alias}.created_at`){
  const params=[],scope=dashboardLeadScopeSql(alias,req.broker,params),where=[`(${scope.clause})`],add=(sql,v)=>{params.push(v);where.push(sql.replace('?',`$${params.length}`));};
  const now=new Date(),end=req.query.dateTo?new Date(req.query.dateTo):now,start=req.query.dateFrom?new Date(req.query.dateFrom):new Date(end.getTime()-30*86400000);
  if(Number.isNaN(start.valueOf())||Number.isNaN(end.valueOf())||start>end)return {error:'Invalid date range'};
  add(`${dateColumn}>=?`,start);add(`${dateColumn}<?`,new Date(end.getTime()+86400000));
  if(req.query.businessLineId){if(req.query.businessLineId==='unassigned')where.push(`${businessLineAtSql(`${alias}.assigned_team_id`,`${alias}.created_at`)} IS NULL`);else add(businessLineFilterSql(`${alias}.assigned_team_id`,`${alias}.created_at`,'?'),req.query.businessLineId);}
  if(req.query.source)add(`${alias}.source=?`,req.query.source);if(req.query.teamId==='unassigned')where.push(`${alias}.assigned_team_id IS NULL`);else if(req.query.teamId)add(`${alias}.assigned_team_id=?`,req.query.teamId);
  if(req.query.campaignCode)add(`${alias}.campaign_code=?`,req.query.campaignCode);
  if(req.query.managerId)add(`${alias}.assigned_team_id IN (SELECT id FROM teams WHERE manager_id=?)`,req.query.managerId);
  if(req.query.agentId==='unassigned')where.push(`${alias}.assigned_to IS NULL`);else if(req.query.agentId)add(`${alias}.assigned_to=?`,req.query.agentId);if(req.query.businessType)add(`${alias}.business_type=?`,req.query.businessType);if(req.query.stage)add(`${alias}.stage=?`,req.query.stage);
  return {params,where:where.join(' AND '),start,end,selected:{businessLineId:req.query.businessLineId||null,dateFrom:start.toISOString().slice(0,10),dateTo:end.toISOString().slice(0,10),source:req.query.source||null,campaignCode:req.query.campaignCode||null,teamId:req.query.teamId||null,managerId:req.query.managerId||null,agentId:req.query.agentId||null,businessType:req.query.businessType||null,stage:req.query.stage||null}};
}
async function relevantDashboardTargets(req,selected){
 const rows=await many("SELECT *,period_start::text AS period_start,period_end::text AS period_end,CASE WHEN scope_type='team' THEN (SELECT name FROM teams WHERE id::text=scope_id) WHEN scope_type='agent' THEN (SELECT name FROM brokers WHERE id::text=scope_id) WHEN scope_type='business_line' THEN COALESCE((SELECT name FROM business_lines WHERE id::text=scope_id),scope_id) ELSE COALESCE(scope_id,'All NYSA') END AS scope_name FROM dashboard_targets WHERE (status='active' OR (status='retired' AND benchmark_source IS DISTINCT FROM 'CORE Release 1 test benchmark')) AND period_start<=$1 AND (period_end IS NULL OR period_end>=$2) ORDER BY created_at,id",[selected.dateTo,selected.dateFrom]);
 let teams=[];if(req.broker.jobRole==='manager'){const params=[],scope=dashboardTeamScopeSql('t.id',req.broker,params);teams=(await many('SELECT t.id FROM teams t WHERE '+scope.clause,params)).map(t=>t.id);}
 const managedAgents=req.broker.jobRole==='manager'?(await many('SELECT id FROM brokers WHERE team_id=ANY($1::uuid[])',[teams])).map(b=>b.id):[];
 return rows.filter(t=>{
  if(['sales_agent','listing_agent'].includes(req.broker.jobRole))return t.scopeType==='agent'&&t.scopeId===req.broker.id&&(!selected.agentId||selected.agentId===req.broker.id)&&!selected.businessLineId;
  if(t.scopeType==='agent')return !selected.businessLineId&& t.scopeId===selected.agentId&&(isCompanyReader(req.broker)||managedAgents.includes(t.scopeId));
  if(t.scopeType==='team')return !selected.businessLineId&&!selected.agentId&&(isCompanyReader(req.broker)?t.scopeId===selected.teamId:teams.includes(t.scopeId)&&(!selected.teamId||t.scopeId===selected.teamId));
  if(t.scopeType==='business_line')return isCompanyReader(req.broker)&&!selected.teamId&&!selected.agentId&&t.scopeId===selected.businessLineId;
  return isCompanyReader(req.broker)&&!selected.businessLineId&&!selected.businessType&&!selected.teamId&&!selected.agentId;
 }).map(t=>({...t,scopeMatchesDashboard:t.scopeType!=='team'||Boolean(selected.teamId)||teams.length===1}));
}
function priorWhere(base,alias='l',dateColumn=`${alias}.created_at`){const days=Math.max(1,Math.ceil((base.end-base.start)/86400000)+1),end=new Date(base.start.getTime()-1),start=new Date(end.getTime()-(days-1)*86400000);const params=[],scope=dashboardLeadScopeSql(alias,base.broker,params),where=[`(${scope.clause})`],add=(sql,v)=>{params.push(v);where.push(sql.replace('?',`$${params.length}`));};add(`${dateColumn}>=?`,start);add(`${dateColumn}<?`,new Date(base.start));if(base.selected.businessLineId){if(base.selected.businessLineId==='unassigned')where.push(`${businessLineAtSql(`${alias}.assigned_team_id`,`${alias}.created_at`)} IS NULL`);else add(businessLineFilterSql(`${alias}.assigned_team_id`,`${alias}.created_at`,'?'),base.selected.businessLineId);}if(base.selected.source)add(`${alias}.source=?`,base.selected.source);if(base.selected.campaignCode)add(`${alias}.campaign_code=?`,base.selected.campaignCode);if(base.selected.teamId==='unassigned')where.push(`${alias}.assigned_team_id IS NULL`);else if(base.selected.teamId)add(`${alias}.assigned_team_id=?`,base.selected.teamId);if(base.selected.managerId)add(`${alias}.assigned_team_id IN (SELECT id FROM teams WHERE manager_id=?)`,base.selected.managerId);if(base.selected.agentId==='unassigned')where.push(`${alias}.assigned_to IS NULL`);else if(base.selected.agentId)add(`${alias}.assigned_to=?`,base.selected.agentId);if(base.selected.businessType)add(`${alias}.business_type=?`,base.selected.businessType);if(base.selected.stage)add(`${alias}.stage=?`,base.selected.stage);return {where:where.join(' AND '),params,start,end};}

const opportunityPipelineStageSql=alias=>`CASE ${alias}.stage
  WHEN 'Requirements' THEN 'Qualified' WHEN 'Matching' THEN 'Qualified'
  WHEN 'Viewing' THEN 'Viewing' WHEN 'Offer' THEN 'Offer' WHEN 'Negotiation' THEN 'Negotiation'
  WHEN 'Booking' THEN 'Booking' WHEN 'Deal' THEN 'Deal'
  WHEN 'Closed Won' THEN 'Won' WHEN 'Closed Lost' THEN 'Lost' ELSE 'Qualified' END`;
const leadOnlyPipelineStageSql=`CASE
  WHEN l.current_status='closed_won' OR l.stage='Won' THEN 'Won'
  WHEN l.current_status='closed_lost' OR l.stage='Lost' THEN 'Lost'
  WHEN l.stage='New' AND l.first_contact_at IS NULL THEN 'New'
  WHEN l.stage IN ('New','Contacted') THEN 'Contacted' ELSE 'Qualified' END`;

async function loadOpportunityPipelineCounts(broker,f){
  const opportunityParams=[...f.params],opportunityScope=opportunityScopeSql('o',broker,opportunityParams);
  const opportunityRows=await many(`SELECT ${opportunityPipelineStageSql('o')} AS label,COUNT(*)::int AS value
    FROM opportunities o JOIN leads l ON l.id=o.lead_id
    WHERE ${f.where} AND (${opportunityScope.clause}) GROUP BY ${opportunityPipelineStageSql('o')}`,opportunityParams);
  const leadParams=[...f.params],childScope=opportunityScopeSql('child_o',broker,leadParams);
  const leadRows=await many(`SELECT ${leadOnlyPipelineStageSql} AS label,COUNT(*)::int AS value FROM leads l
    WHERE ${f.where} AND NOT EXISTS(SELECT 1 FROM opportunities child_o WHERE child_o.lead_id=l.id AND (${childScope.clause}))
    GROUP BY ${leadOnlyPipelineStageSql}`,leadParams);
  const counts=new Map();for(const row of [...leadRows,...opportunityRows])counts.set(row.label,(counts.get(row.label)||0)+Number(row.value||0));
  return [...counts].map(([label,value])=>({label,value}));
}

function dashboardRecordResult(req,payload){
  const pageSize=Math.max(1,Math.min(500,Number.parseInt(req.query.pageSize,10)||100)),count=Number(payload.records[0]?.dashboardTotal??payload.records.length),pages=Math.max(1,Math.ceil(count/pageSize)),page=Math.max(1,Math.min(pages,Number.parseInt(req.query.page,10)||1));
  const paged=payload.records[0]?.dashboardTotal!==undefined,rows=paged?payload.records:payload.records.slice((page-1)*pageSize,page*pageSize);
  return {...payload,count,page,pageSize,pages,records:rows.map(({dashboardTotal,dashboardOrdinal,...row})=>row)};
}
async function dashboardPageRows(req,sql,params=[]){
  const size=Math.max(1,Math.min(500,Number.parseInt(req.query.pageSize,10)||100)),requested=Math.max(1,Number.parseInt(req.query.page,10)||1);
  const query=page=>many(`SELECT result.*,COUNT(*) OVER()::int AS dashboard_total,ROW_NUMBER() OVER() AS dashboard_ordinal FROM (${sql}) result ORDER BY dashboard_ordinal LIMIT $${params.length+1} OFFSET $${params.length+2}`,[...params,size,(page-1)*size]);
  let rows=await query(requested);if(!rows.length&&requested>1){const total=(await one(`SELECT COUNT(*)::int AS count FROM (${sql}) result`,params)).count;rows=await query(Math.max(1,Math.ceil(total/size)));}
  return rows;
}

async function loadOpportunityPipelineRecords(broker,f,stage,req){
  const opportunityParams=[...f.params],opportunityScope=opportunityScopeSql('o',broker,opportunityParams);
  const opportunityQuery=`SELECT l.id,l.lead_reference,l.current_status,l.title,l.source,l.business_type,l.stage,l.temperature,
    o.created_at,o.next_action_due_at AS next_follow_up_at,c.full_name AS contact_name,t.id AS team_id,t.name AS team_name,
    m.id AS manager_id,m.name AS manager_name,b.id AS agent_id,b.name AS agent_name,${opportunityPipelineStageSql('o')} AS pipeline_stage,
    o.id AS pipeline_opportunity_id,o.opportunity_reference
    FROM opportunities o JOIN leads l ON l.id=o.lead_id JOIN contacts c ON c.id=l.contact_id
    LEFT JOIN teams t ON t.id=o.assigned_team_id LEFT JOIN brokers m ON m.id=t.manager_id LEFT JOIN brokers b ON b.id=o.owner_id
    WHERE ${f.where} AND (${opportunityScope.clause}) AND (${opportunityPipelineStageSql('o')})=$${opportunityParams.length+1}
    ORDER BY o.created_at DESC`;
  const leadParams=[...f.params],childScope=opportunityScopeSql('child_o',broker,leadParams);
  const leadQuery=`SELECT l.id,l.lead_reference,l.current_status,l.title,l.source,l.business_type,l.stage,l.temperature,l.created_at,l.next_follow_up_at,
    c.full_name AS contact_name,t.id AS team_id,t.name AS team_name,m.id AS manager_id,m.name AS manager_name,b.id AS agent_id,b.name AS agent_name,
    ${leadOnlyPipelineStageSql} AS pipeline_stage,NULL::uuid AS pipeline_opportunity_id,NULL::text AS opportunity_reference
    FROM leads l JOIN contacts c ON c.id=l.contact_id LEFT JOIN teams t ON t.id=l.assigned_team_id LEFT JOIN brokers m ON m.id=t.manager_id LEFT JOIN brokers b ON b.id=l.assigned_to
    WHERE ${f.where} AND NOT EXISTS(SELECT 1 FROM opportunities child_o WHERE child_o.lead_id=l.id AND (${childScope.clause}))
      AND (${leadOnlyPipelineStageSql})=$${leadParams.length+1} ORDER BY l.created_at DESC`;
  const firstParams=[...opportunityParams,stage],secondQuery=leadQuery.replace(/\$(\d+)/g,(_,index)=>'$'+(Number(index)+firstParams.length));
  return dashboardPageRows(req,'SELECT * FROM (('+opportunityQuery+') UNION ALL ('+secondQuery+')) pipeline_records ORDER BY created_at DESC,pipeline_opportunity_id,id',[...firstParams,...leadParams,stage]);
}

async function loadProposalApprovalQueue(req,selected={},search='',page=1,pageSize=20){
  if(!isProposalApprover(req.broker))return {rows:[],count:0,page:1,pageSize};
  const params=[],scope=proposalApprovalScopeSql('l',req.broker,params),where=[`(${scope.clause})`,`v.status='generated'`,`v.version_number=(SELECT MAX(latest.version_number) FROM proposal_versions latest WHERE latest.proposal_id=v.proposal_id)`],add=(sql,value)=>{params.push(value);where.push(sql.replace('?',`$${params.length}`));};
  if(selected.businessLineId){if(selected.businessLineId==='unassigned')where.push(`${businessLineAtSql('l.assigned_team_id','l.created_at')} IS NULL`);else add(businessLineFilterSql('l.assigned_team_id','l.created_at','?'),selected.businessLineId);}
  if(selected.teamId==='unassigned')where.push('l.assigned_team_id IS NULL');else if(selected.teamId)add('l.assigned_team_id=?',selected.teamId);
  if(selected.managerId)add('l.assigned_team_id IN (SELECT id FROM teams WHERE manager_id=?)',selected.managerId);
  if(selected.agentId==='unassigned')where.push('l.assigned_to IS NULL');else if(selected.agentId)add('l.assigned_to=?',selected.agentId);
  if(selected.businessType)add('l.business_type=?',selected.businessType);
  if(search){params.push(`%${search}%`);const key=`$${params.length}`;where.push(`(c.full_name ILIKE ${key} OR l.title ILIKE ${key} OR p.proposal_number ILIKE ${key} OR p.title ILIKE ${key} OR p.template_type ILIKE ${key} OR COALESCE(t.name,'') ILIKE ${key} OR COALESCE(creator.name,'') ILIKE ${key} OR ('Version '||v.version_number::text) ILIKE ${key} OR 'pending approval' ILIKE ${key} OR 'awaiting review' ILIKE ${key} OR TO_CHAR(v.created_at AT TIME ZONE 'Asia/Dubai','DD Mon YYYY HH24:MI') ILIKE ${key})`);}
  const from=`FROM proposal_versions v JOIN proposals p ON p.id=v.proposal_id JOIN leads l ON l.id=p.lead_id JOIN contacts c ON c.id=p.contact_id LEFT JOIN teams t ON t.id=l.assigned_team_id LEFT JOIN brokers creator ON creator.id=v.created_by WHERE ${where.join(' AND ')}`;
  const safePage=Math.max(1,Number(page)||1),safeSize=Math.max(10,Math.min(50,Number(pageSize)||20)),offset=(safePage-1)*safeSize,count=(await one(`SELECT COUNT(*)::int AS count ${from}`,params)).count,rowParams=[...params,safeSize,offset],rows=await many(`SELECT v.id AS version_id,v.version_number,v.document_version_id,v.created_at,p.id AS proposal_id,p.proposal_number,p.title AS proposal_title,p.template_type,l.id AS lead_id,l.title AS lead_title,l.business_type,c.full_name AS customer_name,t.name AS team_name,creator.name AS requested_by ${from} ORDER BY v.created_at DESC,v.id DESC LIMIT $${params.length+1} OFFSET $${params.length+2}`,rowParams);
  return {rows,count,page:safePage,pageSize:safeSize};
}

async function loadOrganizationContext(broker,type){
  if(broker.jobRole==='director')return {contextVersion:3,kind:'director',supervisors:[],reports:await many(`SELECT m.id AS person_id,m.name AS person_name,t.id AS unit_id,t.name AS unit_name
    FROM brokers m LEFT JOIN teams t ON t.manager_id=m.id AND t.active=1 WHERE m.reports_to_id=$1 AND m.status='active' AND m.job_role='manager' ORDER BY t.name,m.name`,[broker.id])};
  if(type==='manager'){const [directors,reports]=await Promise.all([many(`SELECT director.id AS person_id,director.name AS person_name,NULL::uuid AS unit_id,'NYSA CORE' AS unit_name
      FROM brokers manager JOIN brokers director ON director.id=manager.reports_to_id WHERE manager.id=$1 AND director.status='active' AND director.job_role='director'`,[broker.id]),many(`SELECT b.id AS person_id,b.name AS person_name,t.id AS unit_id,t.name AS unit_name
    FROM teams t JOIN brokers b ON b.team_id=t.id AND b.status='active' AND b.role='internal_broker' AND b.job_role IN ('sales_agent','listing_agent')
    WHERE t.active=1 AND (t.manager_id=$1 OR EXISTS(SELECT 1 FROM team_memberships tm WHERE tm.team_id=t.id AND tm.broker_id=$1 AND tm.membership_role='manager' AND tm.ends_at IS NULL)
      OR EXISTS(SELECT 1 FROM user_role_assignments ur WHERE ur.team_id=t.id AND ur.broker_id=$1 AND ur.job_role='manager' AND ur.status='active' AND ur.ends_at IS NULL))
    ORDER BY t.name,b.name`,[broker.id])]);return {contextVersion:3,kind:'manager',supervisors:directors,reports};}
  if(type==='agent'){const row=await one(`SELECT m.id AS person_id,m.name AS person_name,t.id AS unit_id,t.name AS unit_name
    FROM brokers b
    LEFT JOIN LATERAL (SELECT team.id,team.name,team.manager_id FROM teams team WHERE team.active=1 AND team.id=COALESCE(b.team_id,
      (SELECT ur.team_id FROM user_role_assignments ur WHERE ur.broker_id=b.id AND ur.is_primary=1 AND ur.status='active' AND ur.ends_at IS NULL AND ur.team_id IS NOT NULL ORDER BY ur.starts_at DESC LIMIT 1),
      (SELECT tm.team_id FROM team_memberships tm WHERE tm.broker_id=b.id AND tm.ends_at IS NULL ORDER BY tm.created_at DESC LIMIT 1)) LIMIT 1) t ON TRUE
    LEFT JOIN brokers m ON m.id=t.manager_id WHERE b.id=$1`,[broker.id]);return {contextVersion:3,kind:'agent',supervisors:row?[row]:[],reports:[]};}
  return {contextVersion:3,kind:'governance',supervisors:[],reports:[]};
}

r.get('/crm/dashboard/filter-options',async(req,res)=>{
  const params=[],scope=agentWorkLeadScopeSql('l',req.broker,params),where=[`(${scope.clause})`,`l.campaign_code IS NOT NULL`,`BTRIM(l.campaign_code)<>''`];
  if(req.query.source){params.push(req.query.source);where.push(`l.source=$${params.length}`);}
  const campaigns=await many(`SELECT l.campaign_code AS value,l.campaign_code AS label,COUNT(*)::int AS lead_count FROM leads l WHERE ${where.join(' AND ')} GROUP BY l.campaign_code ORDER BY l.campaign_code`,params);
  res.json({campaigns});
});

async function renderDashboardData(req,res){
  const f=filters(req);if(f.error)return res.status(400).json({error:f.error});
  const proposalF=filters(req,'l','p.updated_at'),callF=filters(req,'l','a.created_at');
  const inventoryScope=dashboardTeamScopeSql('(SELECT dashboard_owner.team_id FROM brokers dashboard_owner WHERE dashboard_owner.id=listings.posted_by)',req.broker,[]);
  if(f.selected.businessLineId){inventoryScope.params.push(f.selected.businessLineId);inventoryScope.clause+=` AND ${f.selected.businessLineId==='unassigned'?businessLineAtSql('(SELECT bl_owner.team_id FROM brokers bl_owner WHERE bl_owner.id=listings.posted_by)','listings.created_at')+' IS NULL':businessLineFilterSql('(SELECT bl_owner.team_id FROM brokers bl_owner WHERE bl_owner.id=listings.posted_by)','listings.created_at','$'+inventoryScope.params.length)}`;if(f.selected.businessLineId==='unassigned')inventoryScope.params.pop();if(['sales_agent','listing_agent'].includes(req.broker.jobRole)){inventoryScope.params.push(req.broker.id);inventoryScope.clause+=` AND listings.posted_by=$${inventoryScope.params.length}`;}}
  f.broker=req.broker;proposalF.broker=req.broker;callF.broker=req.broker;
  const prior=priorWhere(f),priorProposal=priorWhere(proposalF,'l','p.updated_at'),priorCall=priorWhere(callF,'l','a.created_at'),type=dashboardTypeFor(req.broker),canSeeIntegration=isCompanyReader(req.broker)&&!f.selected.businessLineId;
  const [current,previous,stages,sources,priorSources,campaigns,teams,agents,trend,tasks,exceptions,previousExceptions,proposals,calls,priorProposals,priorCalls,priorAgents,inventory,targets,hierarchyRows,accountabilityRows,integrationFailures,previousIntegrationFailures]=await Promise.all([
    one(`SELECT COUNT(*)::int AS leads,COUNT(DISTINCT contact_id)::int AS customers,COUNT(*) FILTER(WHERE temperature='Hot' AND current_status='active')::int AS hot,COUNT(*) FILTER(WHERE temperature='Warm' AND current_status='active')::int AS warm,
      COUNT(*) FILTER(WHERE temperature='Warm' AND current_status='active' AND EXISTS(SELECT 1 FROM opportunities o WHERE o.lead_id=l.id AND o.stage NOT IN ('Closed Won','Closed Lost')))::int AS warm_converted,
      COUNT(*) FILTER(WHERE temperature='Warm' AND current_status='active' AND NOT EXISTS(SELECT 1 FROM opportunities o WHERE o.lead_id=l.id AND o.stage NOT IN ('Closed Won','Closed Lost')) AND stage NOT IN('Lost'))::int AS warm_pending,
      COUNT(*) FILTER(WHERE temperature='Hot' AND current_status='active' AND EXISTS(SELECT 1 FROM opportunities o WHERE o.lead_id=l.id AND o.stage NOT IN ('Closed Won','Closed Lost')))::int AS hot_converted,
      COUNT(*) FILTER(WHERE current_status='closed_won')::int AS won,COUNT(*) FILTER(WHERE accepted_at IS NULL AND acceptance_due_at<NOW())::int AS acceptance_breaches,
      COUNT(*) FILTER(WHERE accepted_at IS NOT NULL AND first_contact_at IS NULL AND first_contact_due_at<NOW())::int AS contact_breaches,
      COUNT(*) FILTER(WHERE stage NOT IN('Won','Lost') AND accepted_at IS NULL)::int AS awaiting_acceptance,
      COUNT(*) FILTER(WHERE stage NOT IN('Won','Lost') AND ((accepted_at IS NULL AND acceptance_due_at BETWEEN NOW() AND NOW()+INTERVAL '60 minutes') OR
        (accepted_at IS NOT NULL AND first_contact_at IS NULL AND first_contact_due_at BETWEEN NOW() AND NOW()+INTERVAL '60 minutes')))::int AS sla_risk,
      COUNT(*) FILTER(WHERE next_follow_up_at IS NULL AND current_status='active' AND stage NOT IN('Won','Lost'))::int AS no_next_action,
      COUNT(*) FILTER(WHERE assigned_to IS NULL AND stage NOT IN('Won','Lost'))::int AS unassigned,
      COUNT(*) FILTER(WHERE updated_at<NOW()-INTERVAL '7 days' AND stage NOT IN('Won','Lost'))::int AS stale_risk,
      COUNT(*) FILTER(WHERE temperature IN('Hot','Warm') AND current_status='active' AND updated_at<NOW()-INTERVAL '7 days' AND stage NOT IN('Won','Lost'))::int AS hot_warm_aging,
      COUNT(*) FILTER(WHERE stage NOT IN('Won','Lost'))::int AS open FROM leads l WHERE ${f.where}`,f.params),
    one(`SELECT COUNT(*)::int AS leads,COUNT(*) FILTER(WHERE temperature='Hot' AND current_status='active')::int AS hot,COUNT(*) FILTER(WHERE temperature='Warm' AND current_status='active')::int AS warm,
      COUNT(*) FILTER(WHERE current_status='closed_won')::int AS won,COUNT(*) FILTER(WHERE accepted_at IS NULL AND acceptance_due_at<NOW())::int AS acceptance_breaches,
      COUNT(*) FILTER(WHERE accepted_at IS NOT NULL AND first_contact_at IS NULL AND first_contact_due_at<NOW())::int AS contact_breaches,
      COUNT(*) FILTER(WHERE next_follow_up_at IS NULL AND current_status='active' AND stage NOT IN('Won','Lost'))::int AS no_next_action,
      COUNT(*) FILTER(WHERE assigned_to IS NULL AND stage NOT IN('Won','Lost'))::int AS unassigned,
      COUNT(*) FILTER(WHERE stage NOT IN('Won','Lost') AND ((accepted_at IS NULL AND acceptance_due_at BETWEEN NOW() AND NOW()+INTERVAL '60 minutes') OR (accepted_at IS NOT NULL AND first_contact_at IS NULL AND first_contact_due_at BETWEEN NOW() AND NOW()+INTERVAL '60 minutes')))::int AS sla_risk,
      COUNT(*) FILTER(WHERE updated_at<NOW()-INTERVAL '7 days' AND stage NOT IN('Won','Lost'))::int AS stale_risk FROM leads l WHERE ${prior.where}`,prior.params),
    many(`SELECT stage AS label,COUNT(*)::int AS value FROM leads l WHERE ${f.where} GROUP BY stage ORDER BY value DESC`,f.params),
    many(`SELECT source AS label,source AS id,COUNT(*)::int AS value,COUNT(*) FILTER(WHERE stage='Won')::int AS won FROM leads l WHERE ${f.where} GROUP BY source ORDER BY value DESC`,f.params),
    many(`SELECT source AS label,source AS id,COUNT(*)::int AS value,COUNT(*) FILTER(WHERE stage='Won')::int AS won FROM leads l WHERE ${prior.where} GROUP BY source ORDER BY value DESC`,prior.params),
    many(`SELECT COALESCE(campaign_code,'Unattributed') AS label,campaign_code AS id,COUNT(*)::int AS value,COUNT(*) FILTER(WHERE stage='Won')::int AS won FROM leads l WHERE ${f.where} GROUP BY campaign_code ORDER BY value DESC`,f.params),
    many(`SELECT COALESCE(t.name,'Unassigned') AS label,l.assigned_team_id AS id,t.manager_id,COUNT(*)::int AS value,
      COUNT(*) FILTER(WHERE l.stage='Won')::int AS won,COUNT(*) FILTER(WHERE l.stage NOT IN('Won','Lost'))::int AS open,
      COUNT(DISTINCT l.assigned_to) FILTER(WHERE l.assigned_to IS NOT NULL)::int AS agents FROM leads l LEFT JOIN teams t ON t.id=l.assigned_team_id WHERE ${f.where} GROUP BY t.name,l.assigned_team_id,t.manager_id ORDER BY value DESC`,f.params),
    many(`SELECT COALESCE(b.name,'Unassigned') AS label,l.assigned_to AS id,l.assigned_team_id AS team_id,COUNT(*)::int AS value,COUNT(*) FILTER(WHERE l.stage='Won')::int AS won,
      COUNT(*) FILTER(WHERE l.stage NOT IN('Won','Lost'))::int AS open,COUNT(*) FILTER(WHERE l.next_follow_up_at<NOW() AND l.stage NOT IN('Won','Lost'))::int AS overdue,
      COUNT(*) FILTER(WHERE l.accepted_at IS NULL AND l.acceptance_due_at<NOW())::int AS sla_breaches FROM leads l LEFT JOIN brokers b ON b.id=l.assigned_to WHERE ${f.where} GROUP BY b.name,l.assigned_to,l.assigned_team_id ORDER BY value DESC`,f.params),
    many(`SELECT DATE_TRUNC('week',l.created_at)::date AS period,COUNT(*)::int AS value FROM leads l WHERE ${f.where} GROUP BY period ORDER BY period`,f.params),
    many(`SELECT CASE WHEN t.status='completed' THEN 'completed' WHEN t.status='cancelled' THEN 'cancelled' WHEN t.due_at<NOW() THEN 'overdue' WHEN t.due_at<CURRENT_DATE+INTERVAL '1 day' THEN 'today' ELSE 'upcoming' END AS label,COUNT(*)::int AS value
      FROM tasks t JOIN leads l ON l.id=t.lead_id WHERE ${f.where} GROUP BY label`,f.params),
    one(`SELECT COUNT(*) FILTER(WHERE (c.email IS NULL AND c.phone IS NULL))::int AS missing_contact,
      COUNT(*) FILTER(WHERE NOT EXISTS(SELECT 1 FROM lead_requirements q WHERE q.lead_id=l.id AND q.superseded_at IS NULL))::int AS missing_requirement,
      COUNT(*) FILTER(WHERE c.do_not_contact=1)::int AS restricted_contact,
      COUNT(*) FILTER(WHERE EXISTS(SELECT 1 FROM contact_channels cc JOIN contact_channels dc ON dc.channel_kind=cc.channel_kind AND dc.normalized_value=cc.normalized_value AND dc.contact_id<>cc.contact_id WHERE cc.contact_id=c.id AND cc.normalized_value IS NOT NULL))::int AS duplicate_contact,
      COUNT(*) FILTER(WHERE c.do_not_contact=0 AND NOT EXISTS(SELECT 1 FROM marketing_agreements ma WHERE ma.contact_id=c.id AND ma.status='executed' AND ma.effective_at<=NOW() AND (ma.expires_at IS NULL OR ma.expires_at>NOW())))::int AS missing_consent,
      COUNT(*) FILTER(WHERE NOT EXISTS(SELECT 1 FROM documents d WHERE d.lead_id=l.id AND d.status<>'retired'))::int AS missing_document,
      0::int AS integration_failures
      FROM leads l JOIN contacts c ON c.id=l.contact_id WHERE ${f.where}`,f.params),
    one(`SELECT COUNT(*) FILTER(WHERE (c.email IS NULL AND c.phone IS NULL))::int AS missing_contact,
      COUNT(*) FILTER(WHERE NOT EXISTS(SELECT 1 FROM lead_requirements q WHERE q.lead_id=l.id AND q.superseded_at IS NULL))::int AS missing_requirement,
      COUNT(*) FILTER(WHERE c.do_not_contact=1)::int AS restricted_contact,
      COUNT(*) FILTER(WHERE EXISTS(SELECT 1 FROM contact_channels cc JOIN contact_channels dc ON dc.channel_kind=cc.channel_kind AND dc.normalized_value=cc.normalized_value AND dc.contact_id<>cc.contact_id WHERE cc.contact_id=c.id AND cc.normalized_value IS NOT NULL))::int AS duplicate_contact,
      COUNT(*) FILTER(WHERE c.do_not_contact=0 AND NOT EXISTS(SELECT 1 FROM marketing_agreements ma WHERE ma.contact_id=c.id AND ma.status='executed' AND ma.effective_at<=NOW() AND (ma.expires_at IS NULL OR ma.expires_at>NOW())))::int AS missing_consent,
      COUNT(*) FILTER(WHERE NOT EXISTS(SELECT 1 FROM documents d WHERE d.lead_id=l.id AND d.status<>'retired'))::int AS missing_document,
      0::int AS integration_failures FROM leads l JOIN contacts c ON c.id=l.contact_id WHERE ${prior.where}`,prior.params),
    one(`SELECT COUNT(*)::int AS total,COUNT(*) FILTER(WHERE p.status='draft')::int AS prepare,COUNT(*) FILTER(WHERE p.status='generated')::int AS review,
      COUNT(*) FILTER(WHERE p.status='reviewed')::int AS send,COUNT(*) FILTER(WHERE p.status='sent')::int AS sent FROM proposals p JOIN leads l ON l.id=p.lead_id WHERE ${proposalF.where}`,proposalF.params),
    one(`SELECT COUNT(*)::int AS total,COALESCE(SUM(a.duration_seconds),0)::int AS duration_seconds,COUNT(*) FILTER(WHERE a.follow_up_required=1)::int AS follow_up_required
      FROM activities a JOIN leads l ON l.id=a.lead_id WHERE a.activity_type='Call' AND ${callF.where}`,callF.params),
    one(`SELECT COUNT(*)::int AS total,COUNT(*) FILTER(WHERE p.status='draft')::int AS prepare,COUNT(*) FILTER(WHERE p.status='generated')::int AS review,
      COUNT(*) FILTER(WHERE p.status='reviewed')::int AS send,COUNT(*) FILTER(WHERE p.status='sent')::int AS sent FROM proposals p JOIN leads l ON l.id=p.lead_id WHERE ${priorProposal.where}`,priorProposal.params),
    one(`SELECT COUNT(*)::int AS total FROM activities a JOIN leads l ON l.id=a.lead_id WHERE a.activity_type='Call' AND ${priorCall.where}`,priorCall.params),
    many(`SELECT l.assigned_to AS id,COUNT(*) FILTER(WHERE l.stage NOT IN('Won','Lost'))::int AS open FROM leads l WHERE ${prior.where} GROUP BY l.assigned_to`,prior.params),
    one(`SELECT COUNT(*)::int AS total,COUNT(*) FILTER(WHERE nysa_inventory_effective_status(id)='Available')::int AS available,
      COUNT(*) FILTER(WHERE nysa_inventory_effective_status(id)='Reserved')::int AS reserved,
      COUNT(*) FILTER(WHERE updated_at<NOW()-INTERVAL '30 days' AND nysa_inventory_effective_status(id) NOT IN('Closed','Sold','Rented'))::int AS stale,
      COUNT(*) FILTER(WHERE updated_at<NOW()-INTERVAL '60 days' AND nysa_inventory_effective_status(id) NOT IN('Closed','Sold','Rented'))::int AS stale60,
      COUNT(*) FILTER(WHERE updated_at<NOW()-INTERVAL '90 days' AND nysa_inventory_effective_status(id) NOT IN('Closed','Sold','Rented'))::int AS stale90,
      COUNT(*) FILTER(WHERE nysa_inventory_effective_status(id) NOT IN('Closed','Sold','Rented') AND (availability_confirmed_at IS NULL OR availability_confirmed_at<NOW()-INTERVAL '7 days'))::int AS availability_unconfirmed,
      COUNT(*) FILTER(WHERE nysa_inventory_effective_status(id) NOT IN('Closed','Sold','Rented') AND permit_expires_at IS NOT NULL AND permit_expires_at<NOW()+INTERVAL '30 days')::int AS permit_exposure,
      COUNT(*) FILTER(WHERE nysa_inventory_effective_status(id) NOT IN('Closed','Sold','Rented') AND (verification_status NOT IN('verified','not_required') OR verification_expires_at<NOW()+INTERVAL '30 days'))::int AS verification_exposure,
      COUNT(*) FILTER(WHERE nysa_inventory_effective_status(id) NOT IN('Closed','Sold','Rented') AND portal_status NOT IN('ready','published'))::int AS portal_not_ready,
      COUNT(*) FILTER(WHERE NOT EXISTS(SELECT 1 FROM property_media m WHERE m.listing_id=listings.id AND m.approval_status='approved' AND m.usage_rights_confirmed=TRUE AND (m.rights_expires_at IS NULL OR m.rights_expires_at>NOW())))::int AS media_not_ready,
      COUNT(*) FILTER(WHERE nysa_inventory_effective_status(id) NOT IN('Closed','Sold','Rented') AND (updated_at<NOW()-INTERVAL '30 days' OR availability_confirmed_at IS NULL OR availability_confirmed_at<NOW()-INTERVAL '7 days'))::int AS aging_exposure,
      COUNT(*) FILTER(WHERE nysa_inventory_effective_status(id) NOT IN('Closed','Sold','Rented') AND ((permit_expires_at IS NOT NULL AND permit_expires_at<NOW()+INTERVAL '30 days') OR verification_status NOT IN('verified','not_required') OR verification_expires_at<NOW()+INTERVAL '30 days' OR NOT EXISTS(SELECT 1 FROM property_media m WHERE m.listing_id=listings.id AND m.approval_status='approved' AND m.usage_rights_confirmed=TRUE AND (m.rights_expires_at IS NULL OR m.rights_expires_at>NOW()))))::int AS compliance_exposure,
      COUNT(*) FILTER(WHERE nysa_inventory_effective_status(id) NOT IN('Closed','Sold','Rented') AND (availability_confirmed_at IS NULL OR availability_confirmed_at<NOW()-INTERVAL '7 days' OR (permit_expires_at IS NOT NULL AND permit_expires_at<NOW()+INTERVAL '30 days') OR verification_status NOT IN('verified','not_required') OR verification_expires_at<NOW()+INTERVAL '30 days' OR portal_status NOT IN('ready','published') OR NOT EXISTS(SELECT 1 FROM property_media m WHERE m.listing_id=listings.id AND m.approval_status='approved' AND m.usage_rights_confirmed=TRUE AND (m.rights_expires_at IS NULL OR m.rights_expires_at>NOW()))))::int AS readiness_exposure FROM listings WHERE deleted_at IS NULL AND ${inventoryScope.clause}`,inventoryScope.params),
    relevantDashboardTargets(req,f.selected),
    many(`SELECT COALESCE(bl.name,'Business line not assigned') AS business_type,bl.id AS business_line_id,COALESCE(t.name,'Unassigned') AS team_name,l.assigned_team_id AS team_id,t.manager_id,COALESCE(m.name,'No manager') AS manager_name,COALESCE(b.name,'Unassigned') AS agent_name,l.assigned_to AS agent_id,COUNT(*)::int AS value FROM leads l LEFT JOIN teams t ON t.id=l.assigned_team_id LEFT JOIN brokers m ON m.id=t.manager_id LEFT JOIN brokers b ON b.id=l.assigned_to LEFT JOIN LATERAL (SELECT line.id,line.name FROM team_business_line_assignments a LEFT JOIN business_lines line ON line.id=a.business_line_id WHERE a.team_id=l.assigned_team_id AND a.effective_from<=(l.created_at AT TIME ZONE 'Asia/Dubai')::date ORDER BY a.effective_from DESC LIMIT 1) bl ON TRUE WHERE ${f.where} GROUP BY bl.id,bl.name,t.name,l.assigned_team_id,t.manager_id,m.name,b.name,l.assigned_to ORDER BY business_type,t.name,m.name,b.name`,f.params),
    many(`SELECT l.business_type,t.name AS team_name,m.name AS manager_name,b.name AS agent_name,
      COUNT(*) FILTER(WHERE (l.accepted_at IS NULL AND l.acceptance_due_at<NOW()) OR (l.accepted_at IS NOT NULL AND l.first_contact_at IS NULL AND l.first_contact_due_at<NOW()))::int AS sla_breaches,
      COUNT(*) FILTER(WHERE l.assigned_to IS NULL AND l.stage NOT IN('Won','Lost'))::int AS unassigned_leads,
      COUNT(*) FILTER(WHERE l.next_follow_up_at IS NULL AND l.current_status='active' AND l.stage NOT IN('Won','Lost'))::int AS no_next_action,
      COUNT(*) FILTER(WHERE l.updated_at<NOW()-INTERVAL '7 days' AND l.stage NOT IN('Won','Lost'))::int AS stale_risk,
      COUNT(*) FILTER(WHERE (c.email IS NULL AND c.phone IS NULL) OR c.do_not_contact=1 OR EXISTS(SELECT 1 FROM contact_channels cc JOIN contact_channels dc ON dc.channel_kind=cc.channel_kind AND dc.normalized_value=cc.normalized_value AND dc.contact_id<>cc.contact_id WHERE cc.contact_id=c.id AND cc.normalized_value IS NOT NULL) OR (c.do_not_contact=0 AND NOT EXISTS(SELECT 1 FROM marketing_agreements ma WHERE ma.contact_id=c.id AND ma.status='executed' AND ma.effective_at<=NOW() AND (ma.expires_at IS NULL OR ma.expires_at>NOW()))) OR NOT EXISTS(SELECT 1 FROM lead_requirements q WHERE q.lead_id=l.id AND q.superseded_at IS NULL) OR NOT EXISTS(SELECT 1 FROM documents d WHERE d.lead_id=l.id AND d.status<>'retired'))::int AS operational_exceptions
      FROM leads l JOIN contacts c ON c.id=l.contact_id LEFT JOIN teams t ON t.id=l.assigned_team_id LEFT JOIN brokers m ON m.id=t.manager_id LEFT JOIN brokers b ON b.id=l.assigned_to
      WHERE ${f.where} GROUP BY l.business_type,t.name,m.name,b.name`,f.params),
    canSeeIntegration?one("SELECT COUNT(*)::int AS count FROM website_intake_events WHERE status='failed' AND received_at>=$1 AND received_at<$2",[f.start,new Date(f.end.getTime()+86400000)]):Promise.resolve({count:0}),
    canSeeIntegration?one('SELECT COUNT(*)::int AS count FROM website_intake_events WHERE status=\'failed\' AND received_at>=$1 AND received_at<$2',[prior.start,new Date(f.start)]):Promise.resolve({count:0})
  ]);
  if(canSeeIntegration){exceptions.integrationFailures=integrationFailures.count;previousExceptions.integrationFailures=previousIntegrationFailures.count;}else{delete exceptions.integrationFailures;delete previousExceptions.integrationFailures;}
  const inventorySnapshotValues={inventory_available:Number(inventory.available||0),inventory_stale:Number(inventory.stale||0),inventory_readiness_exposure:Number(inventory.readinessExposure||0)};
  const previousInventoryRows=f.selected.businessLineId?[]:await many(`SELECT DISTINCT ON(metric_code) metric_code,value FROM dashboard_metric_snapshots WHERE scope_type='company' AND scope_id='' AND metric_code=ANY($1::text[]) AND snapshot_date<$2 ORDER BY metric_code,snapshot_date DESC`,[Object.keys(inventorySnapshotValues),f.start]);
  const previousInventory={...Object.fromEntries(previousInventoryRows.map(row=>[row.metricCode,Number(row.value)])),team_capacity_pressure:priorAgents.filter(agent=>agent.id&&Number(agent.open||0)>=10).length,proposal_workload:Number(priorProposals.prepare||0)+Number(priorProposals.review||0)+Number(priorProposals.send||0),customer_engagement:Number(priorCalls.total||0)+Number(priorProposals.sent||0)};
  if(!req.targetComparison&&!f.selected.businessLineId&&isCompanyReader(req.broker))for(const [metricCode,value] of Object.entries(inventorySnapshotValues))await execute(`INSERT INTO dashboard_metric_snapshots(id,metric_code,scope_type,scope_id,snapshot_date,value) VALUES($1,$2,'company','',CURRENT_DATE,$3) ON CONFLICT(metric_code,scope_type,scope_id,snapshot_date) DO UPDATE SET value=EXCLUDED.value,captured_at=NOW()`,[uuid(),metricCode,value]);
  const organizationRows=type==='manager'?await many(`SELECT t.id AS team_id,t.name AS team_name,t.manager_id,m.name AS manager_name,b.id AS agent_id,b.name AS agent_name
    FROM teams t LEFT JOIN brokers m ON m.id=t.manager_id
    LEFT JOIN brokers b ON b.team_id=t.id AND b.status='active' AND b.role='internal_broker' AND b.job_role IN ('sales_agent','listing_agent')
    WHERE t.active=1 AND (t.manager_id=$1 OR EXISTS(SELECT 1 FROM team_memberships tm WHERE tm.team_id=t.id AND tm.broker_id=$1 AND tm.membership_role='manager' AND tm.ends_at IS NULL)
      OR EXISTS(SELECT 1 FROM user_role_assignments ur WHERE ur.team_id=t.id AND ur.broker_id=$1 AND ur.job_role='manager' AND ur.status='active' AND ur.ends_at IS NULL))
      AND ($2::text IS NULL OR t.id::text=$2) AND ($3::text IS NULL OR b.id::text=$3)
    ORDER BY t.name,b.name`,[req.broker.id,f.selected.teamId,f.selected.agentId]):[];
  const hierarchy={company:'NYSA CORE',businessLines:[],teams:[]};for(const row of hierarchyRows){let business=hierarchy.businessLines.find(x=>x.code===row.businessType);if(!business){business={id:row.businessLineId||'unassigned',code:row.businessType,teams:[]};hierarchy.businessLines.push(business);}let team=business.teams.find(x=>x.id===row.teamId&&x.managerId===row.managerId);if(!team){team={id:row.teamId,name:row.teamName,managerId:row.managerId,manager:row.managerName,agents:[]};business.teams.push(team);}team.agents.push({id:row.agentId,name:row.agentName,value:row.value});}
  const activityByAgent=new Map();for(const row of hierarchyRows){if(row.agentId)activityByAgent.set(row.agentId,(activityByAgent.get(row.agentId)||0)+Number(row.value||0));}
  for(const row of organizationRows){let team=hierarchy.teams.find(x=>x.id===row.teamId);if(!team){team={id:row.teamId,name:row.teamName,managerId:row.managerId,manager:row.managerName||req.broker.name,agents:[]};hierarchy.teams.push(team);}if(row.agentId&&!team.agents.some(x=>x.id===row.agentId))team.agents.push({id:row.agentId,name:row.agentName,value:activityByAgent.get(row.agentId)||0});}
  const taskSummary=Object.fromEntries(tasks.map(item=>[item.label,item.value]));
  const recentActivities=await many(`SELECT a.id,a.activity_type,a.subject,a.outcome,a.created_at,l.id AS lead_id,l.title,c.full_name AS contact_name,b.name AS owner_name FROM activities a
    JOIN leads l ON l.id=a.lead_id JOIN contacts c ON c.id=a.contact_id JOIN brokers b ON b.id=a.owner_id WHERE ${f.where} ORDER BY a.created_at DESC LIMIT 8`,f.params);
  const approvalResult=await loadProposalApprovalQueue(req,f.selected);
  const organizationContext=await loadOrganizationContext(req.broker,type);
  const lifecycleRows=await loadOpportunityPipelineCounts(req.broker,f);
  const canApproveProposals=isProposalApprover(req.broker),requestedView=!canApproveProposals&&req.query.view==='Proposal approvals'?null:req.query.view;
  const versions=await listTargetVersions(targets.map(t=>t.id)),targetPeriods=targets.flatMap(t=>comparisonPeriods(t,versions,f.selected.dateFrom,f.selected.dateTo).map(p=>({...p,metricCode:t.metricCode,scopeType:t.scopeType,scopeId:t.scopeId})));
  const targetCandidates=targets.flatMap(t=>{const periods=targetPeriods.filter(p=>p.targetId===t.id);if(t.status!=='active'||!t.scopeMatchesDashboard||periods.length!==1||periods[0].future||periods[0].from>f.selected.dateFrom||periods[0].to<f.selected.dateTo)return[];const p=periods[0],v=versions.filter(v=>v.targetId===t.id&&v.revision===p.revision)[0];return[{...t,...(v?.payload||{}),targetValue:p.targetValue,exceptionThreshold:p.exceptionThreshold,thresholdDirection:p.thresholdDirection,targetPeriod:p}];});
  const comparableTargets=targetCandidates.filter(t=>targetCandidates.filter(other=>other.metricCode===t.metricCode).length===1);
  const dataAsOf=new Date(),presentation=buildRoleDashboardPresentation({type,view:requestedView,current,previous,previousInventory,targets:comparableTargets,trend,tasks:taskSummary,exceptions,previousExceptions,proposals,calls,inventory,agents,sources,priorSources,accountabilityRows,dataAsOf});
  if(req.targetComparison){const metrics=new Map();for(const view of ['Executive','Sales','Inventory','Operations and Risk'])for(const metric of buildRoleDashboardPresentation({type:'executive',view,current,previous,previousInventory,targets:[],trend,tasks:taskSummary,exceptions,previousExceptions,proposals,calls,inventory,agents,sources,priorSources,accountabilityRows,dataAsOf}).kpis)metrics.set(metric.code,metric);return res.json({kpis:[...metrics.values()]});}
  if(f.selected.businessLineId&&f.selected.businessLineId!=='unassigned'){const line=await one('SELECT * FROM business_lines WHERE id::text=$1',[f.selected.businessLineId]);if(!line)return res.status(400).json({error:'Unknown business line'});const codes=(await many('SELECT metric_code FROM business_line_kpis WHERE business_line_id=$1',[line.id])).map(x=>x.metricCode),all=new Map();for(const view of ['Executive','Sales','Inventory','Operations and Risk'])for(const metric of buildRoleDashboardPresentation({type:'executive',view,current,previous,previousInventory,targets:comparableTargets,trend,tasks:taskSummary,exceptions,previousExceptions,proposals,calls,inventory,agents,sources,priorSources,accountabilityRows,dataAsOf}).kpis)all.set(metric.code,metric);presentation.kpis=codes.filter(code=>isCompanyReader(req.broker)||!code.startsWith('inventory_')).map(code=>all.get(code)).filter(Boolean);}
  for(const k of presentation.kpis)k.targetPeriod=comparableTargets.find(t=>t.metricCode===k.code)?.targetPeriod||null;
  res.json({targetPeriods,dashboardType:type,view:presentation.view,canApproveProposals,dataAsOf,lastRefresh:dataAsOf,filters:f.selected,period:{current:{from:f.start,to:f.end},prior:{from:prior.start,to:prior.end}},
    calculationContext:'Role-scoped operational data; reassignment history is not rewritten. Counts use distinct accessible records.',...presentation,
    organizationContext,qualification:{hot:current.hot,warm:current.warm,warmConverted:current.warmConverted,warmPending:current.warmPending,
      warmConversionRate:Number(current.warm||0)?Number((Number(current.warmConverted||0)*100/Number(current.warm)).toFixed(2)):0,
      hotConverted:current.hotConverted},stages,agentLifecycle:buildAgentLifecycle(lifecycleRows),customerCount:Number(current.customers||0),sources,campaigns,teams,agents,trend,tasks:taskSummary,exceptions,proposals,proposalApprovalQueue:approvalResult.rows,proposalApprovalQueueCount:approvalResult.count,proposalApprovalQueuePage:approvalResult.page,proposalApprovalQueuePageSize:approvalResult.pageSize,calls,inventory,recentActivities,hierarchy});
}
r.get('/crm/dashboard',renderDashboardData);



r.get('/crm/dashboard/proposal-approvals',async(req,res)=>{if(!isProposalApprover(req.broker))return res.status(403).json({error:'Proposal approval access requires Team Manager or Managing Director'});const selected={businessLineId:clean(req.query.businessLineId),teamId:clean(req.query.teamId),managerId:clean(req.query.managerId),agentId:clean(req.query.agentId),businessType:clean(req.query.businessType)},result=await loadProposalApprovalQueue(req,selected,clean(req.query.q)||'',req.query.page,req.query.pageSize);res.json({proposalApprovalQueue:result.rows,count:result.count,page:result.page,pageSize:result.pageSize});});

r.get('/crm/reports/calls',async(req,res)=>{const f=filters(req,'l','a.created_at');if(f.error)return res.status(400).json({error:f.error});const rows=await many(`SELECT a.id,a.created_at,a.direction,a.outcome,a.duration_seconds,a.details,a.follow_up_required,a.due_at,a.next_action_due_at,a.completed_at,
  a.lead_stage_snapshot,a.qualification_snapshot,a.opportunity_stage_snapshot,l.id AS lead_id,l.title,c.id AS contact_id,c.full_name AS contact_name,x.project AS listing_project,b.name AS agent_name
  FROM activities a JOIN leads l ON l.id=a.lead_id JOIN contacts c ON c.id=a.contact_id LEFT JOIN listings x ON x.id=l.listing_id JOIN brokers b ON b.id=a.owner_id
  WHERE a.activity_type='Call' AND ${f.where} ORDER BY a.created_at DESC`,f.params);res.json({dataAsOf:new Date(),filters:f.selected,count:rows.length,calls:rows});});

r.get('/crm/dashboard/records',async(req,res)=>{
  const f=filters(req);if(f.error)return res.status(400).json({error:f.error});const segment=req.query.segment||'new_leads';
  const lifecycle=AGENT_LIFECYCLE_STAGES.find(item=>`lifecycle_${item.stage.toLowerCase()}`===segment);
  if(lifecycle){
    const rows=await loadOpportunityPipelineRecords(req.broker,f,lifecycle.stage,req),sample=rows[0];
    const breadcrumbs=['NYSA CORE',f.selected.businessType,f.selected.teamId?sample?.teamName:null,f.selected.managerId?sample?.managerName:null,f.selected.agentId?sample?.agentName:null].filter(Boolean);
    return res.json(dashboardRecordResult(req,{entityType:'opportunity',segment,segmentLabel:lifecycle.label,stageAction:lifecycle.action,dataAsOf:new Date(),filters:f.selected,count:rows.length,breadcrumbs,
      records:rows.map(row=>({...row,breadcrumbs:['NYSA CORE',row.businessType,row.teamName,row.managerName,row.agentName,row.opportunityReference||row.title].filter(Boolean)}))}));
  }
  if(segment.startsWith('guided_')){
    const step=segment.slice(7),leadSteps={customer:'TRUE',lead:'TRUE',qualification:'EXISTS(SELECT 1 FROM qualification_assessments qa WHERE qa.lead_id=l.id)',requirements:'EXISTS(SELECT 1 FROM lead_requirements lr WHERE lr.lead_id=l.id AND lr.superseded_at IS NULL)'};
    let rows;
    if(Object.hasOwn(leadSteps,step)){
      const params=[],scope=agentWorkLeadScopeSql('l',req.broker,params),distinct=step==='customer'?'DISTINCT ON (l.contact_id)':'';
      rows=await many(`SELECT ${distinct} l.id,l.lead_reference,l.current_status,l.title,l.source,l.business_type,l.stage,l.temperature,l.created_at,l.next_follow_up_at,c.full_name AS contact_name,
        t.id AS team_id,t.name AS team_name,m.id AS manager_id,m.name AS manager_name,b.id AS agent_id,b.name AS agent_name
        FROM leads l JOIN contacts c ON c.id=l.contact_id LEFT JOIN teams t ON t.id=l.assigned_team_id LEFT JOIN brokers m ON m.id=t.manager_id LEFT JOIN brokers b ON b.id=l.assigned_to
        WHERE ${scope.clause} AND ${leadSteps[step]} ORDER BY ${step==='customer'?'l.contact_id,':''}l.created_at DESC`,params);
    }else{
      const conditions={opportunity:"o.stage NOT IN('Closed Won','Closed Lost')",matching:"o.stage='Matching'",viewing:"o.stage='Viewing'",
        offer:'EXISTS(SELECT 1 FROM offers f WHERE f.opportunity_id=o.id)',booking:"EXISTS(SELECT 1 FROM bookings bk WHERE bk.opportunity_id=o.id AND bk.status='reserved')",
        deal:'EXISTS(SELECT 1 FROM deals d WHERE d.opportunity_id=o.id)'};
      if(!conditions[step])return res.status(400).json({error:'Unknown operating-sequence step'});
      const params=[],scope=opportunityScopeSql('o',req.broker,params);
      rows=await many(`SELECT l.id,l.lead_reference,l.current_status,l.title,l.source,l.business_type,l.stage,l.temperature,o.opportunity_reference,o.stage AS opportunity_stage,o.created_at,o.next_action_due_at AS next_follow_up_at,c.full_name AS contact_name,
        t.id AS team_id,t.name AS team_name,m.id AS manager_id,m.name AS manager_name,b.id AS agent_id,b.name AS agent_name
        FROM opportunities o JOIN leads l ON l.id=o.lead_id JOIN contacts c ON c.id=l.contact_id LEFT JOIN teams t ON t.id=o.assigned_team_id
        LEFT JOIN brokers m ON m.id=t.manager_id LEFT JOIN brokers b ON b.id=o.owner_id
        WHERE ${scope.clause} AND ${conditions[step]} ORDER BY o.created_at DESC`,params);
    }
    return res.json(dashboardRecordResult(req,{entityType:'lead',segment,segmentLabel:step==='customer'?'Customers':step[0].toUpperCase()+step.slice(1),dataAsOf:new Date(),filters:{},count:rows.length,breadcrumbs:['NYSA CORE',req.broker.jobRole==='manager'?'Team operating sequence':'My operating sequence'],records:rows.map(row=>({...row,breadcrumbs:['NYSA CORE',row.businessType,row.teamName,row.managerName,row.agentName,row.title].filter(Boolean)}))}));
  }
  if(['inventory_available','inventory_stale','inventory_media_not_ready','inventory_readiness_exposure','inventory_aging_exposure','inventory_compliance_exposure'].includes(segment)){
    if(!isCompanyReader(req.broker))return res.status(403).json({error:'Company inventory drill-down requires Director access'});
    const active="nysa_inventory_effective_status(id) NOT IN('Closed','Sold','Rented')",conditions={inventory_available:"nysa_inventory_effective_status(id)='Available'",inventory_stale:`updated_at<NOW()-INTERVAL '30 days' AND ${active}`,inventory_media_not_ready:"NOT EXISTS(SELECT 1 FROM property_media m WHERE m.listing_id=listings.id AND m.approval_status='approved' AND m.usage_rights_confirmed=TRUE AND (m.rights_expires_at IS NULL OR m.rights_expires_at>NOW()))",
      inventory_aging_exposure:`${active} AND (updated_at<NOW()-INTERVAL '30 days' OR availability_confirmed_at IS NULL OR availability_confirmed_at<NOW()-INTERVAL '7 days')`,
      inventory_compliance_exposure:`${active} AND ((permit_expires_at IS NOT NULL AND permit_expires_at<NOW()+INTERVAL '30 days') OR verification_status NOT IN('verified','not_required') OR verification_expires_at<NOW()+INTERVAL '30 days' OR NOT EXISTS(SELECT 1 FROM property_media m WHERE m.listing_id=listings.id AND m.approval_status='approved' AND m.usage_rights_confirmed=TRUE AND (m.rights_expires_at IS NULL OR m.rights_expires_at>NOW())))`,
      inventory_readiness_exposure:`${active} AND (availability_confirmed_at IS NULL OR availability_confirmed_at<NOW()-INTERVAL '7 days' OR (permit_expires_at IS NOT NULL AND permit_expires_at<NOW()+INTERVAL '30 days') OR verification_status NOT IN('verified','not_required') OR verification_expires_at<NOW()+INTERVAL '30 days' OR portal_status NOT IN('ready','published') OR NOT EXISTS(SELECT 1 FROM property_media m WHERE m.listing_id=listings.id AND m.approval_status='approved' AND m.usage_rights_confirmed=TRUE AND (m.rights_expires_at IS NULL OR m.rights_expires_at>NOW())))`};
    const lineParams=[],lineWhere=f.selected.businessLineId?(f.selected.businessLineId==='unassigned'?` AND ${businessLineAtSql('(SELECT bl_owner.team_id FROM brokers bl_owner WHERE bl_owner.id=listings.posted_by)','listings.created_at')} IS NULL`:(lineParams.push(f.selected.businessLineId),` AND ${businessLineFilterSql('(SELECT bl_owner.team_id FROM brokers bl_owner WHERE bl_owner.id=listings.posted_by)','listings.created_at','$1')}`)):'';
    const records=await dashboardPageRows(req,`SELECT id,project AS title,area,nysa_inventory_effective_status(id) AS status,property_type,updated_at,availability_confirmed_at,verification_status,verification_expires_at,permit_number,permit_expires_at,portal_status FROM listings WHERE deleted_at IS NULL AND ${conditions[segment]}${lineWhere} ORDER BY updated_at,id`,lineParams);
    return res.json(dashboardRecordResult(req,{entityType:'listing',segment,dataAsOf:new Date(),filters:f.selected,count:records.length,breadcrumbs:['NYSA CORE','Inventory'],records:records.map(row=>({...row,breadcrumbs:['NYSA CORE','Inventory',row.area,row.title].filter(Boolean)}))}));
  }
  if(['proposal_workload','customer_engagement'].includes(segment)){
    const proposalF=filters(req,'l','p.updated_at'),callF=filters(req,'l','a.created_at');
    const common=`l.id AS lead_id,l.title,l.business_type,l.stage,l.temperature,c.full_name AS contact_name,t.name AS team_name,m.name AS manager_name,b.name AS agent_name`;
    const proposalStatus=segment==='proposal_workload'?"p.status IN('draft','generated','reviewed')":"p.status='sent'";
    const proposals=await many(`SELECT p.id,${common},p.updated_at AS created_at,'Proposal '||p.status AS engagement_type FROM proposals p JOIN leads l ON l.id=p.lead_id JOIN contacts c ON c.id=l.contact_id LEFT JOIN teams t ON t.id=l.assigned_team_id LEFT JOIN brokers m ON m.id=t.manager_id LEFT JOIN brokers b ON b.id=l.assigned_to WHERE ${proposalF.where} AND ${proposalStatus} ORDER BY p.updated_at DESC`,proposalF.params);
    const calls=segment==='customer_engagement'?await many(`SELECT a.id,${common},a.created_at,'Call' AS engagement_type FROM activities a JOIN leads l ON l.id=a.lead_id JOIN contacts c ON c.id=l.contact_id LEFT JOIN teams t ON t.id=l.assigned_team_id LEFT JOIN brokers m ON m.id=t.manager_id LEFT JOIN brokers b ON b.id=l.assigned_to WHERE a.activity_type='Call' AND ${callF.where} ORDER BY a.created_at DESC`,callF.params):[];
    const records=[...proposals,...calls].sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).map(row=>({...row,id:row.leadId,sourceType:row.engagementType,breadcrumbs:['NYSA CORE',row.businessType,row.teamName,row.managerName,row.agentName,row.title,row.engagementType].filter(Boolean)}));
    return res.json(dashboardRecordResult(req,{entityType:'engagement',segment,dataAsOf:new Date(),filters:f.selected,count:records.length,breadcrumbs:['NYSA CORE',segment==='proposal_workload'?'Proposal workload':'Customer engagement'],records}));
  }
  if(['overdue_tasks','due_today'].includes(segment)){
    const condition=segment==='overdue_tasks'?"task.due_at<NOW()":"task.due_at>=NOW() AND task.due_at<CURRENT_DATE+INTERVAL '1 day'";
    const rows=await dashboardPageRows(req,`SELECT task.id AS task_id,task.subject,task.status,l.id AS lead_id,l.lead_reference,l.title AS lead_title,task.due_at AS created_at,c.full_name AS contact_name,t.name AS team_name,b.name AS agent_name FROM tasks task JOIN leads l ON l.id=task.lead_id JOIN contacts c ON c.id=l.contact_id LEFT JOIN teams t ON t.id=l.assigned_team_id LEFT JOIN brokers b ON b.id=task.assignee_id WHERE ${f.where} AND task.status NOT IN('completed','cancelled') AND ${condition} ORDER BY task.due_at,task.id`,f.params);
    return res.json(dashboardRecordResult(req,{entityType:'task',segment,dataAsOf:new Date(),filters:f.selected,records:rows.map(row=>({...row,id:row.leadId,title:row.subject,stage:row.status}))}));
  }
  if(segment==='team_capacity_pressure'){
    const records=await dashboardPageRows(req,`SELECT l.assigned_to AS agent_id,l.assigned_team_id AS team_id,b.name AS agent_name,t.name AS team_name,COUNT(*) FILTER(WHERE l.stage NOT IN('Won','Lost'))::int AS open_lead_count FROM leads l LEFT JOIN brokers b ON b.id=l.assigned_to LEFT JOIN teams t ON t.id=l.assigned_team_id WHERE ${f.where} AND l.assigned_to IS NOT NULL GROUP BY l.assigned_to,l.assigned_team_id,b.name,t.name HAVING COUNT(*) FILTER(WHERE l.stage NOT IN('Won','Lost'))>=10 ORDER BY b.name,t.name`,f.params);
    return res.json(dashboardRecordResult(req,{entityType:'agent',segment,dataAsOf:new Date(),filters:f.selected,records}));
  }
  if(['operational_exceptions','exception_trend'].includes(segment)){
    const records=await many(`SELECT l.id,l.title,l.source,l.business_type,l.stage,l.temperature,l.created_at,l.next_follow_up_at,c.full_name AS contact_name,
      t.id AS team_id,t.name AS team_name,m.id AS manager_id,m.name AS manager_name,b.id AS agent_id,b.name AS agent_name,ex.exception_type
      FROM leads l JOIN contacts c ON c.id=l.contact_id LEFT JOIN teams t ON t.id=l.assigned_team_id LEFT JOIN brokers m ON m.id=t.manager_id LEFT JOIN brokers b ON b.id=l.assigned_to
      CROSS JOIN LATERAL UNNEST(ARRAY[
        CASE WHEN c.email IS NULL AND c.phone IS NULL THEN 'Missing contact channel' END,
        CASE WHEN NOT EXISTS(SELECT 1 FROM lead_requirements q WHERE q.lead_id=l.id AND q.superseded_at IS NULL) THEN 'Missing current requirement' END,
        CASE WHEN c.do_not_contact=1 THEN 'Restricted contact' END,
        CASE WHEN EXISTS(SELECT 1 FROM contact_channels cc JOIN contact_channels dc ON dc.channel_kind=cc.channel_kind AND dc.normalized_value=cc.normalized_value AND dc.contact_id<>cc.contact_id WHERE cc.contact_id=c.id AND cc.normalized_value IS NOT NULL) THEN 'Possible duplicate contact' END,
        CASE WHEN c.do_not_contact=0 AND NOT EXISTS(SELECT 1 FROM marketing_agreements ma WHERE ma.contact_id=c.id AND ma.status='executed' AND ma.effective_at<=NOW() AND (ma.expires_at IS NULL OR ma.expires_at>NOW())) THEN 'Missing effective consent' END,
        CASE WHEN NOT EXISTS(SELECT 1 FROM documents d WHERE d.lead_id=l.id AND d.status<>'retired') THEN 'Missing active document' END
      ]) ex(exception_type) WHERE ${f.where} AND ex.exception_type IS NOT NULL ORDER BY l.created_at DESC,l.id`,f.params);
    if(!f.selected.businessLineId&&isCompanyReader(req.broker)){const events=await many("SELECT event_id,error_code,received_at FROM website_intake_events WHERE status='failed' AND received_at>=$1 AND received_at<$2 ORDER BY received_at",[f.start,new Date(f.end.getTime()+86400000)]);for(const event of events)records.push({id:null,title:event.eventId,contactName:'Website intake',businessType:'Operations',stage:'Failed',temperature:'—',teamName:'Digital intake',managerName:'Company support',agentName:null,createdAt:event.receivedAt,exceptionType:event.errorCode||'Integration failure'});}
    return res.json(dashboardRecordResult(req,{entityType:'exception',segment,dataAsOf:new Date(),filters:f.selected,count:records.length,breadcrumbs:['NYSA CORE','Operations and Risk'],records:records.map(row=>({...row,breadcrumbs:['NYSA CORE',row.businessType,row.teamName,row.managerName,row.agentName,row.title].filter(Boolean)}))}));
  }
  const clauses={sla_breaches:"((l.accepted_at IS NULL AND l.acceptance_due_at<NOW()) OR (l.accepted_at IS NOT NULL AND l.first_contact_at IS NULL AND l.first_contact_due_at<NOW()))",
    sla_risk:"l.stage NOT IN('Won','Lost') AND ((l.accepted_at IS NULL AND l.acceptance_due_at BETWEEN NOW() AND NOW()+INTERVAL '60 minutes') OR (l.accepted_at IS NOT NULL AND l.first_contact_at IS NULL AND l.first_contact_due_at BETWEEN NOW() AND NOW()+INTERVAL '60 minutes'))",
    no_next_action:"l.next_follow_up_at IS NULL AND l.current_status='active' AND l.stage NOT IN('Won','Lost')",won_leads:"l.current_status='closed_won'",hot_leads:"l.temperature='Hot' AND l.current_status='active'",warm_leads:"l.temperature='Warm' AND l.current_status='active'",
    hot_warm_pipeline:"l.temperature IN('Hot','Warm') AND l.stage NOT IN('Won','Lost')",hot_warm_aging:"l.temperature IN('Hot','Warm') AND l.updated_at<NOW()-INTERVAL '7 days' AND l.stage NOT IN('Won','Lost')",
    stale_risk:"l.updated_at<NOW()-INTERVAL '7 days' AND l.stage NOT IN('Won','Lost')",unassigned_leads:"l.assigned_to IS NULL AND l.stage NOT IN('Won','Lost')",
    awaiting_acceptance:"l.accepted_at IS NULL AND l.stage NOT IN('Won','Lost')",overdue_tasks:"EXISTS(SELECT 1 FROM tasks dt WHERE dt.lead_id=l.id AND dt.status NOT IN('completed','cancelled') AND dt.due_at<NOW())",
    due_today:"EXISTS(SELECT 1 FROM tasks dt WHERE dt.lead_id=l.id AND dt.status NOT IN('completed','cancelled') AND dt.due_at>=CURRENT_DATE AND dt.due_at<CURRENT_DATE+INTERVAL '1 day')",
    proposal_workload:"EXISTS(SELECT 1 FROM proposals dp WHERE dp.lead_id=l.id AND dp.status IN('draft','generated','reviewed'))",
    };
  const pipelineParams=[...f.params],pipelineFrom=pipelineJoin(req.broker,pipelineParams);
  const extra=lifecycle?`(${pipelineStageSql})='${lifecycle.stage}'`:clauses[segment];
  const rows=await dashboardPageRows(req,`SELECT l.id,l.lead_reference,l.current_status,l.title,l.source,l.business_type,l.stage,l.temperature,l.created_at,l.next_follow_up_at,c.full_name AS contact_name,
    t.id AS team_id,t.name AS team_name,m.id AS manager_id,m.name AS manager_name,b.id AS agent_id,b.name AS agent_name,
    ${pipelineStageSql} AS pipeline_stage,pipeline.id AS pipeline_opportunity_id,pipeline.opportunity_reference
    FROM leads l JOIN contacts c ON c.id=l.contact_id LEFT JOIN teams t ON t.id=l.assigned_team_id LEFT JOIN brokers m ON m.id=t.manager_id LEFT JOIN brokers b ON b.id=l.assigned_to
    ${pipelineFrom} WHERE ${f.where}${extra?' AND '+extra:''} ORDER BY l.created_at DESC,l.id`,pipelineParams);
  const sample=rows[0],breadcrumbs=['NYSA CORE',f.selected.businessType,f.selected.teamId?sample?.teamName:null,f.selected.managerId?sample?.managerName:null,f.selected.agentId?sample?.agentName:null].filter(Boolean);
  res.json(dashboardRecordResult(req,{entityType:'lead',segment,segmentLabel:lifecycle?lifecycle.label:null,stageAction:lifecycle?lifecycle.action:null,dataAsOf:new Date(),filters:f.selected,count:rows.length,breadcrumbs,records:rows.map(row=>({...row,breadcrumbs:["NYSA CORE",row.businessType,row.teamName,row.managerName,row.agentName,row.title].filter(Boolean)}))}));
});

const csvCell=v=>`"${String(v??'').replace(/"/g,'""')}"`;
r.get('/crm/dashboard/export',async(req,res)=>{const f=filters(req);if(f.error)return res.status(400).json({error:f.error});const rows=await many(`SELECT l.id,l.lead_reference,l.current_status,l.title,c.full_name AS contact_name,l.source,l.business_type,l.stage,l.temperature,t.name AS team_name,b.name AS agent_name,l.created_at,l.next_follow_up_at FROM leads l JOIN contacts c ON c.id=l.contact_id LEFT JOIN teams t ON t.id=l.assigned_team_id LEFT JOIN brokers b ON b.id=l.assigned_to WHERE ${f.where} ORDER BY l.created_at DESC`,f.params);const headers=['id','leadReference','currentStatus','title','contactName','source','businessType','stage','temperature','teamName','agentName','createdAt','nextFollowUpAt'],csv=[headers.map(csvCell).join(','),...rows.map(row=>headers.map(h=>csvCell(row[h])).join(','))].join('\r\n');await audit('DashboardExport',uuid(),'exported',req.broker.id,{filters:f.selected,rowCount:rows.length,dashboardType:dashboardTypeFor(req.broker)});res.setHeader('Content-Type','text/csv; charset=utf-8');res.setHeader('Content-Disposition','attachment; filename="nysa-dashboard-export.csv"');res.end(csv);});

r.get('/admin/dashboard-metrics',async(req,res)=>{if(req.broker.role!=='admin')return res.status(403).json({error:'Admin access required'});res.json(await targetSetup());});
r.get('/admin/dashboard-targets',async(req,res)=>{if(req.broker.role!=='admin')return res.status(403).json({error:'Admin access required'});res.json({targets:await many('SELECT d.*,d.period_start::text AS period_start,d.period_end::text AS period_end,(SELECT effective_on::text FROM dashboard_target_revisions WHERE target_id=d.id ORDER BY revision DESC LIMIT 1) AS latest_value_effective_on,b.name AS approved_by_name FROM dashboard_targets d LEFT JOIN brokers b ON b.id=d.approved_by ORDER BY d.created_at DESC')});});
r.post('/admin/dashboard-targets',async(req,res)=>{if(req.broker.role!=='admin')return res.status(403).json({error:'Admin access required'});res.status(201).json(await createTarget(req.body||{},req.broker.id));});
for(const action of ['edit','delete','approve','activate','retire'])r.post('/admin/dashboard-targets/:id/'+action,async(req,res)=>{if(req.broker.role!=='admin')return res.status(403).json({error:'Admin access required'});res.json(await changeTarget(req.params.id,action,req.body||{},req.broker.id));});
r.get('/admin/dashboard-targets/:id/history',async(req,res)=>{if(req.broker.role!=='admin')return res.status(403).json({error:'Admin access required'});res.json({versions:await listTargetVersions([req.params.id]),events:await many("SELECT a.action,a.timestamp,a.details,b.name AS performed_by_name FROM audit_log a JOIN brokers b ON b.id=a.performed_by WHERE a.entity_type='DashboardTarget' AND a.entity_id=$1 ORDER BY a.timestamp",[req.params.id])});});

r.get('/crm/dashboard/target-comparisons',async(req,res)=>{
 const f=filters(req);if(f.error)return res.status(400).json({error:f.error});
 const targets=await relevantDashboardTargets(req,f.selected),versions=await listTargetVersions(targets.map(t=>t.id)),all=targets.flatMap(target=>comparisonPeriods(target,versions,f.selected.dateFrom,f.selected.dateTo).map(p=>({...p,metricCode:target.metricCode,scopeType:target.scopeType,scopeId:target.scopeId,scopeName:target.scopeName,label:TARGET_METRICS[target.metricCode]?.label||target.metricCode})));
 const page=Math.max(1,Number(req.query.page)||1),rows=all.slice((page-1)*25,page*25),cache=new Map();
 for(const row of rows){row.actual=null;row.actualNote='Historical actual unavailable';if(row.future){row.actualNote='Period has not started';continue;}
  const flow=['new_leads','won_leads','customer_engagement'].includes(row.metricCode),today=dubaiToday();
  // Historical current-state metrics cannot be reconstructed reliably from today's rows.
  if(!flow&&row.actualTo!==today)continue;
  const query={...req.query,dateFrom:row.actualFrom,dateTo:row.actualTo};delete query.page;
  if(row.scopeType==='team')query.teamId=row.scopeId;if(row.scopeType==='agent')query.agentId=row.scopeId;if(row.scopeType==='business_line')query.businessLineId=row.scopeId;
  const key=JSON.stringify(query);let data=cache.get(key);if(!data){await renderDashboardData({...req,query,targetComparison:true},{json:value=>{data=value;return value;},status:()=>({json:()=>{throw new Error('Target comparison period could not be loaded');}})});cache.set(key,data);}
  const metric=data.kpis.find(k=>k.code===row.metricCode);if(metric){row.actual=metric.current;row.variance=row.actual-row.targetValue;row.actualNote=row.partial?'Partial period; full target retained':'Complete period';row.inProgress=row.to>=today;row.exception=row.exceptionThreshold===null?null:row.thresholdDirection==='high_bad'?row.actual>row.exceptionThreshold:row.actual<row.exceptionThreshold;}
 }
 res.json({rows,count:all.length,page,pageSize:25});
});

r.get('/crm/dashboard/views',async(req,res)=>res.json({views:await many('SELECT * FROM saved_dashboard_views WHERE owner_id=$1 ORDER BY name',[req.broker.id])}));
r.post('/crm/dashboard/views',async(req,res)=>{if(!clean(req.body?.name))return res.status(400).json({error:'name is required'});const id=uuid(),row=await one(`INSERT INTO saved_dashboard_views(id,owner_id,name,dashboard_type,filters) VALUES($1,$2,$3,$4,$5) ON CONFLICT(owner_id,name,dashboard_type) DO UPDATE SET filters=EXCLUDED.filters,updated_at=NOW() RETURNING *`,[id,req.broker.id,clean(req.body.name),dashboardTypeFor(req.broker),JSON.stringify(req.body.filters||{})]);await audit('SavedDashboardView',row.id,'saved',req.broker.id);res.status(201).json(row);});

export default r;
