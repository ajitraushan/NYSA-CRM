import {canReadAllCrmDocuments} from '../document-read-policy.js';
import {registerDirectorSummary} from '../director-commission-summary.js';
import {createAdviceIntents,registerAdviceRoutes} from '../payout-advice.js';
import {registerFinanceQueues} from '../finance-workspace-queues.js';
import { Router } from '../lib/http-kit.js';
import { requireAuth } from '../auth.js';
import {registerCommissionProofRoutes,resolveReceiptProof} from '../commission-proof.js';
import {registerAccountantWorkspace} from '../accountant-workspace.js';
import {parseReceiptAmount} from '../../public/money-input.js';
import {readFile} from 'node:fs/promises';
import {registerCommissionReceivableRoutes} from '../commission-receivables.js';
import {commissionPayoutApprovedDocument,makeCommissionPayoutSheetPdf} from '../commission-payout-sheet-pdf.js';
import {readPrivate,savePrivate,removePrivate} from '../private-files.js';
import {approvedDocumentEvidence,recordApprovedDocumentIssuance} from '../approved-document-issuance.js';
import {registerOpportunityFinance,opportunityReceipts} from '../opportunity-finance.js';
import {lockOpportunityFinance} from '../receivable-receipt-posting.js';
import { one,many,execute,transaction,uuid,audit } from '../db.js';
import { allocateDealAgentCredit,applySocialMediaPayoutBonus,buildQuarterPayoutStatement,calculateExpectedCommission,calculateRealtimePayout,mayDraftPayoutPolicy,
  mayMaintainPayoutPolicy,mayViewPayoutWorkspace,payoutFingerprint,receiptQuarterKey,reconcileCommissionReceipt,validatePayoutPolicy } from '../commission-payout-domain.js';

const r=Router();r.use(requireAuth);
registerAccountantWorkspace(r);
registerAdviceRoutes(r);
registerFinanceQueues(r);
registerCommissionProofRoutes(r);
registerCommissionReceivableRoutes(r);
registerOpportunityFinance(r);
const clean=value=>String(value??'').trim(),fullAdmin=broker=>broker.role==='admin',director=broker=>mayViewPayoutWorkspace(broker);
const financeReceipt=broker=>fullAdmin(broker)||['director','accountant'].includes(broker.jobRole);
const accountant=broker=>fullAdmin(broker)||broker.jobRole==='accountant';
const requireIdempotency=(req,res)=>{const key=clean(req.body?.idempotencyKey||req.headers?.['x-idempotency-key']);if(key.length<8){res.status(400).json({error:'A stable idempotency key is required'});return null;}return key;};
const meaningful=(value,label='A meaningful reason')=>{const text=clean(value);if(text.length<10)throw Object.assign(new Error(`${label} is required`),{statusCode:400});return text;};
const dubaiCalendarDate=value=>{const date=new Date(value);return Number.isNaN(date.getTime())?'':new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Dubai'}).format(date);};

async function dealContext(dealId,client){return one(`SELECT d.id,d.deal_reference,d.status,d.version,d.deal_type,d.agreed_value,d.currency,d.owner_id,
    o.id AS opportunity_id,o.version AS opportunity_version,o.buyer_commission_percent,o.buyer_commission_minimum,
    o.seller_commission_percent,o.seller_commission_minimum,o.originating_agent_split_percent,o.servicing_agent_split_percent,
    COALESCE(l.originating_agent_id,o.buyer_side_agent_id,o.owner_id) AS originating_agent_id,
    COALESCE(d.owner_id,o.inventory_side_agent_id,o.owner_id) AS servicing_agent_id
  FROM deals d JOIN opportunities o ON o.id=d.opportunity_id LEFT JOIN listings l ON l.id=d.listing_id WHERE d.id=$1`,[dealId],client);}

async function policyWithSlabs(policy,client){if(!policy)return null;return{...policy,slabs:await many(`SELECT display_order,lower_amount,upper_amount,agent_percent FROM commission_payout_policy_slabs WHERE policy_version_id=$1 ORDER BY display_order`,[policy.id],client)};}
async function adjustmentWithSlabs(adjustment,client){if(!adjustment)return null;return{...adjustment,slabs:await many(`SELECT display_order,lower_amount,upper_amount,agent_percent,company_lower_amount,company_upper_amount,company_agent_percent FROM agent_payout_adjustment_slabs WHERE adjustment_version_id=$1 ORDER BY display_order`,[adjustment.id],client)};}

r.get('/admin/commission-payout-policies',async(req,res)=>{
  if(!mayDraftPayoutPolicy(req.broker))return res.status(403).json({error:'Admin access required'});
  const policies=await many(`SELECT * FROM commission_payout_policy_versions ORDER BY currency,effective_from DESC,version_number DESC`);
  for(const policy of policies)policy.slabs=await many(`SELECT display_order,lower_amount,upper_amount,agent_percent FROM commission_payout_policy_slabs WHERE policy_version_id=$1 ORDER BY display_order`,[policy.id]);
  const adjustments=await many(`SELECT a.*,b.name AS agent_name FROM agent_payout_adjustment_versions a JOIN brokers b ON b.id=a.agent_id ORDER BY b.name,a.effective_from DESC,a.version_number DESC`);
  for(const adjustment of adjustments)adjustment.slabs=await many(`SELECT display_order,lower_amount,upper_amount,agent_percent,company_lower_amount,company_upper_amount,company_agent_percent FROM agent_payout_adjustment_slabs WHERE adjustment_version_id=$1 ORDER BY display_order`,[adjustment.id]);
  res.json({policies,adjustments});
});

r.post('/admin/commission-payout-policy-versions',async(req,res)=>{
  if(!mayDraftPayoutPolicy(req.broker))return res.status(403).json({error:'Admin access required'});
  const checked=validatePayoutPolicy(req.body||{});if(!checked.valid)return res.status(400).json({error:checked.errors[0],errors:checked.errors});
  const result=await transaction(async client=>{const latest=await one('SELECT COALESCE(MAX(version_number),0)::int AS n FROM commission_payout_policy_versions WHERE policy_code=$1',[checked.value.policyCode],client),id=uuid();
    const policy=await one(`INSERT INTO commission_payout_policy_versions(id,policy_code,version_number,currency,effective_from,effective_to,trigger_method,reason,created_by)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,[id,checked.value.policyCode,Number(latest.n)+1,checked.value.currency,checked.value.effectiveFrom,checked.value.effectiveTo,checked.value.triggerMethod,checked.value.reason,req.broker.id],client);
    for(const slab of checked.value.slabs)await execute(`INSERT INTO commission_payout_policy_slabs(id,policy_version_id,display_order,lower_amount,upper_amount,agent_percent) VALUES($1,$2,$3,$4,$5,$6)`,[uuid(),id,slab.displayOrder,slab.lowerAmount,slab.upperAmount,slab.agentPercent],client);
    await audit('CommissionPayoutPolicy',id,'draft_created',req.broker.id,{policyCode:policy.policyCode,versionNumber:policy.versionNumber,currency:policy.currency,triggerMethod:policy.triggerMethod,slabCount:checked.value.slabs.length},client);return policy;});
  res.status(201).json({policy:result});
});

r.post('/admin/commission-payout-policy-versions/:versionId/activate',async(req,res)=>{
  if(!mayMaintainPayoutPolicy(req.broker))return res.status(403).json({error:'Admin activation required'});
  const result=await transaction(async client=>{const policy=await one('SELECT * FROM commission_payout_policy_versions WHERE id=$1 FOR UPDATE',[req.params.versionId],client);if(!policy)return{code:404,error:'Payout policy not found'};if(policy.status!=='draft')return{code:409,error:'Only a draft payout policy can be activated'};
    await execute('SELECT pg_advisory_xact_lock(hashtext($1))',[`commission-policy:${policy.currency}`],client);
    await execute(`UPDATE commission_payout_policy_versions SET status='superseded' WHERE currency=$1 AND status='active' AND id<>$2 AND effective_from=$3`,[policy.currency,policy.id,policy.effectiveFrom],client);
    const active=await one(`UPDATE commission_payout_policy_versions SET status='active',activated_by=$1,activated_at=NOW() WHERE id=$2 RETURNING *`,[req.broker.id,policy.id],client);
    await audit('CommissionPayoutPolicy',policy.id,'activated',req.broker.id,{versionNumber:policy.versionNumber,currency:policy.currency},client);return{policy:active};});
  if(result.error)return res.status(result.code).json({error:result.error});res.json(result);
});

r.post('/admin/agent-payout-adjustment-versions',async(req,res)=>{
  if(!mayDraftPayoutPolicy(req.broker))return res.status(403).json({error:'Admin access required'});
  const checked=validatePayoutPolicy(req.body||{});if(!checked.valid)return res.status(400).json({error:checked.errors[0],errors:checked.errors});
  const agentId=clean(req.body?.agentId),basePolicyVersionId=clean(req.body?.basePolicyVersionId),evidenceReference=clean(req.body?.evidenceReference);if(!agentId||!basePolicyVersionId||evidenceReference.length<3)return res.status(400).json({error:'Agent, base company policy and evidence reference are required'});
  const result=await transaction(async client=>{const agent=await one("SELECT id FROM brokers WHERE id=$1 AND status='active' AND role='internal_broker'",[agentId],client),base=await one("SELECT * FROM commission_payout_policy_versions WHERE id=$1 AND status='active'",[basePolicyVersionId],client);if(!agent||!base)return{code:409,error:'Select an active internal agent and active company policy'};
    const latest=await one('SELECT COALESCE(MAX(version_number),0)::int AS n FROM agent_payout_adjustment_versions WHERE agent_id=$1 AND currency=$2',[agentId,checked.value.currency],client),id=uuid();
    const adjustment=await one(`INSERT INTO agent_payout_adjustment_versions(id,agent_id,base_policy_version_id,version_number,currency,effective_from,effective_to,trigger_method,reason,evidence_reference,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,[id,agentId,basePolicyVersionId,Number(latest.n)+1,checked.value.currency,checked.value.effectiveFrom,checked.value.effectiveTo,checked.value.triggerMethod,checked.value.reason,evidenceReference,req.broker.id],client);
    const companySlabs=await many('SELECT * FROM commission_payout_policy_slabs WHERE policy_version_id=$1 ORDER BY display_order',[base.id],client);
    for(const slab of checked.value.slabs){const company=companySlabs[slab.displayOrder-1];await execute(`INSERT INTO agent_payout_adjustment_slabs(id,adjustment_version_id,display_order,lower_amount,upper_amount,agent_percent,company_lower_amount,company_upper_amount,company_agent_percent) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)`,[uuid(),id,slab.displayOrder,slab.lowerAmount,slab.upperAmount,slab.agentPercent,company?.lowerAmount??null,company?.upperAmount??null,company?.agentPercent??null],client);}
    await audit('AgentPayoutAdjustment',id,'draft_created',req.broker.id,{agentId,basePolicyVersionId,versionNumber:adjustment.versionNumber,slabCount:checked.value.slabs.length},client);return{adjustment};});
  if(result.error)return res.status(result.code).json({error:result.error});res.status(201).json(result);
});

r.post('/admin/agent-payout-adjustment-versions/:versionId/activate',async(req,res)=>{
  if(!mayMaintainPayoutPolicy(req.broker))return res.status(403).json({error:'Admin activation required'});
  const result=await transaction(async client=>{const adjustment=await one('SELECT * FROM agent_payout_adjustment_versions WHERE id=$1 FOR UPDATE',[req.params.versionId],client);if(!adjustment)return{code:404,error:'Agent payout adjustment not found'};if(adjustment.status!=='draft')return{code:409,error:'Only a draft adjustment can be activated'};
    await execute('SELECT pg_advisory_xact_lock(hashtext($1))',[`agent-adjustment:${adjustment.agentId}:${adjustment.currency}`],client);
    const active=await one(`UPDATE agent_payout_adjustment_versions SET status='active',activated_by=$1,activated_at=NOW() WHERE id=$2 RETURNING *`,[req.broker.id,adjustment.id],client);
    await audit('AgentPayoutAdjustment',adjustment.id,'activated',req.broker.id,{agentId:adjustment.agentId,versionNumber:adjustment.versionNumber},client);return{adjustment:active};});
  if(result.error)return res.status(result.code).json({error:result.error});res.json(result);
});

r.post('/crm/deals/:dealId/commission-expectations/preview',async(req,res)=>{const deal=await dealContext(req.params.dealId);if(!deal)return res.status(404).json({error:'Deal not found'});try{res.json({dealReference:deal.dealReference,expectation:calculateExpectedCommission({...deal,...req.body})});}catch(error){res.status(400).json({error:error.message});}});

r.post('/crm/deals/:dealId/commission-expectations',async(req,res)=>{const key=requireIdempotency(req,res);if(!key)return;const result=await transaction(async client=>{const deal=await dealContext(req.params.dealId,client);if(!deal)return{code:404,error:'Deal not found'};const prior=await one('SELECT * FROM deal_commission_expectation_versions WHERE idempotency_key=$1',[key],client);if(prior)return{expectation:prior,replayed:true};let calc;try{calc=calculateExpectedCommission({...deal,...req.body});}catch(error){return{code:400,error:error.message};}if(calc.referralAmount>0&&!clean(req.body?.partnerOrganizationVersionId))return{code:400,error:'Select the referral partner before confirming a referral fee'};const latest=await one('SELECT COALESCE(MAX(version_number),0)::int AS n FROM deal_commission_expectation_versions WHERE deal_id=$1',[deal.id],client),id=uuid();
    const expectation=await one(`INSERT INTO deal_commission_expectation_versions(id,expectation_reference,deal_id,version_number,deal_version,opportunity_version,deal_type,agreed_value,currency,expected_gross_amount,partner_organization_version_id,referral_amount,referral_settlement_basis,expected_company_receipt,source_context_fingerprint,idempotency_key,status,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,'draft',$17) RETURNING *`,[id,`COM-${deal.dealReference}-${Number(latest.n)+1}`,deal.id,Number(latest.n)+1,deal.version,deal.opportunityVersion,deal.dealType,deal.agreedValue,deal.currency,calc.expectedGrossAmount,req.body?.partnerOrganizationVersionId||null,calc.referralAmount,calc.referralSettlementBasis,calc.expectedCompanyReceipt,calc.fingerprint,key,req.broker.id],client);
    for(const c of calc.components)await execute(`INSERT INTO deal_commission_expectation_components(id,expectation_version_id,represented_side,commission_percent,commission_minimum,percentage_result,expected_amount) VALUES($1,$2,$3,$4,$5,$6,$7)`,[uuid(),id,c.representedSide,c.commissionPercent,c.commissionMinimum,c.percentageResult,c.expectedAmount],client);
    await audit('DealCommissionExpectation',id,'draft_created',req.broker.id,{dealReference:deal.dealReference,versionNumber:expectation.versionNumber,expectedGrossAmount:calc.expectedGrossAmount,currency:deal.currency},client);return{expectation};});if(result.error)return res.status(result.code).json({error:result.error});res.status(result.replayed?200:201).json(result);});

r.post('/crm/deal-commission-expectations/:versionId/freeze',async(req,res)=>{const result=await transaction(async client=>{const item=await one('SELECT * FROM deal_commission_expectation_versions WHERE id=$1 FOR UPDATE',[req.params.versionId],client);if(!item)return{code:404,error:'Commission expectation not found'};if(item.status!=='draft')return{code:409,error:'Only a draft expectation can be frozen'};await execute("UPDATE deal_commission_expectation_versions SET status='superseded' WHERE deal_id=$1 AND status='frozen'",[item.dealId],client);const frozen=await one("UPDATE deal_commission_expectation_versions SET status='frozen',frozen_by=$1,frozen_at=NOW() WHERE id=$2 RETURNING *",[req.broker.id,item.id],client);await audit('DealCommissionExpectation',item.id,'frozen',req.broker.id,{dealId:item.dealId,versionNumber:item.versionNumber},client);return{expectation:frozen};});if(result.error)return res.status(result.code).json({error:result.error});res.json(result);});

r.post('/crm/deals/:dealId/commission-receipts',async(req,res)=>{
  if(!financeReceipt(req.broker))return res.status(403).json({error:'Accountant or Director receipt authority required'});
  const key=requireIdempotency(req,res);if(!key)return;
  let amount;try{amount=parseReceiptAmount(req.body?.amount);}catch(error){return res.status(400).json({error:error.message});}
  const receivedDate=clean(req.body?.receivedDate),
    financeReference=clean(req.body?.financeReference),method=clean(req.body?.receiptMethod);
  const receiptDateValue=new Date(`${receivedDate}T00:00:00.000Z`);
  if(!(amount>0)||!Number.isFinite(amount)||!/^\d{4}-\d{2}-\d{2}$/.test(receivedDate)||
      Number.isNaN(receiptDateValue.valueOf())||receiptDateValue.toISOString().slice(0,10)!==receivedDate||financeReference.length<3||
      !['bank_transfer','cheque','card','other_confirmed'].includes(method))
    return res.status(400).json({error:'Complete amount, received date, method and finance reference'});
  const result=await transaction(async client=>{
    await execute('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',[`commission-receipt:${key}`],client);
    const deal=await dealContext(req.params.dealId,client);
    if(!deal)return{code:404,error:'Deal not found'};
    await lockOpportunityFinance(deal.opportunityId,client);
    await execute('SELECT pg_advisory_xact_lock(hashtext($1))',[`receipt-confirm:${deal.id}`],client);
    const proof=await resolveReceiptProof(deal.id,req.body?.proofId,client);
    const evidenceReference=proof?proof.proofReference:clean(req.body?.evidenceReference);
    if(evidenceReference.length<3)return{code:400,error:'Select uploaded commission proof or provide an evidence reference'};
    const fingerprint=payoutFingerprint({dealId:deal.id,amount,receivedDate,method,financeReference,evidenceReference});
    const existing=await one('SELECT * FROM deal_commission_receipts WHERE idempotency_key=$1',[key],client);
    if(existing)return existing.dealId===deal.id&&existing.recordedBy===req.broker.id&&existing.evidenceFingerprint===fingerprint
      ?{receipt:existing,replayed:true}:{code:409,error:'Receipt key was already used for a different request'};
    const normalized=financeReference.toLowerCase().replace(/\s+/g,'');
    await execute('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',[`receipt-bank:${deal.currency}:${normalized}`],client);
    const linked=await one("SELECT id FROM commission_receivable_collections WHERE LOWER(regexp_replace(finance_reference,'\\s','','g'))=$1",[normalized],client);
    if(linked)return{code:409,error:'Payment already recorded against a receivable invoice. Do not record it again in Finance Receipts.'};
    const id=uuid();
    const receipt=await one(`INSERT INTO deal_commission_receipts
      (id,receipt_reference,deal_id,entry_type,amount,currency,received_date,receipt_method,finance_reference,
       normalized_finance_reference,evidence_reference,evidence_fingerprint,idempotency_key,recorded_by,proof_id)
      VALUES($1,$2,$3,'receipt',$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
      [id,`RCPT-${Date.now()}-${id.slice(0,8)}`,deal.id,amount,deal.currency,receivedDate,method,
       financeReference,financeReference.toLowerCase().replace(/\s+/g,''),evidenceReference,fingerprint,key,req.broker.id,proof?.id||null],client);
    await audit('DealCommissionReceipt',id,'recorded',req.broker.id,
      {dealReference:deal.dealReference,amount,currency:deal.currency,receivedDate,method,proofId:proof?.id||null},client);
    return{receipt};
  });
  if(result.error)return res.status(result.code).json({error:result.error});
  res.status(result.replayed?200:201).json(result);
});

r.post('/crm/deals/:dealId/commission-receipt-confirmations',async(req,res)=>{if(!financeReceipt(req.broker))return res.status(403).json({error:'Accountant or Director receipt authority required'});const key=requireIdempotency(req,res);if(!key)return;const result=await transaction(async client=>{await execute('SELECT pg_advisory_xact_lock(hashtext($1))',[`receipt-confirm:${req.params.dealId}`],client);const replay=await one('SELECT * FROM deal_commission_receipt_confirmations WHERE idempotency_key=$1',[key],client);if(replay)return{confirmation:replay,replayed:true};const deal=await dealContext(req.params.dealId,client);if(!deal)return{code:404,error:'Deal not found'};const expectation=await one("SELECT * FROM deal_commission_expectation_versions WHERE deal_id=$1 AND status='frozen'",[deal.id],client);if(!expectation)return{code:409,error:'Freeze the current expected commission before confirming receipt'};await lockOpportunityFinance(deal.opportunityId,client);const receipts=await opportunityReceipts(deal.opportunityId,client);let reconciled;try{reconciled=reconcileCommissionReceipt({expectedCompanyReceipt:expectation.expectedCompanyReceipt,receipts});}catch(error){return{code:409,error:error.message};}await execute("UPDATE deal_commission_receipt_confirmations SET status='superseded' WHERE id IN (SELECT id FROM opportunity_commission_confirmations WHERE finance_opportunity_id=$1 AND status='confirmed')",[deal.opportunityId],client);const latest=await one('SELECT COALESCE(MAX(version_number),0)::int AS n FROM deal_commission_receipt_confirmations WHERE deal_id=$1',[deal.id],client),id=uuid(),reason=meaningful(req.body?.reason,'A meaningful confirmation reason');const confirmation=await one(`INSERT INTO deal_commission_receipt_confirmations(id,confirmation_reference,deal_id,expectation_version_id,version_number,deal_version,receipt_date,currency,expected_company_receipt,confirmed_actual_received,variance_amount,aggregate_fingerprint,idempotency_key,status,reason,evidence_reference,confirmed_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'confirmed',$14,$15,$16) RETURNING *`,[id,`CONF-${deal.dealReference}-${Number(latest.n)+1}`,deal.id,expectation.id,Number(latest.n)+1,deal.version,reconciled.receiptDate,deal.currency,reconciled.expectedCompanyReceipt,reconciled.confirmedActualReceived,reconciled.varianceAmount,reconciled.aggregateFingerprint,key,reason,clean(req.body?.evidenceReference),req.broker.id],client);await audit('DealCommissionReceiptConfirmation',id,'confirmed',req.broker.id,{dealReference:deal.dealReference,actualReceived:reconciled.confirmedActualReceived,variance:reconciled.varianceAmount,receiptDate:reconciled.receiptDate},client);return{confirmation,closureReady:reconciled.varianceAmount===0};});if(result.error)return res.status(result.code).json({error:result.error});res.status(result.replayed?200:201).json(result);});

r.get('/crm/deals/:dealId/commission',async(req,res)=>{const deal=await dealContext(req.params.dealId);if(!deal)return res.status(404).json({error:'Deal not found'});const [expectations,receipts,confirmations,credits]=await Promise.all([many('SELECT * FROM deal_commission_expectation_versions WHERE deal_id=$1 ORDER BY version_number DESC',[deal.id]),opportunityReceipts(deal.opportunityId),many('SELECT *,receipt_date::text AS receipt_date FROM opportunity_commission_confirmations WHERE finance_opportunity_id=$1 ORDER BY confirmed_at DESC,id',[deal.opportunityId]),many('SELECT * FROM deal_agent_credit_versions WHERE deal_id=$1 ORDER BY version_number DESC',[deal.id])]);res.json({deal:{id:deal.id,dealReference:deal.dealReference,status:deal.status,currency:deal.currency,agreedValue:deal.agreedValue,originatingAgentSplitPercent:deal.originatingAgentSplitPercent,servicingAgentSplitPercent:deal.servicingAgentSplitPercent},expectations,receipts,confirmations,credits,directorPayoutEligible:director(req.broker)&&deal.status==='closed_won'});});

r.post('/crm/deals/:dealId/agent-credit',async(req,res)=>{const key=requireIdempotency(req,res);if(!key)return;const result=await transaction(async client=>{await execute('SELECT pg_advisory_xact_lock(hashtext($1))',[`receipt-confirm:${req.params.dealId}`],client);const deal=await dealContext(req.params.dealId,client);if(!deal)return{code:404,error:'Deal not found'};await lockOpportunityFinance(deal.opportunityId,client);if(deal.status!=='closed_won')return{code:409,error:'Closed Won is required before agent payout credit'};const confirmation=await one("SELECT * FROM opportunity_commission_confirmations WHERE finance_opportunity_id=$1 AND status='confirmed' ORDER BY confirmed_at DESC LIMIT 1",[deal.opportunityId],client),expectation=confirmation?await one("SELECT * FROM deal_commission_expectation_versions WHERE deal_id=$1 AND status='frozen'",[deal.id],client):null;if(!confirmation||!expectation)return{code:409,error:'Current confirmed commission receipt is required'};let allocation;try{allocation=allocateDealAgentCredit({confirmedActualReceived:confirmation.confirmedActualReceived,externalReferralAmount:expectation.referralAmount,referralSettlementBasis:expectation.referralSettlementBasis,originatingAgentId:deal.originatingAgentId,servicingAgentId:deal.servicingAgentId,originatingAgentSplitPercent:deal.originatingAgentSplitPercent,servicingAgentSplitPercent:deal.servicingAgentSplitPercent,currency:deal.currency});}catch(error){return{code:409,error:error.message};}const latest=await one('SELECT COALESCE(MAX(version_number),0)::int AS n FROM deal_agent_credit_versions WHERE deal_id=$1',[deal.id],client),id=uuid();await execute("UPDATE deal_agent_credit_versions SET status='superseded' WHERE deal_id=$1 AND status='frozen'",[deal.id],client);const credit=await one(`INSERT INTO deal_agent_credit_versions(id,credit_reference,deal_id,receipt_confirmation_id,version_number,source_opportunity_version,source_originating_split_percent,source_servicing_split_percent,currency,confirmed_actual_received,external_referral_amount,referral_settlement_basis,internal_credited_amount,source_context_fingerprint,idempotency_key,status,created_by,frozen_by,frozen_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,'frozen',$16,$16,NOW()) RETURNING *`,[id,`CREDIT-${deal.dealReference}-${Number(latest.n)+1}`,deal.id,confirmation.id,Number(latest.n)+1,deal.opportunityVersion,deal.originatingAgentSplitPercent,deal.servicingAgentSplitPercent,deal.currency,allocation.confirmedActualReceived,allocation.externalReferralAmount,allocation.referralSettlementBasis,allocation.internalCreditedAmount,allocation.fingerprint,key,req.broker.id],client);for(const line of allocation.lines)await execute(`INSERT INTO deal_agent_credit_lines(id,credit_version_id,agent_id,originating_percent,servicing_percent,total_credit_percent,credited_amount) VALUES($1,$2,$3,$4,$5,$6,$7)`,[uuid(),id,line.agentId,line.originatingPercent,line.servicingPercent,line.totalCreditPercent,line.creditedAmount],client);await audit('DealAgentCredit',id,'frozen_from_deal_split',req.broker.id,{dealReference:deal.dealReference,originatingSplit:deal.originatingAgentSplitPercent,servicingSplit:deal.servicingAgentSplitPercent,lineCount:allocation.lines.length,internalCreditedAmount:allocation.internalCreditedAmount},client);return{credit,lines:allocation.lines};});if(result.error)return res.status(result.code).json({error:result.error});res.status(201).json(result);});

r.get('/finance/agent-payouts',async(req,res)=>{if(!financeReceipt(req.broker))return res.status(403).json({error:'Accountant or MD commission-payment access required'});const rows=await many(`SELECT p.*,b.name AS agent_name,tier_broker.name AS tier_agent_name,d.deal_reference,d.agreed_value AS sale_price,o.opportunity_reference,
  COALESCE(NULLIF(CONCAT_WS(' · ',listing.inventory_reference,listing.project,listing.building,CASE WHEN listing.unit_reference IS NOT NULL THEN 'Unit '||listing.unit_reference END),''),'Property not recorded') AS property_sold,
  expectation.expected_gross_amount AS deal_gross_commission_ex_vat,
  COALESCE(collection.net_commission_cents/100.0,p.current_gross_commission_amount,credit.confirmed_actual_received) AS gross_commission_received_ex_vat,
  COALESCE(p.resulting_gross_commission_amount,p.resulting_cumulative_amount) AS quarter_gross_cumulative,
  line.total_credit_percent AS agent_commission_share_percent,bi.batch_id,bi.status AS batch_item_status,ba.batch_reference
  FROM agent_payout_calculations p JOIN brokers b ON b.id=p.agent_id JOIN deals d ON d.id=p.deal_id JOIN brokers tier_broker ON tier_broker.id=COALESCE(p.tier_agent_id,d.owner_id) JOIN opportunities o ON o.id=d.opportunity_id
  JOIN deal_agent_credit_lines line ON line.id=p.credit_line_id JOIN deal_agent_credit_versions credit ON credit.id=line.credit_version_id LEFT JOIN commission_receivable_collections collection ON collection.id=credit.source_collection_id LEFT JOIN listings listing ON listing.id=d.listing_id
  LEFT JOIN LATERAL (SELECT expected_gross_amount FROM deal_commission_expectation_versions e
    WHERE e.deal_id=d.id AND e.status='frozen' ORDER BY e.version_number DESC,e.id DESC LIMIT 1) expectation ON TRUE
  LEFT JOIN commission_payment_batch_items bi ON bi.calculation_id=p.id AND bi.status IN ('submitted','approved') LEFT JOIN commission_payment_batches ba ON ba.id=bi.batch_id
  WHERE ($1::text IS NULL OR p.quarter_key=$1) AND ($2::uuid IS NULL OR p.agent_id=$2) ORDER BY p.receipt_date,p.payout_reference`,[clean(req.query.quarter)||null,clean(req.query.agentId)||null]);for(const row of rows){row.bands=await many('SELECT * FROM agent_payout_calculation_bands WHERE calculation_id=$1 ORDER BY display_order',[row.id]);row.decisions=await many('SELECT decision,reason,evidence_reference,decided_at FROM agent_payout_decision_events WHERE calculation_id=$1 ORDER BY decided_at',[row.id]);row.releases=await many('SELECT event_type,released_amount,released_at,evidence_reference,recorded_at FROM agent_payout_release_events WHERE calculation_id=$1 ORDER BY recorded_at',[row.id]);}
  const eligible=await many(`SELECT l.id AS credit_line_id,l.agent_id,b.name AS agent_name,l.credited_amount,l.total_credit_percent,
      l.originating_percent,l.servicing_percent,d.id AS deal_id,d.deal_reference,o.opportunity_reference,v.currency,c.receipt_date,
      v.source_originating_split_percent,v.source_servicing_split_percent,v.confirmed_actual_received,d.owner_id AS tier_agent_id,tier_broker.name AS tier_agent_name,
      COALESCE((SELECT SUM(executing_line.total_credit_percent) FROM deal_agent_credit_lines executing_line WHERE executing_line.credit_version_id=v.id AND executing_line.agent_id=d.owner_id),0) AS tier_agent_deal_share_percent,
      EXISTS(SELECT 1 FROM commission_payout_policy_versions policy WHERE policy.currency=v.currency AND policy.status='active'
        AND policy.effective_from<=c.receipt_date AND (policy.effective_to IS NULL OR policy.effective_to>c.receipt_date)) AS policy_ready,
      COALESCE((SELECT social.status FROM agent_social_media_payout_status_versions social WHERE social.agent_id=d.owner_id
        AND social.effective_from<=c.receipt_date AND (social.effective_to IS NULL OR social.effective_to>c.receipt_date)
        ORDER BY social.effective_from DESC LIMIT 1),'inactive') AS social_media_payout_status
    FROM deal_agent_credit_lines l JOIN deal_agent_credit_versions v ON v.id=l.credit_version_id
    JOIN deal_commission_receipt_confirmations c ON c.id=v.receipt_confirmation_id JOIN deals d ON d.id=v.deal_id JOIN opportunities o ON o.id=d.opportunity_id
    JOIN brokers b ON b.id=l.agent_id JOIN brokers tier_broker ON tier_broker.id=d.owner_id LEFT JOIN agent_payout_calculations p ON p.credit_line_id=l.id
    WHERE v.status='frozen' AND d.status='closed_won' AND p.id IS NULL ORDER BY c.receipt_date,d.deal_reference,b.name`);
  const batches=await many(`SELECT ba.*,sb.name AS submitted_by_name,db.name AS decided_by_name,pb.name AS paid_by_name,
    COUNT(bi.id)::int AS row_count,COUNT(bi.id) FILTER(WHERE bi.status IN ('approved','paid'))::int AS approved_row_count,
    COUNT(DISTINCT p.agent_id) FILTER(WHERE bi.status IN ('approved','paid'))::int AS approved_agent_count,
    COALESCE(SUM(p.agent_payout_amount),0) AS submitted_total,
    COALESCE(SUM(p.agent_payout_amount) FILTER(WHERE bi.status IN ('approved','paid')),0) AS approved_total,
    MIN(p.release_due_date) FILTER(WHERE bi.status IN ('approved','paid')) AS earliest_due_date,
    MAX(p.release_due_date) FILTER(WHERE bi.status IN ('approved','paid')) AS latest_due_date
    FROM commission_payment_batches ba JOIN brokers sb ON sb.id=ba.submitted_by LEFT JOIN brokers db ON db.id=ba.decided_by
    LEFT JOIN brokers pb ON pb.id=ba.paid_by
    JOIN commission_payment_batch_items bi ON bi.batch_id=ba.id JOIN agent_payout_calculations p ON p.id=bi.calculation_id
    GROUP BY ba.id,sb.name,db.name,pb.name ORDER BY ba.submitted_at DESC`);
  for(const batch of batches)batch.items=await many(`SELECT bi.*,p.agent_id,p.payout_reference,p.agent_payout_amount,p.currency,p.release_due_date,p.status AS payout_status,p.trigger_method,p.current_credited_amount,
    CASE WHEN p.trigger_method='quarter_achieved_rate' THEN p.agent_payout_amount-ROUND(p.current_credited_amount*COALESCE((SELECT MAX(pb.agent_percent) FROM agent_payout_calculation_bands pb WHERE pb.calculation_id=p.id),0)/100,2) ELSE 0 END AS quarter_true_up_amount,
    b.name AS agent_name,d.deal_reference,o.opportunity_reference
    FROM commission_payment_batch_items bi JOIN agent_payout_calculations p ON p.id=bi.calculation_id JOIN brokers b ON b.id=p.agent_id JOIN deals d ON d.id=p.deal_id JOIN opportunities o ON o.id=d.opportunity_id
    WHERE bi.batch_id=$1 ORDER BY b.name,d.deal_reference`,[batch.id]);
  res.json({payouts:rows,eligible,batches,permissions:{canSubmit:accountant(req.broker),canApprove:director(req.broker),canRecordPayment:accountant(req.broker)}});});

r.get('/finance/agent-payouts/:agentId/quarters/:quarter/document',async(req,res)=>{
  if(!canReadAllCrmDocuments(req.broker)&&!financeReceipt(req.broker))return res.status(403).json({error:'Active account required'});
  const agentId=clean(req.params.agentId),quarter=clean(req.params.quarter);
  if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(agentId)||!/^\d{4}-Q[1-4]$/.test(quarter))return res.status(400).json({error:'A valid Agent and settlement quarter are required'});
  const agent=await one('SELECT id,name FROM brokers WHERE id=$1',[agentId]);
  const rows=await many(`SELECT p.*,o.opportunity_reference,d.deal_reference,d.agreed_value AS sale_price,
    COALESCE(NULLIF(CONCAT_WS(' · ',l.inventory_reference,l.project,l.building,CASE WHEN l.unit_reference IS NOT NULL THEN 'Unit '||l.unit_reference END),''),'Property not recorded') AS property_sold,
    tier_broker.name AS tier_agent_name,
    expectation.expected_gross_amount AS deal_gross_commission_ex_vat,
    COALESCE(collection.net_commission_cents/100.0,p.current_gross_commission_amount,credit.confirmed_actual_received) AS gross_commission_received_ex_vat,
    COALESCE(p.resulting_gross_commission_amount,p.resulting_cumulative_amount) AS quarter_gross_cumulative,
    line.originating_percent,line.servicing_percent,line.total_credit_percent AS agent_commission_share_percent,
    COALESCE((SELECT MAX(pb.agent_percent) FROM agent_payout_calculation_bands pb WHERE pb.calculation_id=p.id),0) AS achieved_rate,
    CASE WHEN p.trigger_method='quarter_achieved_rate' THEN p.agent_payout_amount-ROUND(p.current_credited_amount*COALESCE((SELECT MAX(pb.agent_percent) FROM agent_payout_calculation_bands pb WHERE pb.calculation_id=p.id),0)/100,2) ELSE 0 END AS quarter_true_up_amount,
    COALESCE((SELECT SUM(CASE WHEN re.event_type='release' THEN re.released_amount ELSE -re.released_amount END) FROM agent_payout_release_events re WHERE re.calculation_id=p.id),0) AS released_amount
    FROM agent_payout_calculations p JOIN deal_agent_credit_lines line ON line.id=p.credit_line_id JOIN deal_agent_credit_versions credit ON credit.id=line.credit_version_id LEFT JOIN commission_receivable_collections collection ON collection.id=credit.source_collection_id
    JOIN deals d ON d.id=p.deal_id JOIN brokers tier_broker ON tier_broker.id=COALESCE(p.tier_agent_id,d.owner_id) JOIN opportunities o ON o.id=d.opportunity_id LEFT JOIN listings l ON l.id=d.listing_id
    LEFT JOIN LATERAL (SELECT expected_gross_amount FROM deal_commission_expectation_versions e
      WHERE e.deal_id=d.id AND e.status='frozen' ORDER BY e.version_number DESC,e.id DESC LIMIT 1) expectation ON TRUE
    WHERE p.agent_id=$1 AND p.quarter_key=$2 AND p.status<>'reversed' ORDER BY p.receipt_date,p.payout_reference`,[agentId,quarter]);
  if(!agent||!rows.length)return res.status(404).json({error:'No payout calculation sheet exists for this Agent and quarter'});
  rows.forEach(row=>{row.currentDealPayout=Number(row.agentPayoutAmount)-Number(row.quarterTrueUpAmount||0);row.eligibleCommissionPool=Number(row.grossCommissionReceivedExVat)*Number(row.achievedRate)/100;row.agentRoleSplit=[Number(row.originatingPercent)>0?`Originating ${Number(row.originatingPercent).toFixed(2)}%`:null,Number(row.servicingPercent)>0?`Servicing ${Number(row.servicingPercent).toFixed(2)}%`:null].filter(Boolean).join(' + ');});
  const statement=buildQuarterPayoutStatement(rows);
  const organization=await one("SELECT * FROM organization_settings WHERE status='active' ORDER BY version DESC LIMIT 1")||{displayName:'NYSA Realty'};
  let logo=null;try{logo=organization.logoStorageKey?{buffer:await readPrivate(organization.logoStorageKey),mediaType:organization.logoMediaType}:{buffer:await readFile(new URL('../../public/brand/nysa/raster/nysa-horizontal-light@2x.png',import.meta.url)),mediaType:'image/png'};}catch{}
  const latestSourceDate=rows.map(row=>row.updatedAt||row.createdAt||row.receiptDate).filter(Boolean).sort().at(-1),generatedDate=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Dubai'}).format(new Date(latestSourceDate||Date.now())),currency=rows[0].currency||'AED',input={agent:agent.name,quarter,currency,rows:statement.rows,summary:statement.summary,organization,logo,generatedDate},data=commissionPayoutApprovedDocument(input),rendered=await makeCommissionPayoutSheetPdf(input),evidence=approvedDocumentEvidence('agent_payout',data,rendered),fileName=`NYSA-Payout-${clean(agent.name).replace(/[^a-z0-9]+/gi,'-')}-${quarter}.pdf`,idempotencyKey=`agent-payout:${agentId}:${quarter}:${evidence.dataHash}`;
  let createdStorageKey=null;
  try{
    const issued=await transaction(async client=>{
      await execute('SELECT pg_advisory_xact_lock(hashtext($1))',[`approved-agent-payout:${agentId}:${quarter}`],client);
      const existing=await one('SELECT i.document_version_id,dv.storage_key,dv.file_name FROM approved_document_issuances i JOIN document_versions dv ON dv.id=i.document_version_id WHERE i.idempotency_key=$1',[idempotencyKey],client);if(existing)return existing;
      const documentId=uuid(),documentVersionId=uuid(),documentReference=`NYSA-PAYOUT-${quarter}-${agentId.slice(0,8).toUpperCase()}-${evidence.dataHash.slice(0,8).toUpperCase()}`;createdStorageKey=await savePrivate(rendered,'.pdf');
      await execute(`INSERT INTO documents(id,document_reference,document_type,title,direction,access_classification,status,owner_id,created_by) VALUES($1,$2,'agent_payout',$3,'Internal','restricted','active',$4,$4)`,[documentId,documentReference,`Agent Payout · ${agent.name} · ${quarter}`,req.broker.id],client);
      await execute(`INSERT INTO document_versions(id,document_id,version_number,file_name,media_type,file_size_bytes,storage_key,file_hash,immutable,source,classification,status,owner_id,created_by) VALUES($1,$2,1,$3,'application/pdf',$4,$5,$6,1,'generated','restricted','generated',$7,$7)`,[documentVersionId,documentId,fileName,rendered.length,createdStorageKey,evidence.pdfHash,req.broker.id],client);
      for(const row of rows)if(row.dealId)await execute("INSERT INTO document_links(id,document_id,entity_type,entity_id,created_by) VALUES($1,$2,'Deal',$3,$4) ON CONFLICT DO NOTHING",[uuid(),documentId,row.dealId,req.broker.id],client);
      await recordApprovedDocumentIssuance({execute,uuid,client,documentCode:'agent_payout',data,pdf:rendered,documentVersionId,sourceEntityType:'AgentPayoutQuarter',sourceEntityId:agentId,issuedBy:req.broker.id,idempotencyKey});
      await audit('AgentPayoutCalculationSheet',agentId,'approved_document_issued',req.broker.id,{quarter,rowCount:rows.length,documentVersionId,dataHash:evidence.dataHash,pdfHash:evidence.pdfHash},client);return{documentVersionId,storageKey:createdStorageKey,fileName};
    });
    const committedStorageKey=createdStorageKey;createdStorageKey=null;const pdf=committedStorageKey&&issued.storageKey===committedStorageKey?rendered:await readPrivate(issued.storageKey);await audit('AgentPayoutCalculationSheet',agentId,'document_viewed',req.broker.id,{quarter,rowCount:rows.length,documentVersionId:issued.documentVersionId,download:req.query.download==='1'});res.setHeader('Content-Type','application/pdf');res.setHeader('Content-Disposition',`${req.query.download==='1'?'attachment':'inline'}; filename="${issued.fileName.replace(/"/g,'')}"`);res.setHeader('Cache-Control','private, no-store');res.end(pdf);
  }catch(error){if(createdStorageKey)await removePrivate(createdStorageKey).catch(()=>{});throw error;}
});

const preparationFailure=(message,statusCode=409)=>Object.assign(new Error(message),{statusCode,payoutPreparationFailure:true});
async function preparePayoutLine(lineId,key,brokerId,client){
  const replay=await one('SELECT * FROM agent_payout_calculations WHERE idempotency_key=$1',[key],client);
  if(replay)return{calculation:replay,replayed:true};
  const line=await one(`SELECT l.*,v.id AS credit_version_id,v.deal_id,v.currency,v.confirmed_actual_received,c.receipt_date,d.deal_reference,d.owner_id AS executing_agent_id
    FROM deal_agent_credit_lines l JOIN deal_agent_credit_versions v ON v.id=l.credit_version_id
    JOIN deal_commission_receipt_confirmations c ON c.id=v.receipt_confirmation_id JOIN deals d ON d.id=v.deal_id
    WHERE l.id=$1 AND v.status='frozen' AND d.status='closed_won' FOR UPDATE OF l`,[lineId],client);
  if(!line)throw preparationFailure('An eligible Closed Won commission credit is required');
  await execute('SELECT pg_advisory_xact_lock(hashtext($1))',[`agent-payout:${line.agentId}:${line.currency}:${line.receiptDate}`],client);
  const policy=await one(`SELECT * FROM commission_payout_policy_versions WHERE currency=$1 AND status='active' AND effective_from<=$2 AND (effective_to IS NULL OR effective_to>$2) ORDER BY effective_from DESC LIMIT 1`,[line.currency,line.receiptDate],client);
  if(!policy)throw preparationFailure('No active company payout policy covers this receipt date. Ask Admin to activate Commission & payout policy first.');
  const adjustment=await one(`SELECT * FROM agent_payout_adjustment_versions WHERE agent_id=$1 AND currency=$2 AND status='active' AND effective_from<=$3 AND (effective_to IS NULL OR effective_to>$3) ORDER BY effective_from DESC LIMIT 1`,[line.executingAgentId,line.currency,line.receiptDate],client);
  const resolved=adjustment?await adjustmentWithSlabs(adjustment,client):await policyWithSlabs(policy,client);
  const executingShare=await one(`SELECT COALESCE(SUM(total_credit_percent),0) AS share FROM deal_agent_credit_lines WHERE credit_version_id=$1 AND agent_id=$2`,[line.creditVersionId,line.executingAgentId],client),social=await one(`SELECT * FROM agent_social_media_payout_status_versions WHERE agent_id=$1 AND effective_from<=$2 AND (effective_to IS NULL OR effective_to>$2) ORDER BY effective_from DESC LIMIT 1`,[line.executingAgentId,line.receiptDate],client),socialUpliftEligible=social?.status==='active'&&Number(executingShare.share)===100,resolvedSlabs=applySocialMediaPayoutBonus(resolved.slabs,socialUpliftEligible);
  const quarter=receiptQuarterKey(line.receiptDate),prior=await one(`WITH receipt_basis AS (
      SELECT l.credit_version_id,MAX(COALESCE(p.current_gross_commission_amount,v.confirmed_actual_received)) AS gross_amount
      FROM agent_payout_calculations p JOIN deal_agent_credit_lines l ON l.id=p.credit_line_id JOIN deal_agent_credit_versions v ON v.id=l.credit_version_id
      WHERE p.tier_agent_id=$1 AND p.quarter_key=$2 AND p.currency=$3 AND p.status<>'reversed' AND l.credit_version_id<>$4
      GROUP BY l.credit_version_id
    ), recipient_basis AS (
      SELECT COALESCE(SUM(p.current_credited_amount),0) AS agent_basis_amount,
        COALESCE(SUM(p.agent_payout_amount-ROUND(p.current_credited_amount*COALESCE(p.social_media_bonus_percent,0)/100,2)),0) AS base_payout_amount
      FROM agent_payout_calculations p JOIN deal_agent_credit_lines l ON l.id=p.credit_line_id
      WHERE p.agent_id=$5 AND p.tier_agent_id=$1 AND p.quarter_key=$2 AND p.currency=$3 AND p.status<>'reversed' AND l.credit_version_id<>$4
    ) SELECT COALESCE((SELECT SUM(gross_amount) FROM receipt_basis),0) AS gross_amount,recipient_basis.agent_basis_amount,recipient_basis.base_payout_amount FROM recipient_basis`,[line.executingAgentId,quarter,line.currency,line.creditVersionId,line.agentId],client);
  let calc;try{calc=calculateRealtimePayout({agentId:line.agentId,tierAgentId:line.executingAgentId,dealReference:line.dealReference,currency:line.currency,receiptDate:line.receiptDate,
    priorGrossCommissionAmount:prior.grossAmount,currentGrossCommissionAmount:line.confirmedActualReceived,agentSharePercent:line.totalCreditPercent,
    priorAgentCommissionBasisAmount:prior.agentBasisAmount,priorBasePayoutAmount:prior.basePayoutAmount,
    triggerMethod:resolved.triggerMethod,slabs:resolvedSlabs,policyVersionId:policy.id,adjustmentVersionId:adjustment?.id||null,socialMediaStatusVersionId:social?.id||null,socialMediaBonusPercent:socialUpliftEligible?5:0});}catch(error){throw preparationFailure(error.message);}
  const id=uuid(),reference=`PAY-${line.dealReference}-${String(line.agentId).slice(0,8)}-${String(line.id).slice(0,8)}`;
  const saved=await one(`INSERT INTO agent_payout_calculations(id,payout_reference,credit_line_id,agent_id,tier_agent_id,deal_id,currency,receipt_date,quarter_key,prior_cumulative_amount,current_credited_amount,resulting_cumulative_amount,calculation_basis_version,prior_gross_commission_amount,current_gross_commission_amount,resulting_gross_commission_amount,agent_share_percent,social_media_uplift_eligible,trigger_method,policy_version_id,adjustment_version_id,social_media_status_version_id,social_media_bonus_percent,resolved_plan_fingerprint,cumulative_context_fingerprint,agent_payout_amount,company_retained_amount,release_due_date,idempotency_key,status,calculated_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,'calculated',$30) RETURNING *`,[id,reference,line.id,line.agentId,line.executingAgentId,line.dealId,line.currency,calc.receiptDate,calc.quarterKey,calc.priorCumulativeAmount,calc.currentCreditedAmount,calc.resultingCumulativeAmount,calc.calculationBasisVersion,calc.priorGrossCommissionAmount,calc.currentGrossCommissionAmount,calc.resultingGrossCommissionAmount,calc.agentSharePercent,socialUpliftEligible,calc.triggerMethod,policy.id,adjustment?.id||null,calc.socialMediaStatusVersionId,calc.socialMediaBonusPercent,calc.resolvedPlanFingerprint,calc.cumulativeContextFingerprint,calc.agentPayoutAmount,calc.companyRetainedAmount,calc.releaseDueDate,key,brokerId],client);
  for(const band of calc.bands)await execute(`INSERT INTO agent_payout_calculation_bands(id,calculation_id,display_order,slab_lower_amount,slab_upper_amount,portion_amount,agent_percent,agent_payout_amount,company_retained_amount) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)`,[uuid(),id,band.displayOrder,band.lowerAmount,band.upperAmount,band.portionAmount,band.agentPercent,band.agentPayoutAmount,band.companyRetainedAmount],client);
  await audit('AgentPayoutCalculation',id,'prepared_by_accountant',brokerId,{dealReference:line.dealReference,agentId:line.agentId,quarterKey:calc.quarterKey,agentPayout:calc.agentPayoutAmount,socialMediaBonusPercent:calc.socialMediaBonusPercent},client);
  return{calculation:saved,bands:calc.bands,replayed:false};
}

r.post('/finance/agent-payouts/prepare-batch',async(req,res)=>{
  if(!accountant(req.broker))return res.status(403).json({error:'Accountant prepares commission-payment rows'});
  const key=requireIdempotency(req,res);if(!key)return;
  const ids=[...new Set((req.body?.creditLineIds||[]).map(clean).filter(value=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)))];
  if(!ids.length||ids.length!==(req.body?.creditLineIds||[]).length)return res.status(400).json({error:'Select one or more valid commission-payment rows'});
  try{
    const result=await transaction(async client=>{
      const ordered=await many(`SELECT l.id FROM deal_agent_credit_lines l JOIN deal_agent_credit_versions v ON v.id=l.credit_version_id JOIN deal_commission_receipt_confirmations c ON c.id=v.receipt_confirmation_id JOIN deals d ON d.id=v.deal_id JOIN brokers b ON b.id=l.agent_id LEFT JOIN commission_receivable_collections collection ON collection.id=v.source_collection_id WHERE l.id=ANY($1::uuid[]) ORDER BY c.receipt_date,COALESCE(collection.created_at,v.frozen_at),d.deal_reference,b.name,l.id`,[ids],client);
      if(ordered.length!==ids.length)throw preparationFailure('One or more selected commission-payment rows are no longer available');
      const prepared=[];for(const row of ordered)prepared.push(await preparePayoutLine(row.id,`${key}:${row.id}`,req.broker.id,client));
      return{calculations:prepared.map(item=>item.calculation),replayed:prepared.every(item=>item.replayed)};
    });
    res.status(result.replayed?200:201).json(result);
  }catch(error){if(error.payoutPreparationFailure)return res.status(error.statusCode||409).json({error:error.message});throw error;}
});

r.post('/finance/deal-agent-credit-lines/:lineId/payout/calculate',async(req,res)=>{if(!accountant(req.broker))return res.status(403).json({error:'Accountant prepares commission-payment rows'});const key=requireIdempotency(req,res);if(!key)return;try{const result=await transaction(client=>preparePayoutLine(req.params.lineId,key,req.broker.id,client));res.status(result.replayed?200:201).json(result);}catch(error){if(error.payoutPreparationFailure)return res.status(error.statusCode||409).json({error:error.message});throw error;}});

r.post('/finance/commission-payment-batches',async(req,res)=>{if(!accountant(req.broker))return res.status(403).json({error:'Accountant access required to submit commission payments'});const key=requireIdempotency(req,res);if(!key)return;const ids=[...new Set((req.body?.calculationIds||[]).map(clean).filter(Boolean))];if(!ids.length)return res.status(400).json({error:'Select at least one commission-payment row'});const result=await transaction(async client=>{const replay=await one('SELECT * FROM commission_payment_batches WHERE idempotency_key=$1',[key],client);if(replay)return{batch:replay,replayed:true};const rows=await many(`SELECT * FROM agent_payout_calculations WHERE id=ANY($1::uuid[]) FOR UPDATE`,[ids],client);if(rows.length!==ids.length||rows.some(x=>x.status!=='calculated'))return{code:409,error:'Every selected row must be ready for approval'};if(new Set(rows.map(x=>x.currency)).size!==1)return{code:409,error:'A consolidated approval batch must use one currency'};const active=await one(`SELECT bi.calculation_id FROM commission_payment_batch_items bi WHERE bi.calculation_id=ANY($1::uuid[]) AND bi.status IN ('submitted','approved') LIMIT 1`,[ids],client);if(active)return{code:409,error:'A selected row is already in an active approval batch'};const id=uuid(),reference=`CPB-${new Date().toISOString().slice(0,10).replaceAll('-','')}-${id.slice(0,8).toUpperCase()}`,batch=await one(`INSERT INTO commission_payment_batches(id,batch_reference,currency,idempotency_key,submitted_by) VALUES($1,$2,$3,$4,$5) RETURNING *`,[id,reference,rows[0].currency,key,req.broker.id],client);for(const row of rows)await execute(`INSERT INTO commission_payment_batch_items(id,batch_id,calculation_id) VALUES($1,$2,$3)`,[uuid(),id,row.id],client);await audit('CommissionPaymentBatch',id,'submitted',req.broker.id,{batchReference:reference,rowCount:rows.length,total:rows.reduce((n,x)=>n+Number(x.agentPayoutAmount),0),currency:rows[0].currency},client);return{batch};});if(result.error)return res.status(result.code).json({error:result.error});res.status(result.replayed?200:201).json(result);});

r.post('/finance/commission-payment-batches/:batchId/decision',async(req,res)=>{if(!director(req.broker))return res.status(403).json({error:'MD approval access required'});const selected=[...new Set((req.body?.selectedCalculationIds||[]).map(clean).filter(Boolean))],reason=meaningful(req.body?.reason,'MD approval reason'),evidence=clean(req.body?.evidenceReference);if(!selected.length||evidence.length<3)return res.status(400).json({error:'Select at least one payout row and provide approval evidence'});const result=await transaction(async client=>{const batch=await one(`SELECT * FROM commission_payment_batches WHERE id=$1 FOR UPDATE`,[req.params.batchId],client);if(!batch)return{code:404,error:'Commission-payment batch not found'};if(batch.status!=='submitted')return{code:409,error:'This batch has already been decided'};const items=await many(`SELECT * FROM commission_payment_batch_items WHERE batch_id=$1 FOR UPDATE`,[batch.id],client),allowed=new Set(items.map(x=>x.calculationId));if(selected.some(id=>!allowed.has(id)))return{code:400,error:'Selected payout row does not belong to this batch'};await execute(`UPDATE commission_payment_batch_items SET status=CASE WHEN calculation_id=ANY($2::uuid[]) THEN 'approved' ELSE 'deferred' END WHERE batch_id=$1`,[batch.id,selected],client);await execute(`UPDATE agent_payout_calculations SET status='approved' WHERE id=ANY($1::uuid[]) AND status='calculated'`,[selected],client);for(const id of selected)await one(`INSERT INTO agent_payout_decision_events(id,calculation_id,decision,reason,evidence_reference,request_fingerprint,decided_by) VALUES($1,$2,'approved',$3,$4,$5,$6) RETURNING id`,[uuid(),id,reason,evidence,payoutFingerprint({batchId:batch.id,calculationId:id,decision:'approved',reason,evidence}),req.broker.id],client);const status=selected.length===items.length?'approved':'partially_approved',updated=await one(`UPDATE commission_payment_batches SET status=$1,decided_by=$2,decided_at=NOW(),decision_reason=$3,evidence_reference=$4 WHERE id=$5 RETURNING *`,[status,req.broker.id,reason,evidence,batch.id],client);await audit('CommissionPaymentBatch',batch.id,'md_approved',req.broker.id,{batchReference:batch.batchReference,approvedRows:selected.length,deferredRows:items.length-selected.length},client);return{batch:updated};});if(result.error)return res.status(result.code).json({error:result.error});res.json(result);});

r.post('/finance/commission-payment-batches/:batchId/release',async(req,res)=>{if(!accountant(req.broker))return res.status(403).json({error:'Accountant records the approved commission-payment batch'});const key=requireIdempotency(req,res);if(!key)return;const paymentDate=clean(req.body?.paymentDate),paymentReference=clean(req.body?.paymentReference),today=dubaiCalendarDate(new Date());if(!/^\d{4}-\d{2}-\d{2}$/.test(paymentDate)||paymentDate>today||paymentReference.length<3)return res.status(400).json({error:'Enter the actual batch payment date (not a future date) and bank payment reference'});const result=await transaction(async client=>{const replay=await one('SELECT * FROM commission_payment_batches WHERE payment_idempotency_key=$1',[key],client);if(replay)return{batch:replay,replayed:true};const batch=await one('SELECT * FROM commission_payment_batches WHERE id=$1 FOR UPDATE',[req.params.batchId],client);if(!batch)return{code:404,error:'Commission-payment batch not found'};if(!['approved','partially_approved'].includes(batch.status)||batch.paymentStatus!=='awaiting_payment')return{code:409,error:'Only an unpaid MD-approved batch can be recorded'};if(paymentDate<dubaiCalendarDate(batch.decidedAt))return{code:400,error:'Batch payment date cannot be earlier than the MD approval date'};const items=await many(`SELECT bi.id AS batch_item_id,bi.calculation_id,p.payout_reference,p.agent_payout_amount,p.status FROM commission_payment_batch_items bi JOIN agent_payout_calculations p ON p.id=bi.calculation_id WHERE bi.batch_id=$1 AND bi.status='approved' FOR UPDATE OF bi,p`,[batch.id],client);if(!items.length||items.some(item=>item.status!=='approved'))return{code:409,error:'Every approved row in this batch must still be awaiting payment'};for(const item of items){const releaseId=uuid();await one(`INSERT INTO agent_payout_release_events(id,release_reference,calculation_id,event_type,released_amount,released_at,evidence_reference,idempotency_key,recorded_by) VALUES($1,$2,$3,'release',$4,$5,$6,$7,$8) RETURNING id`,[releaseId,`REL-${batch.batchReference}-${String(item.calculationId).slice(0,8)}`,item.calculationId,item.agentPayoutAmount,`${paymentDate}T12:00:00+04:00`,paymentReference,`${key}:${item.calculationId}`,req.broker.id],client);}const calculationIds=items.map(item=>item.calculationId);await execute("UPDATE agent_payout_calculations SET status='released' WHERE id=ANY($1::uuid[])",[calculationIds],client);await execute("UPDATE commission_payment_batch_items SET status='paid' WHERE batch_id=$1 AND status='approved'",[batch.id],client);const updated=await one("UPDATE commission_payment_batches SET payment_status='paid',payment_date=$1,payment_reference=$2,payment_idempotency_key=$3,paid_by=$4,paid_at=NOW() WHERE id=$5 RETURNING *",[paymentDate,paymentReference,key,req.broker.id,batch.id],client);await createAdviceIntents(updated,req.broker.id,client);const total=items.reduce((sum,item)=>sum+Number(item.agentPayoutAmount),0);await audit('CommissionPaymentBatch',batch.id,'paid_by_accountant',req.broker.id,{batchReference:batch.batchReference,rowCount:items.length,total,currency:batch.currency,paymentDate,paymentReference},client);return{batch:updated,rowCount:items.length,total};});if(result.error)return res.status(result.code).json({error:result.error});res.status(result.replayed?200:201).json(result);});

r.post('/finance/agent-payout-calculations/:calculationId/decision',async(req,res)=>{if(!director(req.broker))return res.status(403).json({error:'Director-only payout access required'});const decision=clean(req.body?.decision);if(!['approved','returned'].includes(decision))return res.status(400).json({error:'Select approve or return'});const reason=meaningful(req.body?.reason),evidence=clean(req.body?.evidenceReference);const result=await transaction(async client=>{const item=await one('SELECT * FROM agent_payout_calculations WHERE id=$1 FOR UPDATE',[req.params.calculationId],client);if(!item)return{code:404,error:'Payout calculation not found'};if(item.status!=='calculated')return{code:409,error:'Only a calculated payout can be decided'};const event=await one(`INSERT INTO agent_payout_decision_events(id,calculation_id,decision,reason,evidence_reference,request_fingerprint,decided_by) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`,[uuid(),item.id,decision,reason,evidence,payoutFingerprint({calculationId:item.id,decision,reason,evidence}),req.broker.id],client);if(decision==='approved')await execute("UPDATE agent_payout_calculations SET status='approved' WHERE id=$1",[item.id],client);await audit('AgentPayoutCalculation',item.id,decision,req.broker.id,{payoutReference:item.payoutReference,reason},client);return{event};});if(result.error)return res.status(result.code).json({error:result.error});res.json(result);});

r.post('/finance/agent-payout-calculations/:calculationId/release',async(req,res)=>{if(!accountant(req.broker))return res.status(403).json({error:'Accountant records the approved agent payment'});const key=requireIdempotency(req,res);if(!key)return;const result=await transaction(async client=>{const item=await one('SELECT * FROM agent_payout_calculations WHERE id=$1 FOR UPDATE',[req.params.calculationId],client);if(!item)return{code:404,error:'Commission payment not found'};if(item.status!=='approved')return{code:409,error:'MD approval is required before recording payment'};const amount=Number(req.body?.releasedAmount),releasedAt=clean(req.body?.releasedAt),evidence=clean(req.body?.evidenceReference),date=String(releasedAt).slice(0,10);if(amount!==Number(item.agentPayoutAmount)||!/^\d{4}-\d{2}-\d{2}$/.test(date)||date>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Dubai'}).format(new Date())||evidence.length<3)return{code:400,error:'Enter the approved amount, actual payment date (not a future date), and bank payment reference'};const id=uuid(),event=await one(`INSERT INTO agent_payout_release_events(id,release_reference,calculation_id,event_type,released_amount,released_at,evidence_reference,idempotency_key,recorded_by) VALUES($1,$2,$3,'release',$4,$5,$6,$7,$8) RETURNING *`,[id,`REL-${item.payoutReference}`,item.id,amount,`${date}T12:00:00+04:00`,evidence,key,req.broker.id],client);await execute("UPDATE agent_payout_calculations SET status='released' WHERE id=$1",[item.id],client);await execute("UPDATE commission_payment_batch_items SET status='paid' WHERE calculation_id=$1 AND status='approved'",[item.id],client);await audit('AgentPayoutRelease',id,'recorded_by_accountant',req.broker.id,{payoutReference:item.payoutReference,releasedAmount:amount,releasedAt:date},client);return{release:event};});if(result.error)return res.status(result.code).json({error:result.error});res.status(201).json(result);});

registerDirectorSummary(r);
export default r;

