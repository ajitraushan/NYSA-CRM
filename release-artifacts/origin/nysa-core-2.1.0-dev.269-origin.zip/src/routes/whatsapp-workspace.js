import crypto from 'node:crypto';
import path from 'node:path';
import {Router} from '../lib/http-kit.js';
import {requireAuth} from '../auth.js';
import {audit,execute,many,one,transaction,uuid} from '../db.js';
import {campaignCommand,classifyWhatsAppSuppression,recipientEligibility,recipientMatchesSegment,reviewWhatsAppRecipientRows,uniqueSegmentPhoneCount} from '../whatsapp-campaign-domain.js';
import {getContactSuppression,recordContactSuppression,releaseContactSuppression} from '../contact-suppression.js';
import {displayMetaStatus,normalizeSegmentDraft,normalizeWhatsAppPhone,recipientDecision,validateCampaignDraft,validateMaterialDraft,validateRecipientImport,validateTemplateDraft,workspaceHash} from '../whatsapp-workspace-domain.js';
import {decodeAndValidateFile,readPrivate,removePrivate,savePrivate} from '../private-files.js';
import {inspectWhatsAppRecipientFile,parseWhatsAppRecipientFile,validateRecipientBatchMetadata} from '../whatsapp-recipient-import.js';
import {simulatedProviderConfig} from '../whatsapp-simulated-provider.js';
import {replyLockState,selectConversationWithReplyLock,writeReplyLock} from '../whatsapp-reply-lock.js';

const r=Router(),operational=new Set(['sales_agent','manager','director']),creator=new Set(['sales_agent','manager','director']);
const clean=(value,max=500)=>String(value??'').trim().slice(0,max);
const ids=value=>(Array.isArray(value)?value:[]).map(String).filter(Boolean);
const materialTypes=['application/pdf','image/jpeg','image/png','video/mp4'];
const megabyte=1024*1024;
const headerMediaPolicy={
  image:{types:['image/jpeg','image/png'],maxBytes:5*megabyte,label:'JPG or PNG up to 5 MB'},
  video:{types:['video/mp4'],maxBytes:16*megabyte,label:'MP4 up to 16 MB'},
  document:{types:['application/pdf'],maxBytes:Number(process.env.MAX_DOCUMENT_BYTES||10*megabyte),label:'PDF'}
};
const token=(payload,session)=>crypto.createHmac('sha256',String(session||'')).update(JSON.stringify(payload)).digest('hex');
const equal=(a,b)=>{const x=Buffer.from(String(a||'')),y=Buffer.from(String(b||''));return x.length===y.length&&x.length>0&&crypto.timingSafeEqual(x,y);};
const clientTimezone=req=>{const candidate=clean(req.headers?.['x-client-time-zone'],100)||'UTC';try{new Intl.DateTimeFormat('en-GB',{timeZone:candidate}).format();return candidate;}catch{return'UTC';}};
const clientLockTime=(value,req)=>new Intl.DateTimeFormat('en-GB',{dateStyle:'medium',timeStyle:'short',timeZone:clientTimezone(req)}).format(new Date(value));

r.use(requireAuth,async(req,res,next)=>{
  if(req.broker?.role!=='internal_broker'||!operational.has(req.broker.jobRole))return res.status(403).json({error:'WhatsApp Campaigns is restricted to Sales Agents, Managers and Directors'});
  if(req.broker.jobRole==='director'){req.broker.whatsAppTeamIds=null;return next();}
  const rows=await many(`SELECT DISTINCT t.id FROM teams t
    WHERE t.active=1 AND (
      t.id=$2
      OR EXISTS(SELECT 1 FROM team_memberships tm WHERE tm.team_id=t.id AND tm.broker_id=$1 AND tm.ends_at IS NULL)
      OR EXISTS(SELECT 1 FROM user_role_assignments ur WHERE ur.team_id=t.id AND ur.broker_id=$1 AND ur.status='active' AND ur.ends_at IS NULL)
      OR ($3='manager' AND t.manager_id=$1)
    ) ORDER BY t.id`,[req.broker.id,req.broker.teamId||null,req.broker.jobRole]);
  req.broker.whatsAppTeamIds=rows.map(row=>String(row.id));
  next();
});

function teamIds(broker){
  if(broker.jobRole==='director')return null;
  return [...new Set((broker.whatsAppTeamIds||[]).filter(Boolean).map(String))];
}
function canUseTeam(broker,teamId){const scope=teamIds(broker);return scope===null||scope.includes(String(teamId||''));}
function publicMaterial(material){const{storageKey,...safe}=material;return{...safe,hasFile:Boolean(storageKey)};}
function canRetireCampaign(broker,campaign){if(broker.jobRole==='sales_agent')return String(campaign.preparedBy)===String(broker.id)&&['draft','returned'].includes(campaign.status);return ['manager','director'].includes(broker.jobRole)&&canUseTeam(broker,campaign.ownerTeamId)&&['draft','pending_approval','approved','returned'].includes(campaign.status);}
function requireCreator(req,res){if(!creator.has(req.broker.jobRole)){res.status(403).json({error:'Operational WhatsApp workspace access required'});return false;}return true;}
function requireReviewer(req,res){if(!['manager','director'].includes(req.broker.jobRole)){res.status(403).json({error:'Manager or Director review access required'});return false;}return true;}
function scope(alias,broker,params){const teams=teamIds(broker);if(teams===null)return'1=1';params.push(teams);return`${alias}.owner_team_id=ANY($${params.length}::uuid[])`;}
async function lock(key,client){await execute('SELECT pg_advisory_xact_lock(hashtextextended($1,0))',[key],client);}
async function applyCrossChannelSuppression(phone,type,evidenceReference,actorId,client){
  await recordContactSuppression({phone,type,evidenceReference,actorId,auditExpiresAt:new Date(Date.now()+365*86400000).toISOString(),reason:type==='dncr'?'Manual DNCR evidence (not a registry check)':null},client);
  const changed=await many(`UPDATE wa_campaign_recipients SET suppression_status='suppressed',suppressed_at=NOW(),suppression_reason=$2,consent_status=CASE WHEN $2='opt_out' THEN 'withdrawn' ELSE 'denied' END WHERE normalized_phone=$1 RETURNING id`,[phone,type],client);
  await execute(`UPDATE wa_campaign_approval_recipients SET removed_at=COALESCE(removed_at,NOW()),removal_reason=COALESCE(removal_reason,$2) WHERE normalized_phone=$1`,[phone,type],client);
  await execute(`UPDATE contacts SET do_not_contact=1,contact_restriction_reason=$2,updated_at=NOW() WHERE id IN (SELECT matched_contact_id FROM wa_campaign_recipients WHERE normalized_phone=$1 AND matched_contact_id IS NOT NULL) OR id IN (SELECT contact_id FROM contact_channels WHERE channel_kind='Phone' AND normalized_value=$1)`,[phone,`${type==='dncr'?'Manual DNCR':'WhatsApp '+type} evidence ${evidenceReference}`],client);
  return changed.length;
}
async function accessibleTeams(broker,client){
  const values=teamIds(broker),params=[];let where='t.active=1';
  if(values!==null){params.push(values);where+=` AND t.id=ANY($${params.length}::uuid[])`;}
  return many(`SELECT t.id,t.name,t.manager_id,b.name AS manager_name FROM teams t LEFT JOIN brokers b ON b.id=t.manager_id WHERE ${where} ORDER BY t.name`,params,client);
}
async function approverCount(teamId,excludeId,client){const row=await one(`SELECT COUNT(DISTINCT b.id)::int AS count FROM brokers b
  WHERE b.status='active' AND b.id<>$2 AND (b.job_role='director' OR (b.job_role='manager' AND (b.id=(SELECT manager_id FROM teams WHERE id=$1) OR EXISTS(SELECT 1 FROM team_memberships tm WHERE tm.team_id=$1 AND tm.broker_id=b.id AND tm.membership_role='manager' AND tm.ends_at IS NULL))))`,[teamId,excludeId],client);return Number(row?.count||0);}
async function existingPhoneMap(client){
  const map=new Map(),customers=await many(`SELECT c.id,c.customer_reference,COALESCE(ch.normalized_value,c.phone) AS phone FROM contacts c LEFT JOIN contact_channels ch ON ch.contact_id=c.id AND ch.channel_kind='Phone' AND ch.is_primary=1 WHERE COALESCE(ch.normalized_value,c.phone) IS NOT NULL`,[],client);
  for(const item of customers){const phone=normalizeWhatsAppPhone(item.phone);if(phone)map.set(phone,{kind:'customer',id:item.id,reference:item.customerReference});}
  const recipients=await many(`SELECT r.id,r.normalized_phone,b.batch_reference FROM wa_campaign_recipients r JOIN wa_recipient_import_batches b ON b.id=r.batch_id`,[],client);
  for(const item of recipients){const phone=normalizeWhatsAppPhone(item.normalizedPhone);if(phone&&!map.has(phone))map.set(phone,{kind:'recipient',id:item.id,reference:item.batchReference});}
  return map;
}
async function templateContext(id,client){return one(`SELECT v.*,t.name,t.owner_team_id,t.template_reference,t.lifecycle_status,t.name_locked_at FROM wa_message_template_versions v JOIN wa_message_templates t ON t.id=v.template_id WHERE v.id=$1`,[id],client);}
async function campaignContext(id,client){return one(`SELECT c.*,s.name AS segment_name,s.definition,t.name AS template_name,v.version_number AS template_version_number,v.body_text,v.variable_samples,v.internal_status,v.meta_status FROM wa_campaign_drafts c JOIN wa_audience_segments s ON s.id=c.segment_id JOIN wa_message_template_versions v ON v.id=c.template_version_id JOIN wa_message_templates t ON t.id=v.template_id WHERE c.id=$1`,[id],client);}
function previewValue(name,recipient,samples={}){const requirements=recipient.requirements||{};if(name==='name')return recipient.name;return requirements[name]??samples[name]??`[${name}]`;}
function renderedMessage(template,recipient){return String(template.bodyText||'').replace(/\{\{([a-z][a-z0-9_]*)\}\}/g,(_token,name)=>String(previewValue(name,recipient,template.variableSamples||{})));}
async function campaignRecipients(campaign,client){
  const rows=await many(`SELECT r.*,b.owner_team_id FROM wa_campaign_recipients r JOIN wa_recipient_import_batches b ON b.id=r.batch_id WHERE b.owner_team_id=$1`,[campaign.ownerTeamId],client),seen=new Set(),selected=[];
  for(const row of rows){const recipient={...row,phone:row.normalizedPhone,source:row.sourceCode};if(!recipientMatchesSegment(recipient,campaign.definition||{}))continue;const phone=normalizeWhatsAppPhone(row.normalizedPhone);if(!phone||seen.has(phone))continue;seen.add(phone);const shared=await getContactSuppression(phone,client),eligibility=recipientEligibility({phone,consentStatus:row.consentStatus,consentEvidenceRef:row.consentEvidenceRef,suppressed:shared.blocked||row.suppressionStatus==='suppressed'});selected.push({...row,normalizedPhone:phone,eligibility,suppressionType:shared.strongest});}
  return selected;
}
async function applySharedSuppressions(review,client){
  const counts={...review.counts,suppressed:0};
  for(const row of review.rows){
    const phone=normalizeWhatsAppPhone(row.phone);if(!phone)continue;
    const shared=await getContactSuppression(phone,client);if(!shared.blocked)continue;
    if(Number.isInteger(counts[row.action])&&counts[row.action]>0)counts[row.action]--;
    row.action='suppressed';row.suppressionType=shared.strongest;row.errors=[...(row.errors||[]),`Shared restriction: ${shared.strongest}`];counts.suppressed++;
  }
  review.counts=counts;
  return review;
}
async function campaignPreview(campaign,client){
  const recipients=await campaignRecipients(campaign,client),rows=recipients.map(item=>({recipientId:item.id,name:item.name,phone:item.normalizedPhone,eligible:item.eligibility.eligible,eligibilityReason:item.eligibility.reason,message:renderedMessage(campaign,item)}));
  return{rows,totalUniquePhones:rows.length,eligibleCount:rows.filter(item=>item.eligible).length,excludedCount:rows.filter(item=>!item.eligible).length};
}
async function validateHeaderMaterial(draft,teamId,client){
  if(!headerMediaPolicy[draft.headerType])return null;
  const material=await one("SELECT * FROM wa_material_catalogue WHERE id=$1 AND status='active'",[draft.headerMaterialId],client),policy=headerMediaPolicy[draft.headerType];
  if(!material||String(material.ownerTeamId)!==String(teamId))return`Select active ${draft.headerType} header media from the template team`;
  if(!material.storageKey||!policy.types.includes(material.mediaType)||Number(material.fileSizeBytes)>policy.maxBytes)return`Header ${draft.headerType} must use ${policy.label} from the Materials catalogue`;
  return null;
}
async function saveTemplateVersion({templateId,versionNumber,draft,preparedBy,autoApprove=false,id=uuid()},client){
  return one(`INSERT INTO wa_message_template_versions(id,template_id,version_number,language_code,category,header_type,header_text,header_material_id,body_text,footer_text,variable_names,variable_samples,buttons,prepared_by,content_hash)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) RETURNING *`,[id,templateId,versionNumber,draft.languageCode,draft.category,draft.headerType,draft.headerText,draft.headerMaterialId,draft.bodyText,draft.footerText,draft.variableNames,draft.variableSamples,JSON.stringify(draft.buttons),preparedBy,workspaceHash(draft)],client).then(async version=>{
      if(!autoApprove)return version;
      return one("UPDATE wa_message_template_versions SET internal_status='approved',submitted_at=NOW(),reviewed_by=$1,reviewed_at=NOW(),review_reason='Auto-approved by authorized creator',updated_at=NOW() WHERE id=$2 RETURNING *",[preparedBy,version.id],client);
    });
}

function recipientFile(req){
  const fileName=clean(req.body?.originalFileName||req.body?.fileName,240),lower=fileName.toLowerCase(),mediaType=lower.endsWith('.xlsx')?'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'text/csv';
  return decodeAndValidateFile({base64:req.body?.base64,mediaType,fileName,maxBytes:10*megabyte,allowedTypes:['text/csv','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']});
}
async function recipientPayload(req,{allowInspection=false}={}){
  if(!req.body?.base64)return{rows:req.body?.rows,fileHash:null,fileFormat:clean(req.body?.fileFormat,10)||'csv'};
  const file=recipientFile(req);if(file.error)return{error:file.error};
  const mediaType=String(file.fileName).toLowerCase().endsWith('.xlsx')?'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'text/csv',fileFormat=mediaType==='text/csv'?'csv':'xlsx';
  try{
    const inspection=await inspectWhatsAppRecipientFile({buffer:file.buffer,mediaType}),mapping=req.body?.columnMapping||{},suggested=Object.fromEntries(inspection.headers.filter(item=>item.suggestedField).map(item=>[item.suggestedField,item.index])),effective={...suggested,...mapping};
    if(allowInspection&&(!Number.isInteger(Number(effective.name))||!Number.isInteger(Number(effective.phone))))return{mappingRequired:true,inspection,fileHash:file.fileHash,fileFormat};
    const rows=await parseWhatsAppRecipientFile({buffer:file.buffer,mediaType,columnMapping:effective});
    return{rows,fileHash:file.fileHash,fileFormat,inspection,columnMapping:effective};
  }catch(error){return{error:`Recipient file could not be reviewed: ${error.message}`};}
}
function inboxScope(broker,params){
  if(broker.jobRole==='director')return'1=1';
  if(broker.jobRole==='sales_agent'){params.push(broker.id);return`c.owner_agent_id=$${params.length}`;}
  const teams=teamIds(broker)||[];params.push(teams);return`c.owner_team_id=ANY($${params.length}::uuid[])`;
}
function canUseConversation(broker,conversation){
  if(broker.jobRole==='director')return true;
  if(broker.jobRole==='sales_agent')return String(conversation.ownerAgentId||'')===String(broker.id);
  return canUseTeam(broker,conversation.ownerTeamId);
}

r.get('/crm/whatsapp-workspace',async(req,res)=>{
  const result=await transaction(async client=>{
    const params=[],where=scope('t',req.broker,params),templates=await many(`SELECT t.id,t.template_reference,t.name,t.owner_team_id,t.lifecycle_status,t.name_locked_at,t.created_at,team.name AS team_name,
      v.id AS version_id,v.version_number,v.language_code,v.category,v.header_type,v.header_text,v.header_material_id,v.body_text,v.footer_text,v.variable_names,v.variable_samples,v.buttons,v.internal_status,v.meta_status,v.simulated_provider_status,v.simulated_provider_status_at,v.simulated_provider_reason,v.prepared_by,v.submitted_at,v.reviewed_by,v.reviewed_at,v.review_reason,v.updated_at,
      hm.title AS header_material_title,hm.media_type AS header_material_media_type,hm.file_name AS header_material_file_name,
      creator.name AS prepared_by_name,reviewer.name AS reviewed_by_name
      FROM wa_message_templates t JOIN teams team ON team.id=t.owner_team_id
      LEFT JOIN LATERAL(SELECT * FROM wa_message_template_versions x WHERE x.template_id=t.id ORDER BY x.version_number DESC LIMIT 1)v ON TRUE
      LEFT JOIN brokers creator ON creator.id=v.prepared_by LEFT JOIN brokers reviewer ON reviewer.id=v.reviewed_by LEFT JOIN wa_material_catalogue hm ON hm.id=v.header_material_id
      WHERE ${where} ORDER BY t.updated_at DESC`,params,client);
    const materialParams=[],materialWhere=scope('m',req.broker,materialParams),materials=await many(`SELECT m.*,team.name AS team_name,b.name AS created_by_name FROM wa_material_catalogue m JOIN teams team ON team.id=m.owner_team_id JOIN brokers b ON b.id=m.created_by WHERE ${materialWhere} ORDER BY m.updated_at DESC`,materialParams,client);
    const segmentParams=[],segmentWhere=scope('s',req.broker,segmentParams),segments=await many(`SELECT s.*,team.name AS team_name,b.name AS created_by_name FROM wa_audience_segments s JOIN teams team ON team.id=s.owner_team_id JOIN brokers b ON b.id=s.created_by WHERE ${segmentWhere} ORDER BY s.updated_at DESC`,segmentParams,client);
    const recipientParams=[],batchWhere=scope('b',req.broker,recipientParams),batches=await many(`SELECT b.*,team.name AS team_name,u.name AS created_by_name FROM wa_recipient_import_batches b LEFT JOIN teams team ON team.id=b.owner_team_id JOIN brokers u ON u.id=b.created_by WHERE ${batchWhere} ORDER BY b.created_at DESC LIMIT 100`,recipientParams,client);
    const campaignParams=[],campaignWhere=scope('c',req.broker,campaignParams),campaigns=await many(`SELECT c.*,s.name AS segment_name,t.name AS template_name,v.version_number AS template_version_number,v.meta_status,team.name AS team_name,p.name AS prepared_by_name,d.name AS decision_by_name,
      (SELECT COUNT(*)::int FROM wa_campaign_materials cm WHERE cm.campaign_id=c.id) AS material_count,
      (SELECT COALESCE(array_agg(cm.material_id),ARRAY[]::uuid[]) FROM wa_campaign_materials cm WHERE cm.campaign_id=c.id) AS material_ids,
      (SELECT COUNT(*)::int FROM wa_campaign_approval_recipients ar WHERE ar.campaign_id=c.id AND ar.revision=c.approved_revision AND ar.simulated_provider_message_id IS NOT NULL) AS simulated_sent_count,
      (SELECT COUNT(*)::int FROM wa_campaign_approval_recipients ar WHERE ar.campaign_id=c.id AND ar.revision=c.approved_revision AND ar.simulated_status IN ('delivered','read')) AS simulated_delivered_count,
      (SELECT COUNT(*)::int FROM wa_campaign_approval_recipients ar WHERE ar.campaign_id=c.id AND ar.revision=c.approved_revision AND ar.simulated_status='read') AS simulated_read_count,
      (SELECT COUNT(*)::int FROM wa_campaign_approval_recipients ar WHERE ar.campaign_id=c.id AND ar.revision=c.approved_revision AND ar.simulated_status='failed') AS simulated_failed_count
      FROM wa_campaign_drafts c JOIN wa_audience_segments s ON s.id=c.segment_id JOIN wa_message_template_versions v ON v.id=c.template_version_id JOIN wa_message_templates t ON t.id=v.template_id JOIN teams team ON team.id=c.owner_team_id JOIN brokers p ON p.id=c.prepared_by LEFT JOIN brokers d ON d.id=c.decision_by
      WHERE ${campaignWhere} ORDER BY c.updated_at DESC`,campaignParams,client);
    const countParams=[],countWhere=scope('b',req.broker,countParams),recipients=await many(`SELECT r.*,b.owner_team_id,b.batch_reference FROM wa_campaign_recipients r JOIN wa_recipient_import_batches b ON b.id=r.batch_id WHERE ${countWhere}`,countParams,client);
    for(const segment of segments)segment.recipientCount=uniqueSegmentPhoneCount(recipients.map(item=>({batchId:item.batchId,normalizedPhone:item.normalizedPhone,source:item.sourceCode,tags:item.tags,requirements:item.requirements,consentStatus:item.consentStatus})),segment.definition);
    const reviewQueue=['manager','director'].includes(req.broker.jobRole)?{
      templates:templates.filter(item=>item.internalStatus==='pending_approval').map(item=>({...item,metaStatusLabel:displayMetaStatus(item.metaStatus)})),
      campaigns:campaigns.filter(item=>item.status==='pending_approval').map(item=>({...item,metaStatusLabel:displayMetaStatus(item.metaStatus)}))
    }:{templates:[],campaigns:[]};
    const inboxParams=[],conversationWhere=inboxScope(req.broker,inboxParams),conversations=await many(`SELECT c.*,team.name AS team_name,agent.name AS owner_agent_name,
      (SELECT COUNT(*)::int FROM wa_inbox_notifications n WHERE n.conversation_id=c.id AND n.broker_id=$${inboxParams.length+1} AND n.read_at IS NULL) AS unread_count,
      (SELECT body FROM wa_conversation_messages m WHERE m.conversation_id=c.id ORDER BY m.occurred_at DESC LIMIT 1) AS last_message
      FROM wa_conversations c JOIN teams team ON team.id=c.owner_team_id LEFT JOIN brokers agent ON agent.id=c.owner_agent_id
      WHERE ${conversationWhere} ORDER BY c.last_activity_at DESC LIMIT 200`,[...inboxParams,req.broker.id],client);
    const now=Date.now();for(const item of conversations){item.replyWindowOpen=Boolean(item.lastCustomerMessageAt&&now-Date.parse(item.lastCustomerMessageAt)<=24*60*60*1000);item.ctwaFreeWindowOpen=Boolean(['ctwa','website_ctwa'].includes(item.sourceType)&&item.ctwaEntryAt&&now-Date.parse(item.ctwaEntryAt)<=72*60*60*1000);}
    const simulation=simulatedProviderConfig();
    return{teams:await accessibleTeams(req.broker,client),templates:templates.map(item=>({...item,metaStatusLabel:displayMetaStatus(item.metaStatus)})),materials:materials.map(publicMaterial),segments,batches,campaigns:campaigns.map(item=>({...item,metaStatusLabel:displayMetaStatus(item.metaStatus),canRetire:canRetireCampaign(req.broker,item)})),conversations,reviewQueue,permissions:{canCreate:creator.has(req.broker.jobRole),canReview:['manager','director'].includes(req.broker.jobRole),canReassign:['manager','director'].includes(req.broker.jobRole)},provider:{connected:process.env.WHATSAPP_STAGE_B_TEST_NUMBER_CONNECTED==='true',submissionEnabled:simulation.enabled,sendingEnabled:simulation.enabled,status:simulation.enabled?'Simulated':'Not submitted',simulated:simulation.enabled,badge:simulation.enabled?'SIMULATED':null,externalNetwork:false}};
  });
  res.setHeader('Cache-Control','no-store');res.json(result);
});

r.post('/crm/whatsapp-workspace/templates',async(req,res)=>{
  if(!requireCreator(req,res))return;const checked=validateTemplateDraft(req.body||{}),teamId=clean(req.body?.teamId,36);if(!checked.valid)return res.status(400).json({error:checked.errors[0],errors:checked.errors});if(!canUseTeam(req.broker,teamId))return res.status(403).json({error:'Template team is outside your scope'});
  const result=await transaction(async client=>{await lock(`wa-template-name:${teamId}:${checked.value.name.toLowerCase()}`,client);if(await one("SELECT id FROM wa_message_templates WHERE owner_team_id=$1 AND LOWER(name)=LOWER($2) AND lifecycle_status<>'retired'",[teamId,checked.value.name],client))return{code:409,error:'An active template with this name already exists for the team'};const mediaError=await validateHeaderMaterial(checked.value,teamId,client);if(mediaError)return{code:409,error:mediaError};const autoApprove=['manager','director'].includes(req.broker.jobRole),id=uuid(),reference=`WA-TPL-${new Date().getUTCFullYear()}-${id.slice(0,8).toUpperCase()}`,template=await one(`INSERT INTO wa_message_templates(id,template_reference,name,owner_team_id,lifecycle_status,created_by,name_locked_at) VALUES($1,$2,$3,$4,$5,$6,CASE WHEN $7 THEN NOW() ELSE NULL END) RETURNING *`,[id,reference,checked.value.name,teamId,autoApprove?'active':'draft',req.broker.id,autoApprove],client),version=await saveTemplateVersion({templateId:id,versionNumber:1,draft:checked.value,preparedBy:req.broker.id,autoApprove},client);await execute(`INSERT INTO wa_campaign_audit(id,entity_type,entity_id,action,actor_id,details) VALUES($1,'message_template',$2,$3,$4,$5)`,[uuid(),id,autoApprove?'internally_approved':'draft_created',req.broker.id,{version:1,contentHash:checked.contentHash,selfApproval:autoApprove}],client);await audit('WhatsAppMessageTemplate',id,autoApprove?'internally_approved':'draft_created',req.broker.id,{reference,version:1,metaStatus:'not_submitted',headerType:checked.value.headerType,buttonCount:checked.value.buttons.length,selfApproval:autoApprove},client);return{template,version};});if(result.error)return res.status(result.code).json({error:result.error});res.status(201).json(result);
});

r.patch('/crm/whatsapp-workspace/template-versions/:id',async(req,res)=>{
  if(!requireCreator(req,res))return;const checked=validateTemplateDraft(req.body||{});if(!checked.valid)return res.status(400).json({error:checked.errors[0],errors:checked.errors});const result=await transaction(async client=>{const current=await templateContext(req.params.id,client);if(!current)return{code:404,error:'Template version not found'};if(!canUseTeam(req.broker,current.ownerTeamId))return{code:403,error:'Template is outside your scope'};if(!['draft','returned'].includes(current.internalStatus))return{code:409,error:'Only a draft or returned template version can be edited'};if(String(current.preparedBy)!==String(req.broker.id)&&!['manager','director'].includes(req.broker.jobRole))return{code:403,error:'Only the preparer or an authorized Manager/Director may edit this template draft'};if(current.nameLockedAt&&checked.value.name!==current.name)return{code:409,error:'Template name is locked after first submission'};await lock(`wa-template-name:${current.ownerTeamId}:${checked.value.name.toLowerCase()}`,client);if(await one("SELECT id FROM wa_message_templates WHERE owner_team_id=$1 AND LOWER(name)=LOWER($2) AND lifecycle_status<>'retired' AND id<>$3",[current.ownerTeamId,checked.value.name,current.templateId],client))return{code:409,error:'An active template with this name already exists for the team'};const mediaError=await validateHeaderMaterial(checked.value,current.ownerTeamId,client);if(mediaError)return{code:409,error:mediaError};const version=await one(`UPDATE wa_message_template_versions SET language_code=$1,category=$2,header_type=$3,header_text=$4,header_material_id=$5,body_text=$6,footer_text=$7,variable_names=$8,variable_samples=$9,buttons=$10,content_hash=$11,internal_status='draft',review_reason=NULL,updated_at=NOW() WHERE id=$12 RETURNING *`,[checked.value.languageCode,checked.value.category,checked.value.headerType,checked.value.headerText,checked.value.headerMaterialId,checked.value.bodyText,checked.value.footerText,checked.value.variableNames,checked.value.variableSamples,JSON.stringify(checked.value.buttons),checked.contentHash,current.id],client);await execute('UPDATE wa_message_templates SET name=$1,updated_at=NOW() WHERE id=$2',[checked.value.name,current.templateId],client);await audit('WhatsAppMessageTemplate',current.templateId,'draft_updated',req.broker.id,{version:current.versionNumber,contentHash:checked.contentHash,headerType:checked.value.headerType,buttonCount:checked.value.buttons.length},client);return{version};});if(result.error)return res.status(result.code).json({error:result.error});res.json(result);
});

r.post('/crm/whatsapp-workspace/templates/:id/versions',async(req,res)=>{
  if(!requireCreator(req,res))return;const checked=validateTemplateDraft(req.body||{});if(!checked.valid)return res.status(400).json({error:checked.errors[0],errors:checked.errors});const result=await transaction(async client=>{const template=await one('SELECT * FROM wa_message_templates WHERE id=$1 FOR UPDATE',[req.params.id],client);if(!template)return{code:404,error:'Template not found'};if(!canUseTeam(req.broker,template.ownerTeamId))return{code:403,error:'Template is outside your scope'};if(template.nameLockedAt&&checked.value.name!==template.name)return{code:409,error:'Template name is locked after first submission'};if(await one("SELECT id FROM wa_message_template_versions WHERE template_id=$1 AND internal_status IN('draft','pending_approval','returned')",[template.id],client))return{code:409,error:'Complete or retire the open template version first'};await lock(`wa-template-name:${template.ownerTeamId}:${checked.value.name.toLowerCase()}`,client);if(await one("SELECT id FROM wa_message_templates WHERE owner_team_id=$1 AND LOWER(name)=LOWER($2) AND lifecycle_status<>'retired' AND id<>$3",[template.ownerTeamId,checked.value.name,template.id],client))return{code:409,error:'An active template with this name already exists for the team'};const mediaError=await validateHeaderMaterial(checked.value,template.ownerTeamId,client);if(mediaError)return{code:409,error:mediaError};const autoApprove=['manager','director'].includes(req.broker.jobRole),latest=await one('SELECT COALESCE(MAX(version_number),0)::int AS value FROM wa_message_template_versions WHERE template_id=$1',[template.id],client),versionNumber=Number(latest.value)+1;if(autoApprove)await execute("UPDATE wa_message_template_versions SET internal_status='superseded',updated_at=NOW() WHERE template_id=$1 AND internal_status='approved'",[template.id],client);const version=await saveTemplateVersion({templateId:template.id,versionNumber,draft:checked.value,preparedBy:req.broker.id,autoApprove},client);await execute('UPDATE wa_message_templates SET lifecycle_status=$1,name_locked_at=COALESCE(name_locked_at,CASE WHEN $2 THEN NOW() ELSE NULL END),updated_at=NOW() WHERE id=$3',[autoApprove?'active':'draft',autoApprove,template.id],client);await audit('WhatsAppMessageTemplate',template.id,autoApprove?'internally_approved':'version_drafted',req.broker.id,{version:versionNumber,contentHash:checked.contentHash,headerType:checked.value.headerType,buttonCount:checked.value.buttons.length,selfApproval:autoApprove},client);return{version};});if(result.error)return res.status(result.code).json({error:result.error});res.status(201).json(result);
});

r.post('/crm/whatsapp-workspace/template-versions/:id/submit',async(req,res)=>{
  if(!requireCreator(req,res))return;const result=await transaction(async client=>{const current=await templateContext(req.params.id,client);if(!current)return{code:404,error:'Template version not found'};if(!canUseTeam(req.broker,current.ownerTeamId))return{code:403,error:'Template is outside your scope'};if(!['draft','returned'].includes(current.internalStatus))return{code:409,error:'Only a draft or returned template may be submitted'};if(String(current.preparedBy)!==String(req.broker.id)&&!['manager','director'].includes(req.broker.jobRole))return{code:403,error:'Only the preparer or an authorized Manager/Director may submit this template'};const version=await one("UPDATE wa_message_template_versions SET internal_status='pending_approval',submitted_at=NOW(),reviewed_by=NULL,reviewed_at=NULL,review_reason=NULL,updated_at=NOW() WHERE id=$1 RETURNING *",[current.id],client);await execute('UPDATE wa_message_templates SET name_locked_at=COALESCE(name_locked_at,NOW()),updated_at=NOW() WHERE id=$1',[current.templateId],client);await audit('WhatsAppMessageTemplate',current.templateId,'submitted_for_internal_approval',req.broker.id,{version:current.versionNumber,metaStatus:'not_submitted',nameLocked:true},client);return{version};});if(result.error)return res.status(result.code).json({error:result.error});res.json(result);
});

r.post('/crm/whatsapp-workspace/template-versions/:id/decision',async(req,res)=>{
  if(!requireReviewer(req,res))return;const decision=clean(req.body?.decision,20),reason=clean(req.body?.reason,500);if(!['approve','return'].includes(decision))return res.status(400).json({error:'Decision must be approve or return'});if(decision==='return'&&reason.length<5)return res.status(400).json({error:'Return reason must contain at least 5 characters'});const result=await transaction(async client=>{const current=await templateContext(req.params.id,client);if(!current)return{code:404,error:'Template version not found'};if(!canUseTeam(req.broker,current.ownerTeamId))return{code:403,error:'Template is outside your review scope'};if(current.internalStatus!=='pending_approval')return{code:409,error:'Only a pending template can be reviewed'};if(decision==='approve')await execute("UPDATE wa_message_template_versions SET internal_status='superseded',updated_at=NOW() WHERE template_id=$1 AND internal_status='approved' AND id<>$2",[current.templateId,current.id],client);const status=decision==='approve'?'approved':'returned',version=await one(`UPDATE wa_message_template_versions SET internal_status=$1,reviewed_by=$2,reviewed_at=NOW(),review_reason=$3,updated_at=NOW() WHERE id=$4 RETURNING *`,[status,req.broker.id,reason||null,current.id],client);await execute("UPDATE wa_message_templates SET lifecycle_status=$1,name_locked_at=COALESCE(name_locked_at,NOW()),updated_at=NOW() WHERE id=$2",[decision==='approve'?'active':'draft',current.templateId],client);const selfApproval=String(current.preparedBy)===String(req.broker.id);await audit('WhatsAppMessageTemplate',current.templateId,decision==='approve'?'internally_approved':'returned',req.broker.id,{version:current.versionNumber,reason:reason||null,metaStatus:'not_submitted',selfApproval},client);return{version};});if(result.error)return res.status(result.code).json({error:result.error});res.json(result);
});

r.post('/crm/whatsapp-workspace/recipient-imports/preview',async(req,res)=>{
  if(!requireCreator(req,res))return;const teamId=clean(req.body?.teamId,36);if(!canUseTeam(req.broker,teamId))return res.status(403).json({error:'Import team is outside your scope'});const metadata=validateRecipientBatchMetadata(req.body||{});if(!metadata.valid)return res.status(400).json({error:metadata.errors[0],errors:metadata.errors});const parsed=await recipientPayload(req,{allowInspection:true});if(parsed.error)return res.status(400).json({error:parsed.error});if(parsed.mappingRequired)return res.json({...parsed,originalFileName:clean(req.body?.originalFileName||req.body?.fileName,240)});const result=await transaction(async client=>{const checked=validateRecipientImport({...req.body,rows:parsed.rows,existingPhones:await existingPhoneMap(client)});if(!checked.valid)return{code:400,error:checked.errors[0],errors:checked.errors};await applySharedSuppressions(checked.review,client);const fileHash=parsed.fileHash||checked.fileHash,payload={teamId,originalFileName:checked.originalFileName,fileHash,fileFormat:parsed.fileFormat,metadata:metadata.value,columnMapping:parsed.columnMapping||{},rows:checked.review.rows.map(row=>({rowNumber:row.rowNumber,fingerprint:row.fingerprint,action:row.action}))},previewHash=workspaceHash(payload);return{...checked.review,originalFileName:checked.originalFileName,fileHash,fileFormat:parsed.fileFormat,metadata:metadata.value,columnMapping:parsed.columnMapping||{},inputRowCount:checked.review.rows.length,reconciledRowCount:checked.review.rows.length,previewHash,reviewToken:token(payload,req.token),normalizedRows:parsed.rows};});if(result.error)return res.status(result.code).json({error:result.error,errors:result.errors});res.json(result);
});

r.post('/crm/whatsapp-workspace/recipient-imports/commit',async(req,res)=>{
  if(!requireCreator(req,res))return;
  const teamId=clean(req.body?.teamId,36);if(!canUseTeam(req.broker,teamId))return res.status(403).json({error:'Import team is outside your scope'});
  const metadata=validateRecipientBatchMetadata(req.body||{});if(!metadata.valid)return res.status(400).json({error:metadata.errors[0],errors:metadata.errors});
  const parsed={rows:req.body?.normalizedRows??req.body?.rows,fileHash:clean(req.body?.fileHash,64),fileFormat:clean(req.body?.fileFormat,10)||'csv',columnMapping:req.body?.columnMapping||{}};
  const result=await transaction(async client=>{
    const checked=validateRecipientImport({...req.body,rows:parsed.rows,existingPhones:await existingPhoneMap(client)});if(!checked.valid)return{code:400,error:checked.errors[0],errors:checked.errors};
    await applySharedSuppressions(checked.review,client);
    const fileHash=parsed.fileHash||checked.fileHash,payload={teamId,originalFileName:checked.originalFileName,fileHash,fileFormat:parsed.fileFormat,metadata:metadata.value,columnMapping:parsed.columnMapping,rows:checked.review.rows.map(row=>({rowNumber:row.rowNumber,fingerprint:row.fingerprint,action:row.action}))},previewHash=workspaceHash(payload);
    if(!equal(previewHash,req.body?.previewHash)||!equal(req.body?.reviewToken,token(payload,req.token)))return{code:409,error:'Recipient data or suppression state changed after preview; review the file again'};
    await lock(`wa-recipient-import:${req.broker.id}:${fileHash}`,client);if(await one('SELECT id FROM wa_recipient_import_batches WHERE file_hash=$1 AND created_by=$2',[fileHash,req.broker.id],client))return{code:409,error:'This exact recipient file has already been committed by you'};
    const decisions=new Map((Array.isArray(req.body?.decisions)?req.body.decisions:[]).map(item=>[Number(item.rowNumber),item])),resolved=checked.review.rows.map(row=>({row,...recipientDecision(row,decisions.get(row.rowNumber))})),decisionError=resolved.find(item=>item.error);if(decisionError)return{code:400,error:decisionError.error};
    const included=resolved.filter(item=>item.include),suppressed=resolved.filter(item=>item.row.action==='suppressed');if(!included.length&&!suppressed.length)return{code:400,error:'Select at least one valid recipient'};
    const batchId=uuid(),reference=`WA-RCP-${new Date().getUTCFullYear()}-${batchId.slice(0,8).toUpperCase()}`,ready=resolved.filter(item=>item.row.action==='ready'&&item.include).length,review=resolved.filter(item=>item.row.action==='review_required').length,invalid=resolved.filter(item=>['invalid','suppressed'].includes(item.row.action)).length,batch=await one(`INSERT INTO wa_recipient_import_batches(id,batch_reference,original_file_name,file_hash,status,row_count,ready_count,review_count,invalid_count,created_by,owner_team_id,committed_at,file_format,source_type,source_description,supplier_name,supplier_batch_reference,acquisition_date,source_evidence_ref,raw_expires_at) VALUES($1,$2,$3,$4,'committed',$5,$6,$7,$8,$9,$10,NOW(),$11,$12,$13,$14,$15,$16,$17,NOW()) RETURNING *`,[batchId,reference,checked.originalFileName,fileHash,checked.review.rows.length,ready,review,invalid,req.broker.id,teamId,parsed.fileFormat,metadata.value.sourceType,metadata.value.sourceDescription,metadata.value.supplierName,metadata.value.supplierBatchReference,metadata.value.acquisitionDate,metadata.value.sourceEvidenceRef],client);
    for(const item of [...included,...suppressed]){const row=item.row,match=row.existingMatch,contactId=item.disposition==='linked'&&match?.kind==='customer'?match.id:null,isSuppressed=row.action==='suppressed';await execute(`INSERT INTO wa_campaign_recipients(id,batch_id,row_number,name,normalized_phone,email,requirements,tags,source_code,consent_status,consent_evidence_ref,suppression_status,suppressed_at,suppression_reason,duplicate_disposition,matched_contact_id,fingerprint) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,CASE WHEN $12='suppressed' THEN NOW() ELSE NULL END,$13,$14,$15,$16)`,[uuid(),batchId,row.rowNumber,row.name,row.phone,row.email,row.requirements,row.tags,metadata.value.sourceType,isSuppressed?(row.suppressionType==='opt_out'?'withdrawn':'denied'):row.consentStatus,row.consentEvidenceRef,isSuppressed?'suppressed':'not_suppressed',isSuppressed?row.suppressionType:null,item.disposition,contactId,row.fingerprint],client);}
    const details={reference,inputRows:checked.review.rows.length,reconciledRows:resolved.length,includedCount:included.length,excludedCount:resolved.length-included.length,retainedSuppressedCount:suppressed.length,sourceType:metadata.value.sourceType,rawFileStored:false};
    await execute(`INSERT INTO wa_campaign_audit(id,entity_type,entity_id,action,actor_id,details) VALUES($1,'recipient_import',$2,'committed',$3,$4)`,[uuid(),batchId,req.broker.id,details],client);await audit('WhatsAppRecipientImport',batchId,'committed',req.broker.id,{...details,createsLead:false,createsCustomer:false},client);return{batch,includedCount:included.length,excludedCount:resolved.length-included.length,retainedSuppressedCount:suppressed.length,inputRowCount:checked.review.rows.length,reconciledRowCount:resolved.length};
  });if(result.error)return res.status(result.code).json({error:result.error,errors:result.errors});res.status(201).json(result);
});

r.post('/crm/whatsapp-workspace/segments',async(req,res)=>{
  if(!requireCreator(req,res))return;let checked;try{checked=normalizeSegmentDraft(req.body||{});}catch(error){return res.status(400).json({error:error.message});}const teamId=clean(req.body?.teamId,36);if(!checked.valid)return res.status(400).json({error:checked.errors[0],errors:checked.errors});if(!canUseTeam(req.broker,teamId))return res.status(403).json({error:'Segment team is outside your scope'});const result=await transaction(async client=>{await lock(`wa-segment:${teamId}:${checked.value.name.toLowerCase()}`,client);if(await one("SELECT id FROM wa_audience_segments WHERE owner_team_id=$1 AND LOWER(name)=LOWER($2) AND status='active'",[teamId,checked.value.name],client))return{code:409,error:'An active segment with this name already exists'};const segment=await one(`INSERT INTO wa_audience_segments(id,name,description,definition,owner_team_id,created_by,updated_by) VALUES($1,$2,$3,$4,$5,$6,$6) RETURNING *`,[uuid(),checked.value.name,checked.value.description,checked.value.definition,teamId,req.broker.id],client);await audit('WhatsAppAudienceSegment',segment.id,'created',req.broker.id,{name:segment.name,definition:segment.definition},client);return{segment};});if(result.error)return res.status(result.code).json({error:result.error});res.status(201).json(result);
});

r.post('/crm/whatsapp-workspace/segments/:id/retire',async(req,res)=>{
  if(!requireCreator(req,res))return;const result=await transaction(async client=>{const segment=await one('SELECT * FROM wa_audience_segments WHERE id=$1 FOR UPDATE',[req.params.id],client);if(!segment)return{code:404,error:'Segment not found'};if(!canUseTeam(req.broker,segment.ownerTeamId))return{code:403,error:'Segment is outside your scope'};if(segment.status==='retired')return{segment};const updated=await one("UPDATE wa_audience_segments SET status='retired',retired_at=NOW(),updated_at=NOW(),updated_by=$1 WHERE id=$2 RETURNING *",[req.broker.id,segment.id],client);await audit('WhatsAppAudienceSegment',segment.id,'retired',req.broker.id,{});return{segment:updated};});if(result.error)return res.status(result.code).json({error:result.error});res.json(result);
});

r.post('/crm/whatsapp-workspace/materials',async(req,res)=>{
  if(!requireCreator(req,res))return;const checked=validateMaterialDraft(req.body||{}),teamId=clean(req.body?.teamId,36);if(!checked.valid)return res.status(400).json({error:checked.errors[0],errors:checked.errors});if(!canUseTeam(req.broker,teamId))return res.status(403).json({error:'Material team is outside your scope'});let file=null,key=null;if(req.body?.base64||req.body?.fileName||req.body?.mediaType){const mediaType=String(req.body?.mediaType||''),maxBytes=mediaType.startsWith('image/')?5*megabyte:mediaType==='video/mp4'?16*megabyte:Number(process.env.MAX_DOCUMENT_BYTES||10*megabyte);file=decodeAndValidateFile({...req.body,maxBytes,allowedTypes:materialTypes});if(file.error)return res.status(400).json({error:file.error});key=await savePrivate(file.buffer,path.extname(file.fileName));}try{const result=await transaction(async client=>{const id=uuid(),reference=`WA-MAT-${new Date().getUTCFullYear()}-${id.slice(0,8).toUpperCase()}`,material=await one(`INSERT INTO wa_material_catalogue(id,material_reference,title,material_type,description,owner_team_id,file_name,media_type,file_size_bytes,storage_key,file_hash,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,[id,reference,checked.value.title,checked.value.materialType,checked.value.description,teamId,file?.fileName||null,req.body?.mediaType||null,file?.buffer.length||null,key,file?.fileHash||null,req.broker.id],client);await audit('WhatsAppMaterial',id,'catalogued',req.broker.id,{reference,materialType:checked.value.materialType,fileHash:file?.fileHash||null},client);return{material:publicMaterial(material)};});res.status(201).json(result);}catch(error){if(key)await removePrivate(key);throw error;}
});

r.get('/crm/whatsapp-workspace/materials/:id/file',async(req,res)=>{const material=await one('SELECT * FROM wa_material_catalogue WHERE id=$1',[req.params.id]);if(!material?.storageKey)return res.status(404).json({error:'Material file not found'});if(!canUseTeam(req.broker,material.ownerTeamId))return res.status(403).json({error:'Material is outside your scope'});const data=await readPrivate(material.storageKey);res.setHeader('Content-Type',material.mediaType);res.setHeader('Content-Disposition',`inline; filename="${material.fileName.replace(/"/g,'')}"`);res.setHeader('Cache-Control','private, no-store');res.setHeader('X-Content-Type-Options','nosniff');res.end(data);});

r.post('/crm/whatsapp-workspace/materials/:id/retire',async(req,res)=>{if(!requireCreator(req,res))return;const material=await one('SELECT * FROM wa_material_catalogue WHERE id=$1',[req.params.id]);if(!material)return res.status(404).json({error:'Material not found'});if(!canUseTeam(req.broker,material.ownerTeamId))return res.status(403).json({error:'Material is outside your scope'});const updated=await one("UPDATE wa_material_catalogue SET status='retired',updated_at=NOW() WHERE id=$1 RETURNING *",[material.id]);await audit('WhatsAppMaterial',material.id,'retired',req.broker.id,{});res.json({material:publicMaterial(updated)});});

r.post('/crm/whatsapp-workspace/campaigns',async(req,res)=>{
  if(!requireCreator(req,res))return;
  const checked=validateCampaignDraft(req.body||{}),teamId=clean(req.body?.teamId,36);
  if(!checked.valid)return res.status(400).json({error:checked.errors[0],errors:checked.errors});
  if(!canUseTeam(req.broker,teamId))return res.status(403).json({error:'Campaign team is outside your scope'});
  const result=await transaction(async client=>{
    const segment=await one("SELECT * FROM wa_audience_segments WHERE id=$1 AND status='active'",[checked.value.segmentId],client),template=await templateContext(checked.value.templateVersionId,client);
    if(!segment||String(segment.ownerTeamId)!==teamId)return{code:409,error:'Select an active segment from the campaign team'};
    if(!template||String(template.ownerTeamId)!==teamId||template.internalStatus!=='approved')return{code:409,error:'Select an internally approved template version from the campaign team'};
    const materials=checked.value.materialIds.length?await many("SELECT id FROM wa_material_catalogue WHERE id=ANY($1::uuid[]) AND owner_team_id=$2 AND status='active'",[checked.value.materialIds,teamId],client):[];
    if(materials.length!==checked.value.materialIds.length)return{code:409,error:'One or more selected materials are unavailable for this team'};
    const id=uuid(),reference=`WA-CMP-${new Date().getUTCFullYear()}-${id.slice(0,8).toUpperCase()}`,campaign=await one(`INSERT INTO wa_campaign_drafts(id,campaign_reference,name,owner_team_id,segment_id,template_id,template_version_id,template_variables,purpose,prepared_by,scheduled_at,budget_aed) VALUES($1,$2,$3,$4,$5,NULL,$6,'{}',$7,$8,$9,$10) RETURNING *`,[id,reference,checked.value.name,teamId,segment.id,template.id,checked.value.purpose,req.broker.id,checked.value.scheduledAt,checked.value.budgetAed],client);
    for(const material of materials)await execute('INSERT INTO wa_campaign_materials(campaign_id,material_id,added_by) VALUES($1,$2,$3)',[id,material.id,req.broker.id],client);
    const snapshot={name:campaign.name,purpose:campaign.purpose,ownerTeamId:teamId,segmentId:segment.id,templateVersionId:template.id,materialIds:materials.map(item=>item.id),scheduledAt:campaign.scheduledAt,budgetAed:campaign.budgetAed,sendingEnabled:false,metaStatus:'not_submitted'},snapshotHash=workspaceHash(snapshot);
    await execute(`INSERT INTO wa_campaign_revisions(id,campaign_id,revision,snapshot,snapshot_hash,created_by) VALUES($1,$2,1,$3,$4,$5)`,[uuid(),id,snapshot,snapshotHash,req.broker.id],client);
    await audit('WhatsAppCampaign',id,'draft_created',req.broker.id,{reference,revision:1,snapshotHash,sendingEnabled:false},client);return{campaign};
  });
  if(result.error)return res.status(result.code).json({error:result.error});res.status(201).json(result);
});

r.patch('/crm/whatsapp-workspace/campaigns/:id',async(req,res)=>{
  if(!requireCreator(req,res))return;const checked=validateCampaignDraft(req.body||{});if(!checked.valid)return res.status(400).json({error:checked.errors[0],errors:checked.errors});
  const result=await transaction(async client=>{const current=await one('SELECT * FROM wa_campaign_drafts WHERE id=$1 FOR UPDATE',[req.params.id],client);if(!current)return{code:404,error:'Campaign not found'};if(!canUseTeam(req.broker,current.ownerTeamId))return{code:403,error:'Campaign is outside your scope'};if(!['draft','returned','approved'].includes(current.status))return{code:409,error:'Campaign cannot be edited while approval is pending'};const segment=await one("SELECT * FROM wa_audience_segments WHERE id=$1 AND status='active'",[checked.value.segmentId],client),template=await templateContext(checked.value.templateVersionId,client);if(!segment||String(segment.ownerTeamId)!==String(current.ownerTeamId))return{code:409,error:'Select an active segment from the campaign team'};if(!template||String(template.ownerTeamId)!==String(current.ownerTeamId)||template.internalStatus!=='approved')return{code:409,error:'Select an internally approved template version from the campaign team'};const materials=checked.value.materialIds.length?await many("SELECT id FROM wa_material_catalogue WHERE id=ANY($1::uuid[]) AND owner_team_id=$2 AND status='active'",[checked.value.materialIds,current.ownerTeamId],client):[];if(materials.length!==checked.value.materialIds.length)return{code:409,error:'One or more selected materials are unavailable for this team'};const revision=Number(current.revision)+1,approvalInvalidated=current.status==='approved';const updated=await one(`UPDATE wa_campaign_drafts SET name=$1,purpose=$2,segment_id=$3,template_version_id=$4,scheduled_at=$5,budget_aed=$6,status='draft',revision=$7,submitted_at=NULL,decision_by=NULL,decision_at=NULL,decision_reason=NULL,approved_revision=NULL,approved_snapshot_hash=NULL,approved_recipient_count=NULL,approved_at=NULL,updated_at=NOW() WHERE id=$8 RETURNING *`,[checked.value.name,checked.value.purpose,segment.id,template.id,checked.value.scheduledAt,checked.value.budgetAed,revision,current.id],client);await execute('DELETE FROM wa_campaign_materials WHERE campaign_id=$1',[current.id],client);for(const material of materials)await execute('INSERT INTO wa_campaign_materials(campaign_id,material_id,added_by) VALUES($1,$2,$3)',[current.id,material.id,req.broker.id],client);const snapshot={name:updated.name,purpose:updated.purpose,ownerTeamId:updated.ownerTeamId,segmentId:updated.segmentId,templateVersionId:updated.templateVersionId,materialIds:materials.map(item=>item.id),scheduledAt:updated.scheduledAt,budgetAed:updated.budgetAed,sendingEnabled:false,metaStatus:'not_submitted'},snapshotHash=workspaceHash(snapshot);await execute('INSERT INTO wa_campaign_revisions(id,campaign_id,revision,snapshot,snapshot_hash,created_by) VALUES($1,$2,$3,$4,$5,$6)',[uuid(),current.id,revision,snapshot,snapshotHash,req.broker.id],client);await audit('WhatsAppCampaign',current.id,approvalInvalidated?'approval_invalidated_by_edit':'draft_updated',req.broker.id,{revision,snapshotHash,reapprovalRequired:true},client);return{campaign:updated};});if(result.error)return res.status(result.code).json({error:result.error});res.json(result);
});

r.get('/crm/whatsapp-workspace/campaigns/:id/preview',async(req,res)=>{
  const result=await transaction(async client=>{const campaign=await campaignContext(req.params.id,client);if(!campaign)return{code:404,error:'Campaign not found'};if(!canUseTeam(req.broker,campaign.ownerTeamId))return{code:403,error:'Campaign is outside your scope'};return{campaign,preview:await campaignPreview(campaign,client)};});if(result.error)return res.status(result.code).json({error:result.error});res.setHeader('Cache-Control','no-store');res.json(result);
});

r.post('/crm/whatsapp-workspace/campaigns/:id/submit',async(req,res)=>{
  if(!requireCreator(req,res))return;const result=await transaction(async client=>{const campaign=await campaignContext(req.params.id,client);if(!campaign)return{code:404,error:'Campaign not found'};if(!canUseTeam(req.broker,campaign.ownerTeamId))return{code:403,error:'Campaign is outside your scope'};let next;try{next=campaignCommand(campaign,'submit',{actorId:req.broker.id,actorRole:req.broker.jobRole,managedTeamIds:[...(req.broker.managedTeamIds||[]),req.broker.teamId].filter(Boolean)});}catch(error){return{code:409,error:error.message};}const updated=await one("UPDATE wa_campaign_drafts SET status=$1,submitted_at=NOW(),updated_at=NOW() WHERE id=$2 RETURNING *",[next.status,campaign.id],client);await audit('WhatsAppCampaign',campaign.id,'submitted_for_internal_approval',req.broker.id,{revision:campaign.revision,sendingEnabled:false},client);return{campaign:updated};});if(result.error)return res.status(result.code).json({error:result.error});res.json(result);
});

r.post('/crm/whatsapp-workspace/campaigns/:id/retire',async(req,res)=>{
  const reason=clean(req.body?.reason,500);if(reason.length<5)return res.status(400).json({error:'Retirement reason must contain at least 5 characters'});
  const result=await transaction(async client=>{const campaign=await campaignContext(req.params.id,client);if(!campaign)return{code:404,error:'Campaign not found'};if(!canUseTeam(req.broker,campaign.ownerTeamId))return{code:404,error:'Campaign not found or outside your scope'};let next;try{next=campaignCommand(campaign,'retire',{actorId:req.broker.id,actorRole:req.broker.jobRole,managedTeamIds:[...(req.broker.managedTeamIds||[]),req.broker.teamId].filter(Boolean),reason});}catch(error){return{code:409,error:error.message};}const updated=await one("UPDATE wa_campaign_drafts SET status='retired',decision_by=$1,decision_at=NOW(),decision_reason=$2,updated_at=NOW() WHERE id=$3 RETURNING *",[req.broker.id,next.decisionReason,campaign.id],client);await audit('WhatsAppCampaign',campaign.id,'retired',req.broker.id,{priorStatus:campaign.status,revision:campaign.revision,reason:next.decisionReason,sendingEnabled:false},client);return{campaign:updated};});
  if(result.error)return res.status(result.code).json({error:result.error});res.json(result);
});

r.post('/crm/whatsapp-workspace/campaigns/:id/decision',async(req,res)=>{
  if(!requireReviewer(req,res))return;const decision=clean(req.body?.decision,20),reason=clean(req.body?.reason,500);if(!['approve','return'].includes(decision))return res.status(400).json({error:'Decision must be approve or return'});if(decision==='return'&&reason.length<5)return res.status(400).json({error:'Return reason must contain at least 5 characters'});
  const result=await transaction(async client=>{const campaign=await campaignContext(req.params.id,client);if(!campaign)return{code:404,error:'Campaign not found'};if(!canUseTeam(req.broker,campaign.ownerTeamId))return{code:403,error:'Campaign is outside your review scope'};let next;try{next=campaignCommand(campaign,decision,{actorId:req.broker.id,actorRole:req.broker.jobRole,managedTeamIds:[...(req.broker.managedTeamIds||[]),req.broker.teamId].filter(Boolean),reason});}catch(error){return{code:409,error:error.message};}let approval=null;if(decision==='approve'){const preview=await campaignPreview(campaign,client),eligible=preview.rows.filter(item=>item.eligible);if(!eligible.length)return{code:409,error:'Campaign has no unique eligible recipients'};const materials=await many('SELECT material_id FROM wa_campaign_materials WHERE campaign_id=$1 ORDER BY material_id',[campaign.id],client),snapshot={campaignId:campaign.id,revision:campaign.revision,segmentId:campaign.segmentId,segmentDefinition:campaign.definition,templateVersionId:campaign.templateVersionId,templateBody:campaign.bodyText,templateSamples:campaign.variableSamples,materialIds:materials.map(item=>item.materialId),scheduledAt:campaign.scheduledAt,budgetAed:campaign.budgetAed,recipients:eligible.map(item=>({recipientId:item.recipientId,phone:item.phone,message:item.message}))},snapshotHash=workspaceHash(snapshot);for(const item of eligible)await execute(`INSERT INTO wa_campaign_approval_recipients(campaign_id,revision,recipient_id,normalized_phone,display_name,rendered_message,snapshot_hash) VALUES($1,$2,$3,$4,$5,$6,$7)`,[campaign.id,campaign.revision,item.recipientId,item.phone,item.name,item.message,workspaceHash(item)],client);approval={...snapshot,snapshotHash,recipientCount:eligible.length};}const updated=await one(`UPDATE wa_campaign_drafts SET status=$1,decision_by=$2,decision_at=NOW(),decision_reason=$3,approved_revision=$4,approved_snapshot_hash=$5,approved_recipient_count=$6,approved_at=CASE WHEN $1='approved' THEN NOW() ELSE NULL END,updated_at=NOW() WHERE id=$7 RETURNING *`,[next.status,req.broker.id,reason||null,approval?.revision||null,approval?.snapshotHash||null,approval?.recipientCount||null,campaign.id],client);const selfApproval=String(campaign.preparedBy)===String(req.broker.id);await audit('WhatsAppCampaign',campaign.id,decision==='approve'?'internally_approved':'returned',req.broker.id,{revision:campaign.revision,reason:reason||null,sendingEnabled:false,metaStatus:'not_submitted',selfApproval,approvedRecipientCount:approval?.recipientCount||0,approvedSnapshotHash:approval?.snapshotHash||null},client);return{campaign:updated,approval};});if(result.error)return res.status(result.code).json({error:result.error});res.json(result);
});

r.post('/crm/whatsapp-workspace/recipient-suppressions',async(req,res)=>{
  if(!requireCreator(req,res))return;const phone=normalizeWhatsAppPhone(req.body?.phone),messageText=clean(req.body?.messageText,160),evidenceReference=clean(req.body?.evidenceReference,240),suppressionType=classifyWhatsAppSuppression(messageText);if(!phone)return res.status(400).json({error:'Valid E.164 phone is required'});if(!suppressionType)return res.status(400).json({error:'Message is not a maintained opt-out or wrong-number response'});if(!evidenceReference)return res.status(400).json({error:'Suppression evidence reference is required'});
  const result=await transaction(async client=>{await lock(`wa-suppression:${phone}`,client);const affectedRecipientRows=await applyCrossChannelSuppression(phone,suppressionType,evidenceReference,req.broker.id,client);await audit('WhatsAppRecipientImport',uuid(),'cross_list_suppression_recorded',req.broker.id,{suppressionType,evidenceReference,affectedRecipientRows,approvedCampaignRowsOnlyShrunk:true},client);return{suppressionType,affectedRecipientRows};});res.status(201).json(result);
});

r.post('/crm/whatsapp-workspace/recipient-suppressions/dncr',async(req,res)=>{
  if(!requireReviewer(req,res))return;
  const phone=normalizeWhatsAppPhone(req.body?.phone),action=clean(req.body?.action,20),evidenceReference=clean(req.body?.evidenceReference,240),reason=clean(req.body?.reason,500);
  if(!phone)return res.status(400).json({error:'Valid E.164 phone is required'});
  if(!['record','release'].includes(action))return res.status(400).json({error:'Action must be record or release'});
  if(action==='record'&&!evidenceReference)return res.status(400).json({error:'Manual DNCR evidence reference is required'});
  if(action==='release'&&reason.length<5)return res.status(400).json({error:'A meaningful DNCR release reason is required'});
  try{
    const result=await transaction(async client=>{await lock(`wa-suppression:${phone}`,client);let affectedRecipientRows=0;if(action==='record')affectedRecipientRows=await applyCrossChannelSuppression(phone,'dncr',evidenceReference,req.broker.id,client);else await releaseContactSuppression({phone,type:'dncr',reason,actorId:req.broker.id,actorRole:req.broker.jobRole},client);const suppression=await getContactSuppression(phone,client);await audit('WhatsAppRecipientImport',uuid(),action==='record'?'manual_dncr_recorded':'manual_dncr_released',req.broker.id,{label:'Manual DNCR evidence (not a registry check)',evidenceReference:action==='record'?evidenceReference:null,reason:action==='release'?reason:null,affectedRecipientRows,strongest:suppression.strongest},client);return{action,suppressionType:'dncr',affectedRecipientRows,strongest:suppression.strongest};});res.status(action==='record'?201:200).json(result);
  }catch(error){res.status(409).json({error:error.message});}
});

r.post('/crm/whatsapp-workspace/recipient-suppressions/release',async(req,res)=>{
  if(!['manager','director'].includes(req.broker.jobRole))return res.status(403).json({error:'Manager or Director access is required'});
  const phone=normalizeWhatsAppPhone(req.body?.phone),type=clean(req.body?.suppressionType,30);if(!phone)return res.status(400).json({error:'Valid E.164 phone is required'});
  try{const result=await transaction(client=>releaseContactSuppression({phone,type,reason:req.body?.reason,actorId:req.broker.id,actorRole:req.broker.jobRole,consentEvidenceReference:req.body?.consentEvidenceReference,consentRecordedAt:req.body?.consentRecordedAt},client));res.json(result);}catch(error){res.status(409).json({error:error.message});}
});

r.get('/crm/whatsapp-workspace/conversations/:id',async(req,res)=>{
    const conversation=await selectConversationWithReplyLock(undefined,req.params.id);
    if(!conversation||!canUseConversation(req.broker,conversation))return res.status(404).json({error:'Conversation not found or outside your inbox scope'});
    const related=await one(`SELECT team.name AS team_name,agent.name AS owner_agent_name,l.lead_reference,l.title AS lead_title
      FROM wa_conversations c JOIN teams team ON team.id=c.owner_team_id LEFT JOIN brokers agent ON agent.id=c.owner_agent_id
      LEFT JOIN leads l ON l.id=c.lead_id WHERE c.id=$1`,[conversation.id]);
    Object.assign(conversation,related||{});
  const messages=await many('SELECT id,direction,message_type,body,occurred_at,simulated,provider_message_id,provider_status,provider_status_at FROM wa_conversation_messages WHERE conversation_id=$1 ORDER BY occurred_at ASC LIMIT 500',[conversation.id]);
  const agents=['manager','director'].includes(req.broker.jobRole)?await many(`SELECT DISTINCT b.id,b.name FROM brokers b WHERE b.status='active' AND b.job_role='sales_agent' AND (b.team_id=$1 OR EXISTS(SELECT 1 FROM team_memberships tm WHERE tm.team_id=$1 AND tm.broker_id=b.id AND tm.ends_at IS NULL) OR EXISTS(SELECT 1 FROM user_role_assignments ur WHERE ur.team_id=$1 AND ur.broker_id=b.id AND ur.status='active' AND ur.ends_at IS NULL)) ORDER BY b.name`,[conversation.ownerTeamId]):[];
  await execute('UPDATE wa_inbox_notifications SET read_at=NOW() WHERE conversation_id=$1 AND broker_id=$2 AND read_at IS NULL',[conversation.id,req.broker.id]);
    const now=Date.now(),simulation=simulatedProviderConfig(),lockState=replyLockState(conversation,req.broker),lockDisplay=lockState.active?`${lockState.ownerName||'another user'} until ${clientLockTime(lockState.expiresAt,req)} (your local time)`:'available';res.json({conversation:{...conversation,replyLockOwnerName:lockDisplay,replyLock:lockState,replyWindowOpen:Boolean(conversation.lastCustomerMessageAt&&now-Date.parse(conversation.lastCustomerMessageAt)<=24*60*60*1000),ctwaFreeWindowOpen:Boolean(['ctwa','website_ctwa'].includes(conversation.sourceType)&&conversation.ctwaEntryAt&&now-Date.parse(conversation.ctwaEntryAt)<=72*60*60*1000)},messages,agents,sendingEnabled:Boolean(simulation.enabled&&conversation.simulated&&lockState.canSend),simulationEnabled:simulation.enabled});
});

r.post('/crm/whatsapp-workspace/conversations/:id/reply-lock',async(req,res)=>{
  const action=clean(req.body?.action,20);if(!['acquire','release'].includes(action))return res.status(400).json({error:'Reply lock action must be acquire or release'});
  const result=await transaction(async client=>{
    const conversation=await selectConversationWithReplyLock(client,req.params.id,{forUpdate:true});
    if(!conversation)return{code:404,error:'Conversation not found or outside your inbox scope'};
    if(!canUseTeam(req.broker,conversation.ownerTeamId))return{code:404,error:'Conversation not found or outside your inbox scope'};
    if(req.broker.jobRole==='sales_agent'&&String(conversation.ownerAgentId)!==String(req.broker.id))return{code:404,error:'Conversation not found or outside your inbox scope'};
    const before=replyLockState(conversation,req.broker);
    if(action==='acquire'&&before.active&&!before.heldByCurrentUser){const error=`Reply lock held by ${before.ownerName||'another user'} until ${clientLockTime(before.expiresAt,req)} (your local time)`;return{code:409,error,response:{error,code:'WHATSAPP_REPLY_LOCK_HELD',replyLock:before}};}
    if(action==='release'&&conversation.replyLockOwnerId&&!before.heldByCurrentUser&&!['manager','director'].includes(req.broker.jobRole))return{code:403,error:'Only the lock holder or a Manager/Director may release it'};
    if(action==='release'&&!conversation.replyLockOwnerId)return{conversation,replyLock:before,noOp:true};
    const updated=await writeReplyLock(client,conversation.id,action==='acquire'?req.broker.id:null),after=replyLockState(updated,req.broker);
    const auditAction=action==='release'?'reply_lock_released':before.expired?'reply_lock_expired_replaced':'reply_lock_acquired';
    const details=action==='release'?{priorHolderId:before.ownerId,priorAcquiredAt:before.acquiredAt,priorExpiresAt:before.expiresAt,releaseMode:before.heldByCurrentUser?'holder':'manager_override'}:{priorHolderId:before.ownerId,priorAcquiredAt:before.acquiredAt,priorExpiresAt:before.expiresAt,newHolderId:after.ownerId,newAcquiredAt:after.acquiredAt,newExpiresAt:after.expiresAt,reacquired:before.active&&before.heldByCurrentUser};
    await audit('WhatsAppConversation',conversation.id,auditAction,req.broker.id,details,client);
    return{conversation:updated,replyLock:after};
  });
  if(result.error)return res.status(result.code).json(result.response||{error:result.error});res.json(result);
});

r.post('/crm/whatsapp-workspace/conversations/:id/assignment',async(req,res)=>{
    if(!requireReviewer(req,res))return;const agentId=clean(req.body?.agentId,36),takeover=Boolean(req.body?.takeover),reason=clean(req.body?.reason,500);if(reason.length<5)return res.status(400).json({error:'Assignment reason must contain at least 5 characters'});const result=await transaction(async client=>{const conversation=await selectConversationWithReplyLock(client,req.params.id,{forUpdate:true});if(!conversation)return{code:404,error:'Conversation not found'};if(!canUseTeam(req.broker,conversation.ownerTeamId))return{code:403,error:'Conversation is outside your management scope'};const priorReplyLock=replyLockState(conversation,req.broker),target=takeover?req.broker.id:agentId;if(!target)return{code:400,error:'Select an Agent'};const eligible=await one(`SELECT b.id FROM brokers b WHERE b.id=$1 AND b.status='active' AND ((b.job_role='sales_agent' AND (b.team_id=$2 OR EXISTS(SELECT 1 FROM team_memberships tm WHERE tm.team_id=$2 AND tm.broker_id=b.id AND tm.ends_at IS NULL) OR EXISTS(SELECT 1 FROM user_role_assignments ur WHERE ur.team_id=$2 AND ur.broker_id=b.id AND ur.status='active' AND ur.ends_at IS NULL))) OR ($3::boolean AND b.job_role IN('manager','director')))`,[target,conversation.ownerTeamId,takeover],client);if(!eligible)return{code:409,error:'Selected owner is not eligible for this team'};const action=takeover?'taken_over':conversation.ownerAgentId?'reassigned':'assigned',updated=await one('UPDATE wa_conversations SET owner_agent_id=$1,reply_lock_owner_id=NULL,reply_lock_acquired_at=NULL,updated_at=NOW() WHERE id=$2 RETURNING *',[target,conversation.id],client);await execute('INSERT INTO wa_conversation_assignment_history(id,conversation_id,from_agent_id,to_agent_id,action,reason,changed_by) VALUES($1,$2,$3,$4,$5,$6,$7)',[uuid(),conversation.id,conversation.ownerAgentId,target,action,reason,req.broker.id],client);await execute(`INSERT INTO wa_inbox_notifications(id,conversation_id,broker_id,notification_type) VALUES($1,$2,$3,'assignment')`,[uuid(),conversation.id,target],client);await audit('WhatsAppConversation',conversation.id,action,req.broker.id,{fromAgentId:conversation.ownerAgentId,toAgentId:target,reason,replyLockReset:true,priorReplyLock:{ownerId:priorReplyLock.ownerId,acquiredAt:priorReplyLock.acquiredAt,expiresAt:priorReplyLock.expiresAt,active:priorReplyLock.active}},client);return{conversation:updated};});if(result.error)return res.status(result.code).json({error:result.error});res.json(result);
});

export default r;
