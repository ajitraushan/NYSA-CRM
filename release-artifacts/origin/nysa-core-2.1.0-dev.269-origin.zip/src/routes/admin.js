import crypto from 'node:crypto';
import { Router } from '../lib/http-kit.js';
import { one, many, execute, transaction, uuid, audit } from '../db.js';
import { requireAuth, publicBroker,hashPassword } from '../auth.js';
import { JOB_ROLES } from '../crm-domain.js';
import { validateInvitationExpiry } from '../admin-governance.js';
import { validateBrnDetails } from '../document-agent-domain.js';

const r = Router();
r.use(requireAuth,(req,res,next)=>req.broker.role==='admin'?next():res.status(403).json({error:'Admin access required'}));
const ROLES = ['admin','internal_broker','partner_broker','viewer'];
const privileged=role=>['admin','director'].includes(role);
const canMaintain=(req,jobRole)=>req.broker.role==='admin'||!privileged(jobRole);
const teamManager=async(teamId,client)=>teamId?one(`SELECT t.id,t.name,t.manager_id,b.name AS manager_name FROM teams t LEFT JOIN brokers b ON b.id=t.manager_id WHERE t.id=$1 AND t.active=1`,[teamId],client):null;
async function syncManagerAssignment(teamId,brokerId,actorId,client){
  await execute('UPDATE teams SET manager_id=$1 WHERE id=$2',[brokerId,teamId],client);
  await execute("UPDATE team_memberships SET membership_role='member' WHERE team_id=$1 AND broker_id<>$2 AND membership_role='manager' AND ends_at IS NULL",[teamId,brokerId],client);
  await execute(`INSERT INTO team_memberships(id,team_id,broker_id,membership_role,created_by) VALUES($1,$2,$3,'manager',$4)
    ON CONFLICT (team_id,broker_id) WHERE ends_at IS NULL DO UPDATE SET membership_role='manager'`,[uuid(),teamId,brokerId,actorId],client);
}

async function operationalOwnershipImpact(brokerId,client){
  const counts=await one(`SELECT
    (SELECT COUNT(*)::int FROM leads WHERE assigned_to=$1 AND stage NOT IN('Won','Lost')) AS leads,
    (SELECT COUNT(*)::int FROM opportunities WHERE owner_id=$1 AND stage NOT IN('Closed Won','Closed Lost')) AS opportunities,
    (SELECT COUNT(*)::int FROM offers WHERE owner_id=$1 AND status NOT IN('rejected','expired','withdrawn')) AS offers,
    (SELECT COUNT(*)::int FROM tasks WHERE assignee_id=$1 AND status IN('open','in_progress')) AS tasks,
    (SELECT COUNT(*)::int FROM viewings WHERE organizer_id=$1 AND status IN('scheduled','rescheduled')) AS viewings,
    (SELECT COUNT(*)::int FROM bookings WHERE owner_id=$1 AND status='reserved') AS bookings,
    (SELECT COUNT(*)::int FROM deals WHERE owner_id=$1 AND status NOT IN('closed_won','closed_lost')) AS deals`,[brokerId],client);
  const total=Object.values(counts||{}).reduce((sum,value)=>sum+Number(value||0),0);
  return{...counts,total,clear:total===0};
}

r.get('/admin/invitations', async (req, res) => {
  const rows = await many(`SELECT i.*, b.name AS issued_by_name FROM invitations i
    JOIN brokers b ON b.id = i.issued_by ORDER BY i.created_at DESC`);
  res.json({ count:rows.length, invitations:rows });
});

r.post('/admin/invitations', async (req, res) => {
  const { issuedToEmail, role='internal_broker', jobRole, expiresAt,teamId } = req.body || {};
  if (!ROLES.includes(role)) return res.status(400).json({ error:'Invalid role' });
  const resolvedJobRole = role === 'admin' ? 'admin' : role === 'internal_broker' ? (jobRole || 'sales_agent') : null;
  if (resolvedJobRole && !JOB_ROLES.includes(resolvedJobRole)) return res.status(400).json({ error:'Invalid jobRole' });
  if (!issuedToEmail||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(issuedToEmail)) return res.status(400).json({ error:'A valid named user email is required' });
  if(!canMaintain(req,resolvedJobRole))return res.status(403).json({error:'Only Admin can appoint Admin or Director access'});
  if(['sales_agent','listing_agent','manager'].includes(resolvedJobRole)&&!teamId)return res.status(400).json({error:'Team is required for this user role'});
  if(teamId&&!(await one('SELECT id FROM teams WHERE id=$1 AND active=1',[teamId])))return res.status(400).json({error:'Active team not found'});
  if(resolvedJobRole==='manager'){const team=await teamManager(teamId);if(team?.managerId)return res.status(409).json({error:`${team.name} is already managed by ${team.managerName}. Change its manager deliberately in Team maintenance.`});}
  const checkedExpiry=validateInvitationExpiry(expiresAt);
  if(checkedExpiry.error)return res.status(400).json({error:checkedExpiry.error});
  const id = uuid();
  const code = 'NYSA-' + crypto.randomBytes(8).toString('hex').toUpperCase();
  const invitation = await one(`INSERT INTO invitations
    (id,code,issued_by,issued_to_email,role,job_role,max_uses,expires_at,team_id) VALUES ($1,$2,$3,$4,$5,$6,1,$7,$8) RETURNING *`,
    [id,code,req.broker.id,issuedToEmail.toLowerCase(),role,resolvedJobRole,checkedExpiry.value,teamId||null]);
  await audit('Invitation', id, 'created', req.broker.id, { role, jobRole:resolvedJobRole, issuedToEmail,teamId:teamId||null,expiresAt:checkedExpiry.value });
  res.status(201).json(invitation);
});

r.delete('/admin/invitations/:id', async (req, res) => {
  const invitation = await one('SELECT * FROM invitations WHERE id=$1', [req.params.id]);
  if (!invitation) return res.status(404).json({ error:'Invitation not found' });
  await execute("UPDATE invitations SET status='revoked' WHERE id=$1", [invitation.id]);
  await audit('Invitation', invitation.id, 'revoked', req.broker.id);
  res.json({ ok:true });
});

r.get('/admin/brokers', async (req, res) => {
  const rows = await many(`SELECT b.*,t.manager_id AS reporting_manager_id,m.name AS reporting_manager_name,d.name AS direct_supervisor_name,
    COALESCE((SELECT ARRAY_AGG(tm.team_id::text ORDER BY member_team.name) FROM team_memberships tm JOIN teams member_team ON member_team.id=tm.team_id WHERE tm.broker_id=b.id AND tm.ends_at IS NULL),ARRAY[]::text[]) AS team_ids,
    COALESCE((SELECT ARRAY_AGG(aa.area_id::text ORDER BY assigned_area.display_order,assigned_area.business_label) FROM agent_area_assignments aa JOIN areas assigned_area ON assigned_area.id=aa.area_id WHERE aa.broker_id=b.id AND aa.ends_at IS NULL),ARRAY[]::text[]) AS area_ids,
    (SELECT COALESCE(json_agg(json_build_object('id',mt.id,'name',mt.name) ORDER BY mt.name),'[]') FROM teams mt WHERE mt.manager_id=b.id AND mt.active=1) AS managed_teams,(SELECT COALESCE(json_agg(json_build_object(
    'id',r.id,'jobRole',r.job_role,'teamId',r.team_id,'isPrimary',r.is_primary=1,
    'status',r.status,'startsAt',r.starts_at,'endsAt',r.ends_at,'changeReason',r.change_reason
  ) ORDER BY r.is_primary DESC,r.starts_at),'[]') FROM user_role_assignments r WHERE r.broker_id=b.id) AS role_assignments,
    (SELECT COALESCE(json_agg(json_build_object('id',s.id,'status',s.status,'effectiveFrom',s.effective_from,
      'effectiveTo',s.effective_to,'reason',s.reason,'evidenceReference',s.evidence_reference,'createdAt',s.created_at)
      ORDER BY s.effective_from DESC,s.created_at DESC),'[]') FROM agent_social_media_payout_status_versions s WHERE s.agent_id=b.id) AS social_media_payout_status_versions
    FROM brokers b LEFT JOIN teams t ON t.id=b.team_id LEFT JOIN brokers m ON m.id=t.manager_id LEFT JOIN brokers d ON d.id=b.reports_to_id ORDER BY b.joined_at DESC`);
  res.json({ count:rows.length, brokers:rows.map(publicBroker) });
});

r.post('/admin/users/:id/social-media-payout-status',async(req,res)=>{
  if(req.broker.role!=='admin')return res.status(403).json({error:'Admin access is required'});
  const target=await one("SELECT id,name,role,job_role FROM brokers WHERE id=$1",[req.params.id]);
  if(!target)return res.status(404).json({error:'Agent not found'});
  if(target.role!=='internal_broker'||!['sales_agent','listing_agent','manager'].includes(target.jobRole))return res.status(400).json({error:'Social-media payout eligibility applies only to an individual Agent'});
  const status=String(req.body?.status||''),effectiveFrom=String(req.body?.effectiveFrom||'').slice(0,10),reason=String(req.body?.reason||'').trim(),evidenceReference=String(req.body?.evidenceReference||'').trim();
  if(!['active','inactive'].includes(status)||!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(effectiveFrom)||reason.length<10||evidenceReference.length<3)return res.status(400).json({error:'Status, effective date, meaningful reason and evidence reference are required'});
  const result=await transaction(async client=>{
    const covering=await one(`SELECT *,effective_from::text AS effective_from FROM agent_social_media_payout_status_versions WHERE agent_id=$1
      AND effective_from<=$2 AND (effective_to IS NULL OR effective_to>$2) FOR UPDATE`,[target.id,effectiveFrom],client);
    if(covering&&String(covering.effectiveFrom).slice(0,10)===effectiveFrom)return{code:409,error:'A social-media payout status already begins on this date'};
    if(covering)await execute('UPDATE agent_social_media_payout_status_versions SET effective_to=$1 WHERE id=$2',[effectiveFrom,covering.id],client);
    const next=await one(`SELECT effective_from::text AS effective_from FROM agent_social_media_payout_status_versions
      WHERE agent_id=$1 AND effective_from>$2 ORDER BY effective_from LIMIT 1`,[target.id,effectiveFrom],client);
    const id=uuid(),created=await one(`INSERT INTO agent_social_media_payout_status_versions(id,agent_id,status,effective_from,effective_to,reason,evidence_reference,created_by)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,[id,target.id,status,effectiveFrom,next?.effectiveFrom||null,reason,evidenceReference,req.broker.id],client);
    await audit('AgentSocialMediaPayoutStatus',id,'status_recorded',req.broker.id,{agentId:target.id,status,effectiveFrom,reason,evidenceReference},client);
    return{statusVersion:created};
  });
  if(result.error)return res.status(result.code).json({error:result.error});
  res.status(201).json(result);
});

r.get('/admin/password-reset-requests',async(req,res)=>{
  if(req.broker.role!=='admin')return res.status(403).json({error:'Admin access required'});
  await execute("UPDATE password_reset_requests SET status='expired',code_hash=NULL WHERE status='issued' AND expires_at<=NOW()");
  const requests=await many(`SELECT pr.id,pr.status,pr.requested_at,pr.issued_at,pr.expires_at,pr.delivery_recorded_at,b.id AS broker_id,b.name,b.email,issuer.name AS issued_by_name
    FROM password_reset_requests pr JOIN brokers b ON b.id=pr.broker_id LEFT JOIN brokers issuer ON issuer.id=pr.issued_by
    WHERE pr.status IN ('pending','issued') ORDER BY pr.requested_at DESC`);
  res.json({count:requests.length,requests});
});

r.post('/admin/password-reset-requests/:id/issue',async(req,res)=>{
  if(req.broker.role!=='admin')return res.status(403).json({error:'Admin access required'});
  const code=`NYSA-RST-${crypto.randomBytes(6).toString('hex').toUpperCase()}`,codeHash=crypto.createHash('sha256').update(code).digest('hex');
  const request=await transaction(async client=>{
    const row=await one(`SELECT pr.*,b.status AS broker_status FROM password_reset_requests pr JOIN brokers b ON b.id=pr.broker_id
      WHERE pr.id=$1 AND pr.status IN ('pending','issued') FOR UPDATE OF pr`,[req.params.id],client);
    if(!row||row.brokerStatus!=='active')return null;
    await execute("UPDATE password_reset_requests SET status='issued',issued_by=$1,code_hash=$2,issued_at=NOW(),expires_at=NOW()+INTERVAL '30 minutes' WHERE id=$3",[req.broker.id,codeHash,row.id],client);
    await audit('Broker',row.brokerId,'password_reset_code_issued',req.broker.id,{resetRequestId:row.id,expiresInMinutes:30},client);
    return row;
  });
  if(!request)return res.status(404).json({error:'Open password reset request not found'});
  res.json({ok:true,code,expiresInMinutes:30,requestId:request.id});
});

r.post('/admin/password-reset-requests/:id/delivery',async(req,res)=>{
  if(req.broker.role!=='admin')return res.status(403).json({error:'Admin access required'});
  if(req.body?.confirmed!==true)return res.status(400).json({error:'Confirm delivery through an approved private channel'});
  const request=await one(`UPDATE password_reset_requests SET delivery_method='manual_approved_private_channel',delivery_recorded_at=NOW(),delivery_recorded_by=$1
    WHERE id=$2 AND status='issued' AND expires_at>NOW() RETURNING *`,[req.broker.id,req.params.id]);
  if(!request)return res.status(409).json({error:'Only a current issued reset code can be marked delivered'});
  await audit('Broker',request.brokerId,'password_reset_code_delivery_recorded',req.broker.id,{resetRequestId:request.id,method:'manual_approved_private_channel'});
  res.json({ok:true,deliveryRecordedAt:request.deliveryRecordedAt});
});

r.delete('/admin/password-reset-requests/:id',async(req,res)=>{
  if(req.broker.role!=='admin')return res.status(403).json({error:'Admin access required'});
  const request=await one("UPDATE password_reset_requests SET status='cancelled',code_hash=NULL WHERE id=$1 AND status IN ('pending','issued') RETURNING *",[req.params.id]);
  if(!request)return res.status(404).json({error:'Open password reset request not found'});
  await audit('Broker',request.brokerId,'password_reset_cancelled',req.broker.id,{resetRequestId:request.id});
  res.json({ok:true});
});

r.post('/admin/users',async(req,res)=>{
  const b=req.body||{},email=String(b.email||'').trim().toLowerCase(),phone=String(b.phone||'').trim(),classification=b.userClassification||'internal_user',assignments=Array.isArray(b.roleAssignments)?b.roleAssignments:[];
  if(!String(b.name||'').trim()||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||!/^\+?[0-9][0-9 ()-]{6,24}$/.test(phone)||!['internal_user','viewer','external_broker'].includes(classification))return res.status(400).json({error:'Name, valid email, phone and user classification are required'});
  if(await one('SELECT id FROM brokers WHERE LOWER(email)=LOWER($1)',[email]))return res.status(409).json({error:'A user with this email already exists'});
  if(classification==='internal_user'&&(!assignments.length||assignments.filter(x=>x.isPrimary).length!==1))return res.status(400).json({error:'Internal users require exactly one primary role'});
  if(classification!=='internal_user'&&assignments.length)return res.status(400).json({error:'Role assignments apply only to internal users'});
  if(assignments.some(x=>!JOB_ROLES.includes(x.jobRole)||!canMaintain(req,x.jobRole)))return res.status(403).json({error:'One or more role assignments are invalid or outside your authority'});
  for(const a of assignments){if(['sales_agent','listing_agent','manager'].includes(a.jobRole)&&!a.teamId)return res.status(400).json({error:`Team is required for ${a.jobRole}`});if(a.teamId&&!(await one('SELECT id FROM teams WHERE id=$1 AND active=1',[a.teamId])))return res.status(400).json({error:'One or more assigned teams are unavailable'});}
  for(const a of assignments.filter(x=>x.jobRole==='manager')){const team=await teamManager(a.teamId);if(team?.managerId)return res.status(409).json({error:`${team.name} is already managed by ${team.managerName}. Change its manager deliberately in Team maintenance.`});}
  const primary=assignments.find(x=>x.isPrimary),role=classification==='viewer'?'viewer':classification==='external_broker'?'partner_broker':primary?.jobRole==='admin'?'admin':'internal_broker',status=classification==='external_broker'?'revoked':'pending_activation',id=uuid(),code='NYSA-'+crypto.randomBytes(8).toString('hex').toUpperCase();
  const result=await transaction(async client=>{
    const user=await one(`INSERT INTO brokers(id,name,email,phone,role,job_role,team_id,status,password_hash,invited_by,user_classification) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,[id,String(b.name).trim(),email,phone,role,primary?.jobRole||null,primary?.teamId||null,status,hashPassword(crypto.randomBytes(32).toString('hex')),req.broker.id,classification],client);
    for(const a of assignments){await execute(`INSERT INTO user_role_assignments(id,broker_id,job_role,team_id,is_primary,status,starts_at,ends_at,approved_by,change_reason) VALUES($1,$2,$3,$4,$5,'active',COALESCE($6,NOW()),$7,$8,$9)`,[uuid(),id,a.jobRole,a.teamId||null,a.isPrimary?1:0,a.startsAt||null,a.endsAt||null,req.broker.id,String(a.changeReason||'Initial approved role').trim()],client);if(a.teamId){if(a.jobRole==='manager')await syncManagerAssignment(a.teamId,id,req.broker.id,client);else await execute(`INSERT INTO team_memberships(id,team_id,broker_id,membership_role,created_by) VALUES($1,$2,$3,'member',$4)`,[uuid(),a.teamId,id,req.broker.id],client);}}
    if(classification!=='external_broker')await execute(`INSERT INTO invitations(id,code,issued_by,issued_to_email,role,job_role,max_uses,expires_at,team_id,pending_broker_id) VALUES($1,$2,$3,$4,$5,$6,1,NOW()+INTERVAL '7 days',$7,$8)`,[uuid(),code,req.broker.id,email,role,primary?.jobRole||null,primary?.teamId||null,id],client);
    await audit('Broker',id,'user_added',req.broker.id,{classification,status,phoneMaintained:true,roles:assignments},client);return user;
  });
  res.status(201).json({user:publicBroker(result),activationCode:classification==='external_broker'?null:code});
});

r.post('/admin/users/:id/roles',async(req,res)=>{
  const target=await one('SELECT * FROM brokers WHERE id=$1',[req.params.id]),b=req.body||{},reason=String(b.changeReason||'').trim();
  if(!target)return res.status(404).json({error:'User not found'});
  if(!JOB_ROLES.includes(b.jobRole)||!canMaintain(req,b.jobRole)||!reason)return res.status(400).json({error:'Valid role and change reason are required'});
  if(['sales_agent','listing_agent','manager'].includes(b.jobRole)&&!b.teamId)return res.status(400).json({error:'Team is required for this role'});
  if(b.teamId&&!(await one('SELECT id FROM teams WHERE id=$1 AND active=1',[b.teamId])))return res.status(400).json({error:'Active team not found'});
  if(b.jobRole==='manager'){const team=await teamManager(b.teamId);if(team?.managerId&&team.managerId!==target.id)return res.status(409).json({error:`${team.name} is already managed by ${team.managerName}. Change its manager deliberately in Team maintenance.`});}
  const row=await transaction(async client=>{
    if(b.isPrimary)await execute("UPDATE user_role_assignments SET is_primary=0 WHERE broker_id=$1 AND status='active'",[target.id],client);
    const created=await one(`INSERT INTO user_role_assignments(id,broker_id,job_role,team_id,is_primary,status,starts_at,ends_at,approved_by,change_reason) VALUES($1,$2,$3,$4,$5,'active',COALESCE($6,NOW()),$7,$8,$9) RETURNING *`,[uuid(),target.id,b.jobRole,b.teamId||null,b.isPrimary?1:0,b.startsAt||null,b.endsAt||null,req.broker.id,reason],client);
    if(b.teamId){if(b.jobRole==='manager')await syncManagerAssignment(b.teamId,target.id,req.broker.id,client);else await execute(`INSERT INTO team_memberships(id,team_id,broker_id,membership_role,created_by) VALUES($1,$2,$3,'member',$4) ON CONFLICT (team_id,broker_id) WHERE ends_at IS NULL DO UPDATE SET membership_role='member'`,[uuid(),b.teamId,target.id,req.broker.id],client);}
    if(b.isPrimary)await execute('UPDATE brokers SET job_role=$1,team_id=$2,updated_at=NOW() WHERE id=$3',[b.jobRole,b.teamId||null,target.id],client);
    await audit('Broker',target.id,'role_assigned',req.broker.id,{roleAssignmentId:created.id,jobRole:b.jobRole,teamId:b.teamId||null},client);return created;
  });
  res.status(201).json(row);
});
r.get('/admin/users/:id/operational-impact',async(req,res)=>{const target=await one('SELECT id,name,job_role,status FROM brokers WHERE id=$1',[req.params.id]);if(!target)return res.status(404).json({error:'User not found'});if(!canMaintain(req,target.jobRole))return res.status(403).json({error:'This user is outside your maintenance authority'});res.json({user:target,impact:await operationalOwnershipImpact(target.id)});});

r.post('/admin/users/:id/access',async(req,res)=>{const target=await one('SELECT * FROM brokers WHERE id=$1',[req.params.id]),action=req.body?.action,reason=String(req.body?.reason||'').trim();if(!target)return res.status(404).json({error:'User not found'});if(target.id===req.broker.id)return res.status(400).json({error:'You cannot change your own access state'});if(!canMaintain(req,target.jobRole))return res.status(403).json({error:'This user is outside your maintenance authority'});if(!['suspend','reactivate','revoke'].includes(action)||!reason)return res.status(400).json({error:'Valid action and reason are required'});const status=action==='reactivate'?'active':action==='suspend'?'suspended':'revoked';const result=await transaction(async client=>{if(status!=='active'){const impact=await operationalOwnershipImpact(target.id,client);if(!impact.clear)return{code:409,error:'Access cannot be removed while the user owns active operational work. Reassign and obtain receiving-user acceptance before retrying.',impact};}await execute(`UPDATE brokers SET status=$1,suspended_at=CASE WHEN $1='suspended' THEN NOW() ELSE suspended_at END,revoked_at=CASE WHEN $1='revoked' THEN NOW() ELSE revoked_at END,access_change_reason=$2,updated_at=NOW() WHERE id=$3`,[status,reason,target.id],client);if(status!=='active')await execute('DELETE FROM sessions WHERE broker_id=$1',[target.id],client);await audit('Broker',target.id,action,req.broker.id,{reason},client);return{ok:true,status};});if(result.error)return res.status(result.code).json(result);res.json(result);});

r.put('/admin/users/:id/business-areas',async(req,res)=>{
  const target=await one('SELECT * FROM brokers WHERE id=$1',[req.params.id]),body=req.body||{};
  if(!target)return res.status(404).json({error:'User not found'});
  if(target.role!=='internal_broker')return res.status(400).json({error:'Business areas apply to internal CRM users'});
  if(!canMaintain(req,target.jobRole))return res.status(403).json({error:'This user is outside your maintenance authority'});
  const teamIds=[...new Set((Array.isArray(body.teamIds)?body.teamIds:[]).filter(Boolean))],areaIds=[...new Set((Array.isArray(body.areaIds)?body.areaIds:[]).filter(Boolean))],primaryTeamId=body.primaryTeamId||null,reason=String(body.reason||'').trim();
  if(!teamIds.length)return res.status(400).json({error:'Select at least one business area'});
  if(!primaryTeamId||!teamIds.includes(primaryTeamId))return res.status(400).json({error:'Primary team must be one of the selected business areas'});
  if(!reason)return res.status(400).json({error:'Change reason is required'});
  const teams=await many('SELECT id FROM teams WHERE id=ANY($1::uuid[]) AND active=1',[teamIds]);
  if(teams.length!==teamIds.length)return res.status(400).json({error:'One or more selected business areas are unavailable'});
  const areas=areaIds.length?await many('SELECT id FROM areas WHERE id=ANY($1::uuid[]) AND active=1',[areaIds]):[];
  if(areas.length!==areaIds.length)return res.status(400).json({error:'One or more selected geographical areas are unavailable'});
  await transaction(async client=>{
    const before=await many('SELECT team_id,membership_role FROM team_memberships WHERE broker_id=$1 AND ends_at IS NULL',[target.id],client);
    await execute('UPDATE team_memberships SET ends_at=NOW() WHERE broker_id=$1 AND ends_at IS NULL AND NOT(team_id=ANY($2::uuid[]))',[target.id,teamIds],client);
    for(const teamId of teamIds){
      const managed=await one('SELECT id FROM teams WHERE id=$1 AND manager_id=$2',[teamId,target.id],client),membershipRole=managed?'manager':'member';
      await execute(`INSERT INTO team_memberships(id,team_id,broker_id,membership_role,created_by) VALUES($1,$2,$3,$4,$5)
        ON CONFLICT (team_id,broker_id) WHERE ends_at IS NULL DO UPDATE SET membership_role=EXCLUDED.membership_role`,
        [uuid(),teamId,target.id,membershipRole,req.broker.id],client);
    }
    await execute('UPDATE brokers SET team_id=$1,updated_at=NOW() WHERE id=$2',[primaryTeamId,target.id],client);
    await execute(`UPDATE user_role_assignments SET team_id=$1 WHERE broker_id=$2 AND is_primary=1 AND status='active'`,[primaryTeamId,target.id],client);
    await execute('UPDATE agent_area_assignments SET ends_at=NOW() WHERE broker_id=$1 AND ends_at IS NULL AND NOT(area_id=ANY($2::uuid[]))',[target.id,areaIds],client);
    for(const areaId of areaIds)await execute(`INSERT INTO agent_area_assignments(id,broker_id,area_id,created_by) VALUES($1,$2,$3,$4)
      ON CONFLICT (broker_id,area_id) WHERE ends_at IS NULL DO NOTHING`,[uuid(),target.id,areaId,req.broker.id],client);
    await audit('Broker',target.id,'assignment_scope_updated',req.broker.id,{reason,primaryTeamId,teamIds,areaIds,before},client);
  });
  res.json({ok:true,primaryTeamId,teamIds,areaIds});
});

r.patch('/admin/brokers/:id', async (req, res) => {
  const broker = await one('SELECT * FROM brokers WHERE id=$1', [req.params.id]);
  if (!broker) return res.status(404).json({ error:'Broker not found' });
  const { role, status, canPost, teamId, jobTitle, jobRole,reportsToId,name,email,phone,brn,brnIssuedOn } = req.body || {};
  if (role !== undefined && !ROLES.includes(role)) return res.status(400).json({ error:'Invalid role' });
  if (jobRole !== undefined && jobRole !== null && !JOB_ROLES.includes(jobRole)) return res.status(400).json({ error:'Invalid jobRole' });
  if (status !== undefined && !['pending_activation','active','suspended','revoked'].includes(status)) return res.status(400).json({ error:'Invalid status' });
  if(name!==undefined&&!String(name).trim())return res.status(400).json({error:'User name is required'});
  if(email!==undefined&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email).trim()))return res.status(400).json({error:'Enter a valid user email'});
  if(phone!==undefined&&phone!==null&&String(phone).trim()&&!/^\+?[0-9][0-9 ()-]{6,24}$/.test(String(phone).trim()))return res.status(400).json({error:'Enter a valid representative phone number'});
  if(email!==undefined&&await one('SELECT id FROM brokers WHERE LOWER(email)=LOWER($1) AND id<>$2',[String(email).trim(),broker.id]))return res.status(409).json({error:'A user with this email already exists'});
  const brnCheck=validateBrnDetails({brn:brn===undefined?broker.brn:brn,brnIssuedOn:brnIssuedOn===undefined?broker.brnIssuedOn:brnIssuedOn});
  if(brnCheck.error)return res.status(400).json({error:brnCheck.error});
  if (req.broker.role !== 'admin' && (!canMaintain(req,broker.jobRole) || (jobRole && !canMaintain(req,jobRole)) || role === 'admin' || status !== undefined)) return res.status(403).json({ error:'Only Admin can alter privileged roles or access status' });
  if (teamId && !(await one('SELECT id FROM teams WHERE id=$1 AND active=1', [teamId]))) return res.status(400).json({ error:'Invalid teamId' });
  const nextJobRole=jobRole===undefined?broker.jobRole:jobRole||null,nextTeamId=teamId===undefined?broker.teamId:teamId||null;
  if(reportsToId!==undefined&&nextJobRole!=='manager')return res.status(400).json({error:'Only a Manager can have a maintained Director reporting line'});
  if(reportsToId&&!(await one("SELECT id FROM brokers WHERE id=$1 AND role='internal_broker' AND job_role='director' AND status='active'",[reportsToId])))return res.status(400).json({error:'Select an active Managing Director'});
  if(nextJobRole==='manager'&&!nextTeamId)return res.status(400).json({error:'Team is required for a Manager'});
  if(nextJobRole==='manager'){const team=await teamManager(nextTeamId);if(team?.managerId&&team.managerId!==broker.id)return res.status(409).json({error:`${team.name} is already managed by ${team.managerName}. Change its manager deliberately in Team maintenance.`});}
  if (broker.id === req.broker.id && role !== undefined && role !== 'admin') return res.status(400).json({ error:'You cannot demote yourself' });
  if (broker.id === req.broker.id && status === 'revoked') return res.status(400).json({ error:'You cannot revoke yourself' });
  const changes = {};
  await transaction(async (client) => {
    for(const [field,value,column] of [['name',name,'name'],['email',email,'email'],['phone',phone,'phone']]){
      if(value===undefined)continue;const normalized=field==='email'?String(value).trim().toLowerCase():String(value||'').trim()||null;
      if((broker[field]||null)!==normalized){changes[field]={from:broker[field]||null,to:normalized};await execute(`UPDATE brokers SET ${column}=$1,updated_at=NOW() WHERE id=$2`,[normalized,broker.id],client);}
    }
    if(brn!==undefined||brnIssuedOn!==undefined){
      const next=brnCheck.value;
      if((broker.brn||null)!==next.brn||(broker.brnIssuedOn?String(broker.brnIssuedOn).slice(0,10):null)!==next.brnIssuedOn){
        changes.brn={from:broker.brn||null,to:next.brn};changes.brnIssuedOn={from:broker.brnIssuedOn||null,to:next.brnIssuedOn};
        await execute('UPDATE brokers SET brn=$1,brn_issued_on=$2,updated_at=NOW() WHERE id=$3',[next.brn,next.brnIssuedOn,broker.id],client);
      }
    }
    if (role !== undefined && role !== broker.role) {
      changes.role = { from:broker.role, to:role };
      const defaultJobRole = role === 'admin' ? 'admin' : role === 'internal_broker' ? (jobRole || broker.jobRole || 'sales_agent') : null;
      await execute('UPDATE brokers SET role=$1,job_role=$2,team_id=CASE WHEN $1 IN (\'admin\',\'internal_broker\') THEN team_id ELSE NULL END WHERE id=$3', [role,defaultJobRole,broker.id], client);
    }
    if (canPost !== undefined && (canPost ? 1 : 0) !== broker.canPost) {
      changes.canPost = { from:broker.canPost, to:canPost?1:0 };
      await execute('UPDATE brokers SET can_post=$1 WHERE id=$2', [canPost?1:0,broker.id], client);
    }
    if (status !== undefined && status !== broker.status) {
      changes.status = { from:broker.status, to:status };
      await execute('UPDATE brokers SET status=$1 WHERE id=$2', [status,broker.id], client);
      if (status === 'revoked') await execute('DELETE FROM sessions WHERE broker_id=$1', [broker.id], client);
    }
    if (teamId !== undefined && (teamId || null) !== broker.teamId) {
      changes.teamId = { from:broker.teamId, to:teamId||null };
      await execute('UPDATE brokers SET team_id=$1 WHERE id=$2', [teamId||null,broker.id], client);
      if(teamId) await execute(`INSERT INTO team_memberships (id,team_id,broker_id,membership_role,created_by)
        VALUES ($1,$2,$3,$4,$5) ON CONFLICT (team_id,broker_id) WHERE ends_at IS NULL DO NOTHING`,
        [uuid(),teamId,broker.id,(jobRole||broker.jobRole)==='manager'?'manager':'member',req.broker.id],client);
    }
    if (jobTitle !== undefined && (jobTitle || null) !== broker.jobTitle) {
      changes.jobTitle = { from:broker.jobTitle, to:jobTitle||null };
      await execute('UPDATE brokers SET job_title=$1 WHERE id=$2', [jobTitle||null,broker.id], client);
    }
    if (jobRole !== undefined && (jobRole || null) !== broker.jobRole) {
      changes.jobRole = { from:broker.jobRole, to:jobRole||null };
      await execute('UPDATE brokers SET job_role=$1 WHERE id=$2', [jobRole||null,broker.id], client);
    }
    if(reportsToId!==undefined&&(reportsToId||null)!==broker.reportsToId){changes.reportsToId={from:broker.reportsToId,to:reportsToId||null};await execute('UPDATE brokers SET reports_to_id=$1 WHERE id=$2',[reportsToId||null,broker.id],client);}
    if(nextJobRole!=='manager'&&broker.reportsToId)await execute('UPDATE brokers SET reports_to_id=NULL WHERE id=$1',[broker.id],client);
    if(teamId!==undefined||jobRole!==undefined)await execute(`UPDATE user_role_assignments SET job_role=$1,team_id=$2 WHERE broker_id=$3 AND is_primary=1 AND status='active'`,[nextJobRole,nextTeamId,broker.id],client);
    await execute(`UPDATE teams t SET manager_id=NULL WHERE t.manager_id=$1 AND (t.id<>$2 OR $3 IS DISTINCT FROM 'manager') AND NOT EXISTS(
      SELECT 1 FROM user_role_assignments r WHERE r.broker_id=$1 AND r.team_id=t.id AND r.job_role='manager' AND r.is_primary=0 AND r.status='active' AND r.ends_at IS NULL)`,[broker.id,nextTeamId,nextJobRole],client);
    if(nextTeamId&&nextJobRole==='manager')await syncManagerAssignment(nextTeamId,broker.id,req.broker.id,client);
    else if(nextTeamId)await execute("UPDATE team_memberships SET membership_role='member' WHERE team_id=$1 AND broker_id=$2 AND ends_at IS NULL",[nextTeamId,broker.id],client);
    if (Object.keys(changes).length) await audit('Broker', broker.id, 'edited', req.broker.id, changes, client);
  });
  res.json(publicBroker(await one('SELECT * FROM brokers WHERE id=$1', [broker.id])));
});

r.get('/admin/audit-log', async (req, res) => {
  const { entityType, entityId, performedBy, from, to } = req.query;
  const where = ['1=1'], params = [];
  const add = (clause, value) => { params.push(value); where.push(clause.replace('?', `$${params.length}`)); };
  if (entityType) add('a.entity_type = ?', entityType);
  if (entityId) add('a.entity_id = ?', entityId);
  if (performedBy) add('a.performed_by = ?', performedBy);
  if (from) add('a.timestamp >= ?', from);
  if (to) add('a.timestamp <= ?', to);
  const limit = Math.max(1, Math.min(Number(req.query.limit) || 200, 1000));
  params.push(limit);
  const rows = await many(`SELECT a.*, b.name AS performed_by_name FROM audit_log a
    JOIN brokers b ON b.id = a.performed_by WHERE ${where.join(' AND ')}
    ORDER BY a.timestamp DESC LIMIT $${params.length}`, params);
  res.json({ count:rows.length, entries:rows });
});

export default r;
